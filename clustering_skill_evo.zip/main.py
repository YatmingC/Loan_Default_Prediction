import argparse
import json
import os
import pickle
import random
import shutil
import logging
from pathlib import Path
import json_repair

from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)
logger.level = logging.DEBUG

BUSY_MAX_PARALLEL = 10  # 模型服务忙碌时间并发
IDLE_MAX_PARALLEL = 40  # 模型服务空闲时间并发
ACCEPT_THRESHOLD = 0.8

from src.utils import (
    dataload, clustering_func, build_feature_matrix, validation_skill,
    analyse_skill_result, interactive_agent,
    interactive_agent_send_message, interactive_agent_send_and_get,
    run_agent, clean_agents
)
from src.prompt_template import render
from adaptive_clustering.core.clustering.metrics import compute_all_clustering_metrics
import numpy as np

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", type=str, required=True, help="input file dir")
    parser.add_argument("-o", "--output", type=str, required=True, help="output file dir")

    parser.add_argument("--max_iterations", type=int, default=2, help="max iterations")
    parser.add_argument("--max_skill_evo_iterations", type=int, default=2, help="max iterations")

    args = parser.parse_args()
    return args

def get_score(answer_list, label_list):
    """
    评估预测答案与真实标签，计算 precision、recall、F1 分数，
    并返回正确与错误的样本索引。

    参数:
        answer_list (list of str): 预测答案列表，每个元素应以“是”或“否”结尾。
        label_list (list of str): 真实标签列表，每个元素为“1”或“0”。

    返回:
        dict: 包含以下键：
            - precision (float): 精确率
            - recall (float): 召回率
            - f1 (float): F1 分数
            - correct_ids (list of int): 预测正确的样本索引（从0开始）
            - error_ids (list of int): 预测错误的样本索引
    """
    # 确保两个列表长度一致
    if len(answer_list) != len(label_list):
        raise ValueError("answer_list 和 label_list 长度必须相同")

    TP = FP = FN = TN = 0
    correct_ids = []
    error_ids = []

    for idx, (ans, lbl) in enumerate(zip(answer_list, label_list)):
        ans_stripped = ans.strip()
        # 根据答案结尾确定预测标签
        if ans_stripped.endswith("是"):
            pred = 1
        elif ans_stripped.endswith("否"):
            pred = 0
        else:
            # 若答案不以“是”或“否”结尾，视为无效，跳过（可根据需求修改）
            # 此处简单跳过并计入错误
            error_ids.append(idx)
            continue

        # 判断是否正确
        if pred == lbl:
            correct_ids.append(idx)
        else:
            error_ids.append(idx)

        # 更新混淆矩阵（正类为“是”）
        if lbl == 1:
            if pred == 1:
                TP += 1
            else:
                FN += 1
        else:  # lbl == "否"
            if pred == 1:
                FP += 1
            else:
                TN += 1

    # 计算精确率、召回率、F1
    precision = TP / (TP + FP) if (TP + FP) > 0 else 0.0
    recall = TP / (TP + FN) if (TP + FN) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "correct_ids": correct_ids,
        "error_ids": error_ids
    }

def construct_validation_prompt(data_line):
    return render("validation_prompt.j2", data_line=data_line)

def construct_feedback_prompt(data_line):
    return render("feedback_prompt.j2", data_line=data_line)

def get_max_parallel():
    from datetime import datetime, time
    from zoneinfo import ZoneInfo

    busy_max_parallel = BUSY_MAX_PARALLEL
    idle_max_parallel = IDLE_MAX_PARALLEL
    # 模型忙碌开始时间(即模型空闲结束时间)07:30-2:00(预测耗时2h)=05:30
    busy_start_time_schedule = {
        "hour": 5,
        "minute": 30
    }
    # 模型忙碌结束时间(模型空闲开始时间)18:30
    busy_end_time_schedule = {
        "hour": 18,
        "minute": 30
    }

    if os.path.exists("model_parallel_config.json"):    
        with open("model_parallel_config.json", "r", encoding="utf-8") as f:
            model_parallel_config = json.load(f)

            busy_max_parallel = model_parallel_config["parallel_config"]["busy_max_parallel"]
            idle_max_parallel = model_parallel_config["parallel_config"]["idle_max_parallel"]

            busy_start_time_schedule["hour"] = model_parallel_config["time_config"]["busy_start_time"]["hour"]
            busy_start_time_schedule["minute"] = model_parallel_config["time_config"]["busy_start_time"]["minute"]

            busy_end_time_schedule["hour"] = model_parallel_config["time_config"]["busy_end_time"]["hour"]
            busy_end_time_schedule["minute"] = model_parallel_config["time_config"]["busy_end_time"]["minute"]
    
    china_tz = ZoneInfo("Asia/Shanghai")
    now = datetime.now(china_tz).time()  # 获取当前时间（仅时分秒）
    busy_start_time = time(busy_start_time_schedule["hour"], busy_start_time_schedule["minute"]) 
    busy_end_time = time(busy_end_time_schedule["hour"], busy_end_time_schedule["minute"])       

    if busy_start_time <= now <= busy_end_time:
        logger.info(f"time {now=} max_parallel_size={busy_max_parallel}")
        return busy_max_parallel
    else:
        logger.info(f"time {now=} max_parallel_size={idle_max_parallel}")
        return idle_max_parallel

def main():
    args = parse_args()

    data = dataload(
        data_path=os.path.join(args.input, "sampled_test_data_add_prompt.xlsx"),
        columns_desc_path=os.path.join(args.input, "columns_description.xlsx")
    )

    cluster_session_id = None
    cluster_algo = {
        "cluster_func_name": "kmeans",
        "n_clusters": 30
    }
    excluded_features: list[str] = []  # 被剔除的聚类特征列；空=使用全部候选

    column_configs = data["column_configs"]
    candidate_features = data["candidate_features"]
    raw_df = data["df"]

    for iteration in range(args.max_iterations):
        logger.info(f"{iteration=} start!")
        os.makedirs(os.path.join(args.output, f"iteration_{iteration}"), exist_ok=True)
        project_dir = os.path.join(args.output, f"iteration_{iteration}")

        cluster_func_name = cluster_algo.get("cluster_func_name", "kmeans")
        if "cluster_func_name" in cluster_algo:
            cluster_algo.pop("cluster_func_name")
        # exclude_features 不作为算法参数，提前摘除避免泄漏给聚类方法
        cluster_algo.pop("exclude_features", None)
        algorithm_params = cluster_algo

        # 由剔除集合推导本轮使用的特征列并重建特征矩阵
        excluded_set = set(excluded_features)
        active_features = [c for c in candidate_features if c not in excluded_set]
        logger.info(f"{iteration=} {excluded_set=}")
        feature_matrix, feature_names = build_feature_matrix(
            raw_df, column_configs, active_features, label_column="Default"
        )
        logger.info(
            f"{iteration=} active_features({len(active_features)}/{len(candidate_features)}) "
            f"excluded={excluded_features} encoded_dims={len(feature_names)}"
        )

        cluster_result = clustering_func(
            method=cluster_func_name,
            algorithm_params=algorithm_params,
            feature_matrix=feature_matrix,
            raw_dataframe=data["raw_dataframe"]
        )

        # 计算聚类质量指标（簇数不足时降级为空）
        labels = cluster_result["labels"]
        feat_np = np.array(feature_matrix, dtype=float)
        labels_np = np.array(labels)
        clustering_metrics: dict = {}
        n_clusters = len(set(labels) - {-1})
        if n_clusters >= 2:
            try:
                metrics_obj = compute_all_clustering_metrics(feat_np, labels_np)
                clustering_metrics = metrics_obj.model_dump()
            except Exception as e:
                logger.warning(f"{iteration=} 聚类指标计算失败: {e}")
        else:
            logger.info(f"{iteration=} 簇数={n_clusters}，聚类指标不可用")

        logger.info(f"{n_clusters=} saving cluster model to {project_dir}/model.pkl")
        with open(os.path.join(project_dir, "model.pkl"), "wb") as f:
            pickle.dump(cluster_result["model"], f)

        for cluster_label, cluster_samples in zip(cluster_result["cluster_labels"], cluster_result["cluster_samples"]):
            logger.info(f"{cluster_label=} start!")
            pre_compute_score = get_score(
                [sample["reasoning"] for sample in cluster_samples["samples"]],
                [sample["Default"] for sample in cluster_samples["samples"]]
            )

            logger.info(f"{pre_compute_score["precision"]=} {pre_compute_score["recall"]=} {pre_compute_score["f1"]=}")
            if pre_compute_score["f1"] > ACCEPT_THRESHOLD:
                logger.info(f"f1 score: {pre_compute_score['f1']} > {ACCEPT_THRESHOLD} skip!")
                continue
            logger.info(f"f1 score: {pre_compute_score['f1']} < {ACCEPT_THRESHOLD} will evo skills!")

            os.makedirs(os.path.join(project_dir, cluster_label), exist_ok=True)
            cluster_dir = os.path.join(project_dir, cluster_label)
            os.makedirs(os.path.join(cluster_dir, ".cache"), exist_ok=True)
            positive_samples = list(filter(lambda sample: sample["Default"] == 1, cluster_samples["samples"]))
            negative_samples = list(filter(lambda sample: sample["Default"] == 0, cluster_samples["samples"]))

            # 1:1采样
            if len(positive_samples) == 0:
                logger.info(f"{iteration=} {cluster_label=} no positive samples!")
                continue
                # choices_negative_samples = random.sample(negative_samples, min(1, int(len(negative_samples) * 0.1)))
            else:
                choices_negative_samples = random.sample(negative_samples, len(positive_samples) if len(positive_samples) < len(negative_samples) else len(negative_samples))

            all_samples = positive_samples + choices_negative_samples
            logger.info(f"{iteration=} {cluster_label=} {len(positive_samples)=} {len(negative_samples)=}")
            for i, sample in enumerate(all_samples):
                all_samples[i]["validation_prompt"] = construct_validation_prompt(sample)

            session_id = None
            for skill_evo_iter in range(args.max_skill_evo_iterations):

                # validation skill
                if skill_evo_iter == 0:
                    os.makedirs(cluster_dir, exist_ok=True)
                    shutil.copytree(f"./default_skill/", cluster_dir, dirs_exist_ok=True)
                all_validation_result = validation_skill(cluster_dir, prompt_list=[sample["validation_prompt"] for sample in all_samples], max_parallel_size=get_max_parallel())
                logger.debug(f"{iteration=} {cluster_label=} {skill_evo_iter=} {all_validation_result=}")
                clean_agents([cluster_session_id, session_id])

                for i, sample in enumerate(all_samples):
                    all_samples[i]["validation_result"] = all_validation_result[i]

                score_result = get_score(
                    [sample["validation_result"]["risk_result"] for sample in all_samples],
                    [sample["Default"] for sample in all_samples],
                )

                precision = score_result["precision"]
                recall = score_result["recall"]
                f1 = score_result["f1"]
                # correct_case = [all_samples[i] for i in score_result["correct_ids"]]
                # error_case = [all_samples[i] for i in score_result["error_ids"]]
                logger.info(f"{iteration=} {cluster_label=} {skill_evo_iter=} score: {precision=} {recall=} {f1=}")

                # if f1 > ACCEPT_THRESHOLD:
                #     logger.info(f"f1 score: {f1} > {ACCEPT_THRESHOLD} skip!")
                #     break

                for i, sample in enumerate(all_samples):
                    all_samples[i]["skill_feedback_prompt"] = construct_feedback_prompt(sample)

                # 簇skill结果分析
                all_analyse_result = analyse_skill_result(
                    cluster_dir,
                    prompt_list=[sample["skill_feedback_prompt"] for sample in all_samples],
                    max_parallel_size=get_max_parallel()
                )
                logger.debug(f"{iteration=} {cluster_label=} {skill_evo_iter=} {all_samples[0]['skill_feedback_prompt']=} {all_analyse_result=}")
                clean_agents([cluster_session_id, session_id])

                for i, sample in enumerate(all_samples):
                    all_samples[i]["skill_analyse_result"] = all_analyse_result[i]

                # 簇skill结果分析汇总 & 簇聚类效果分析
                merge_prompt = render("merge_summary_prompt.j2", samples=all_samples)
                logger.debug(f"{iteration=} {cluster_label=} {merge_prompt=}")
                merge_result = run_agent(
                    cluster_dir,
                    output_schema_path=Path(__file__).parent / "json_schemas/merge_result.json",
                    prompt=merge_prompt,
                    parser=lambda x:x
                )
                logger.debug(f"{iteration=} {cluster_label=} {skill_evo_iter=} {merge_result=}")

                cluster_samples["pattern_collections"] = merge_result["pattern_collections"]
                cluster_samples["clustering_analyse"] = merge_result["clustering_analyse"]

                # 更新skill
                update_skill_msg = render("update_skill_prompt.j2", pattern_collections=merge_result['pattern_collections'])
                logger.debug(f"{iteration=} {cluster_label=} {update_skill_msg=}")
                if session_id is None:
                    session_id = interactive_agent(cluster_dir, update_skill_msg)["session_id"]
                else:
                    interactive_agent_send_message(session_id, "/compact")
                    interactive_agent_send_message(session_id, update_skill_msg)

                # 缓存
                with open(Path(cluster_dir) / f".cache/{skill_evo_iter}.json", "w", encoding="utf-8") as f:
                    json.dump(cluster_samples, f, ensure_ascii=False)
                shutil.copytree(Path(cluster_dir) / "skills" / "post-loan-management", Path(cluster_dir) / f".cache/{skill_evo_iter}_post-loan-management", dirs_exist_ok=True)
            clean_agents([cluster_session_id])

        # 聚类调整
        cluster_gathered = "\n\n".join([sample.get('clustering_analyse', '当前簇正常，无需调整') for sample in cluster_result["cluster_samples"]])

        # 计算总指标
        answer_list = []
        gt_list = []
        for cluster_samples in cluster_result["cluster_samples"]:
            for sample in cluster_samples["samples"]:
                if "validation_result" in sample:
                    answer_list.append(sample["validation_result"]["risk_result"])
                else:
                    answer_list.append(sample["reasoning"])
                gt_list.append(sample["Default"])
        all_score = get_score(answer_list, gt_list)

        logger.info(f"{iteration=} {all_score=}")

        retry_times = 0
        param_space = cluster_result['method_class'].get_param_space()
        # 通过 extra_properties 注入可选的 exclude_features 字段（字符串数组，候选限定为聚类列）
        param_space_schema = param_space.to_json_schema(extra_properties={
            "exclude_features": {
                "type": "array",
                "items": {"type": "string", "enum": candidate_features},
                "description": "本轮要从聚类特征中剔除的原始列名；可选，缺省沿用上一轮剔除集合",
            }
        })
        param_space_schema_json = json.dumps(
            param_space_schema, ensure_ascii=False, indent=2
        )

        def _check_cluster_algo(algo) -> list[str]:
            errs: list[str] = []
            if algo is None:
                return ["未在回复中找到 ```json``` 围栏代码块"]
            if not isinstance(algo, dict):
                return [f"输出必须是 JSON 对象，得到 {type(algo).__name__}"]
            if "cluster_func_name" not in algo:
                errs.append("缺失参数: cluster_func_name")
            elif algo["cluster_func_name"] != cluster_func_name:
                errs.append(
                    f"cluster_func_name 必须为 {cluster_func_name}，得到 {algo['cluster_func_name']!r}"
                )
            # exclude_features 与 cluster_func_name 一样不属于算法参数，摘除后做独立校验
            excl = algo.get("exclude_features")
            params_only = {
                k: v for k, v in algo.items()
                if k not in ("cluster_func_name", "exclude_features")
            }
            errs.extend(param_space.validate_params(params_only))
            if "exclude_features" in algo:
                if not isinstance(excl, list):
                    errs.append(f"exclude_features 必须是数组，得到 {type(excl).__name__}")
                else:
                    cand_set = set(candidate_features)
                    bad = [c for c in excl if not isinstance(c, str) or c not in cand_set]
                    if bad:
                        errs.append(f"exclude_features 含非法列名: {bad}，候选: {candidate_features}")
                    elif len(candidate_features) - len(set(excl)) < 1:
                        errs.append(
                            f"exclude_features 不能剔除全部候选列，至少保留 1 列（候选共 {len(candidate_features)} 列）"
                        )
            return errs

        # 首轮：发完整 prompt 启动 / 复用 agent
        cluster_prompt = render("cluster_adjust_prompt.j2",
                                cluster_func_name=cluster_func_name,
                                param_space_json=param_space_schema_json,
                                cluster_gathered=cluster_gathered,
                                iteration=iteration,
                                candidate_features=candidate_features,
                                current_excluded=excluded_features,
                                current_features=active_features,
                                feature_names=feature_names,
                                clustering_metrics=clustering_metrics)
        logger.debug(f"{iteration=} {cluster_prompt=}")
        if cluster_session_id is None:
            # 首轮：创建新 session 并获取输出
            cluster_output, cluster_session_id = interactive_agent_send_and_get(
                None, cluster_prompt, cwd=project_dir)
        else:
            # 后续轮：复用 session，先 compact 再发新 prompt
            interactive_agent_send_message(cluster_session_id, "/compact")
            cluster_output, _ = interactive_agent_send_and_get(
                cluster_session_id, cluster_prompt)

        # json_repair解析输出
        cluster_algo = json_repair.loads(cluster_output)
        logger.debug(f"{iteration=} {cluster_algo=}")
        cluster_errors = _check_cluster_algo(cluster_algo)

        # 校验失败：把错误信息直接发回 session 让它修
        while cluster_errors:
            retry_times += 1
            if retry_times > 3:
                raise ValueError(f"聚类参数错误！{cluster_errors}")

            errors_mess = "\n".join(cluster_errors)
            cluster_output, _ = interactive_agent_send_and_get(
                cluster_session_id,
                f"你的输出解析时提示：\n{errors_mess}\n\n请重新以 ```json``` 围栏代码块的形式给出修正后的完整 JSON。"
            )

            cluster_algo = json_repair.loads(cluster_output)
            logger.debug(f"{iteration=} retry={retry_times} {cluster_algo=}")
            cluster_errors = _check_cluster_algo(cluster_algo)

        # 应用本轮特征剔除选择（未输出 exclude_features 则沿用上轮）
        if isinstance(cluster_algo, dict) and "exclude_features" in cluster_algo:
            excluded_features = cluster_algo["exclude_features"]
            logger.info(f"{iteration=} 更新 excluded_features={excluded_features}")

if __name__ == "__main__":
    main()
