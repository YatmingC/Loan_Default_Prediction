#!/usr/bin/env python3
"""分析聚类上下文并生成特征报告

使用方式：
    python scripts/analyze_clustering_context.py --context context/iteration_0_context.json

输出：
    打印到stdout的分析报告（JSON格式）
"""

import argparse
import json
import sys
import numpy as np
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="分析聚类上下文特征")
    parser.add_argument("--context", required=True, help="上下文JSON文件路径")
    args = parser.parse_args()

    try:
        # 读取上下文
        with open(args.context, "r", encoding="utf-8") as f:
            context = json.load(f)

        # 读取特征矩阵
        feature_matrix_path = context.get("feature_matrix_path")
        if not feature_matrix_path or not Path(feature_matrix_path).exists():
            raise FileNotFoundError(f"特征矩阵文件不存在: {feature_matrix_path}")

        feature_matrix = np.load(feature_matrix_path)
        n_samples, n_features = feature_matrix.shape

        # 计算特征统计
        feature_means = feature_matrix.mean(axis=0)
        feature_stds = feature_matrix.std(axis=0)
        feature_vars = feature_matrix.var(axis=0)

        # 识别低方差特征（可能需要剔除）
        low_variance_threshold = 0.01
        low_variance_features = [i for i, var in enumerate(feature_vars) if var < low_variance_threshold]

        # 计算特征相关性（采样，避免计算量过大）
        high_corr_pairs = []
        sample_size = min(100, n_features)  # 只检查前100个特征或全部
        for i in range(sample_size):
            for j in range(i+1, sample_size):
                corr = np.corrcoef(feature_matrix[:, i], feature_matrix[:, j])[0, 1]
                if abs(corr) > 0.95:
                    high_corr_pairs.append((i, j, float(corr)))
                if len(high_corr_pairs) >= 20:  # 最多返回20对
                    break
            if len(high_corr_pairs) >= 20:
                break

        # 异常值检测（IQR方法）
        outlier_ratios = []
        for i in range(n_features):
            q1 = np.percentile(feature_matrix[:, i], 25)
            q3 = np.percentile(feature_matrix[:, i], 75)
            iqr_val = q3 - q1
            if iqr_val > 0:
                lower = q1 - 1.5 * iqr_val
                upper = q3 + 1.5 * iqr_val
                outliers = np.sum((feature_matrix[:, i] < lower) | (feature_matrix[:, i] > upper))
                outlier_ratios.append(outliers / n_samples)
            else:
                outlier_ratios.append(0.0)

        avg_outlier_ratio = float(np.mean(outlier_ratios))

        # 构建分析报告
        report = {
            "data_characteristics": {
                "n_samples": n_samples,
                "n_features": n_features,
                "dimension_ratio": float(n_features / n_samples) if n_samples > 0 else 0.0,
                "avg_outlier_ratio": avg_outlier_ratio
            },
            "feature_quality": {
                "low_variance_feature_count": len(low_variance_features),
                "low_variance_feature_indices": low_variance_features[:10],  # 最多返回10个
                "high_correlation_pair_count": len(high_corr_pairs),
                "high_correlation_pairs": [
                    {"feature_i": i, "feature_j": j, "correlation": corr}
                    for i, j, corr in high_corr_pairs[:10]
                ]
            },
            "recommendations": []
        }

        # 生成建议
        if len(low_variance_features) > 0:
            report["recommendations"].append(
                f"检测到{len(low_variance_features)}个低方差特征（var < {low_variance_threshold}），建议剔除"
            )

        if len(high_corr_pairs) > 0:
            report["recommendations"].append(
                f"检测到{len(high_corr_pairs)}对高相关特征（|corr| > 0.95），考虑剔除冗余特征"
            )

        if avg_outlier_ratio > 0.1:
            report["recommendations"].append(
                f"异常值占比{avg_outlier_ratio:.1%} > 10%，建议使用DBSCAN等噪声鲁棒算法"
            )

        if n_features / n_samples > 0.5:
            report["recommendations"].append(
                f"维度比{n_features / n_samples:.2f} > 0.5，存在维度灾难风险，建议降维或剔除特征"
            )

        # 输出到stdout（Agent可以捕获）
        print(json.dumps(report, indent=2, ensure_ascii=False))

    except Exception as e:
        error_report = {
            "error": str(e),
            "type": type(e).__name__
        }
        print(json.dumps(error_report, indent=2, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
