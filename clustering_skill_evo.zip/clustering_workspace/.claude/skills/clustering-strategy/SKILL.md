---
name: clustering-strategy
description: >
  聚类算法选择与参数调优专家。根据数据特征、历史聚类质量指标和簇级反馈，
  自主选择最优聚类算法（K-Means/DBSCAN/Gaussian Mixture/Spectral）并配置参数。
  触发词："调整聚类"、"选择聚类算法"、"优化聚类参数"。
  不适用于：skill演进、风控分析、贷后管理。
target_role: 机器学习工程师 / 数据科学家
business_domain: 机器学习 > 无监督学习 > 聚类算法
risk_level: medium
version: 1.0.0
status: active
---

## 目标角色 (Target Role)

- **角色**：机器学习工程师 / 数据科学家
- **使用场景**：迭代优化聚类算法和参数，提升聚类质量
- **输出用途**：生成算法选择和参数配置的结构化决策
- **决策层级**：算法策略决策，不涉及业务逻辑
- **执行频率**：每轮聚类迭代后执行一次

## 重要约束 (Critical Constraints)

⚠️ **Skill作用域限制**：
- 本Skill仅负责聚类算法选择和参数配置
- 不参与风控规则制定、不分析企业财务数据
- 不得读取或修改 `skills/post-loan-management/` 等业务Skill
- 输出仅包含算法名称、参数配置、特征选择建议

⚠️ **禁止跨域操作**：
- 工作目录限定在聚类工作空间内
- 仅允许读取 `context/` 目录下的上下文文件
- 仅允许调用 `scripts/` 目录下的分析脚本
- 不得访问业务数据的原始文件

## 数据接入 (Data Sources)

### 必需数据（从上下文文件读取）
| 数据项 | 来源文件 | 说明 |
|--------|---------|------|
| 数据规模 | context/iteration_X_context.json | n_samples, n_features |
| 特征矩阵 | context/iteration_X_feature_matrix.npy | 用于特征分析 |
| 上一轮聚类结果 | context/iteration_X_context.json | prev_method, prev_params |
| 聚类质量指标 | context/iteration_X_context.json | silhouette, davies_bouldin等 |
| 簇结构统计 | context/iteration_X_context.json | cluster_stats |
| 簇级反馈 | context/iteration_X_context.json | cluster_gathered |
| 算法切换历史 | context/iteration_X_context.json | algorithm_switch_history |
| 历史决策库 | decision_history/decisions.jsonl | 历史决策及效果（JSONL） |

### 数据获取方式
```python
import json
import numpy as np

# 读取上下文文件（路径在prompt中给出）
with open("context/iteration_X_context.json", "r") as f:
    context = json.load(f)

# 读取特征矩阵
feature_matrix = np.load(context["feature_matrix_path"])
```

## 术语消歧 (Terminology)

| 术语 | 本Skill中含义 |
|------|--------------|
| 聚类质量 | 通过silhouette/davies_bouldin/calinski_harabasz等指标综合评估 |
| 噪声点 | DBSCAN算法识别的label=-1的样本 |
| 单样本簇 | 只包含1个样本的簇 |
| 算法切换 | 从一种聚类算法更换到另一种 |
| 特征剔除 | 从候选聚类特征中排除某些列 |
| 维度灾难 | 高维特征空间中距离度量失效的现象 |

## 执行流程 (Workflow)

> **读取优先**：在开始分析前，必须先从上下文文件读取所有输入数据

### 步骤1：读取上下文数据

从prompt中获取上下文文件路径，读取JSON文件了解：
- 数据规模：`n_samples`, `n_features`, `dimension_ratio`
- 特征信息：`candidate_features`, `current_excluded`, `current_features`
- 上一轮结果：`prev_method`, `prev_params`
- 质量指标：`clustering_metrics`
- 簇统计：`cluster_stats`（包含n_clusters, single_sample_clusters, max_cluster_ratio, noise_ratio）
- 簇反馈：`cluster_gathered`（各簇的文本反馈）
- 历史记录：`algorithm_switch_history`, `iteration`

示例命令：
```bash
cat context/iteration_0_context.json
```

输出：确认数据已加载

### 步骤1.5：分析历史决策库

读取 `decision_history/decisions.jsonl`（如果文件存在），逐行解析JSON：
```bash
cat decision_history/decisions.jsonl
```

重点关注：
- `impact.effective = false` 的记录：这些参数组合已被证明无效，应避免重复
- `impact.f1_delta` 和 `impact.silhouette_delta`：了解哪些调整方向有效
- 相同 `data_signature` 下的历史决策：与当前数据规模相近的历史更具参考价值
- `before_decision_metric` vs `after_decision_metric`：决策前后的聚类效果对比

分析产出：
- 无效参数组合列表（需避免）
- 有效调整方向（可参考）
- 若无历史文件或文件为空，跳过此步骤

### 步骤2：分析数据特征

运行特征分析脚本：
```bash
python scripts/analyze_clustering_context.py --context context/iteration_X_context.json
```

脚本会输出JSON格式的分析报告，包含：
- **data_characteristics**: 样本数、特征维度、维度比、异常值占比
- **feature_quality**: 低方差特征索引、高相关特征对
- **recommendations**: 改进建议列表

基于分析报告，判断数据特征类型：
- 高维数据：dimension_ratio > 0.5
- 高噪声数据：avg_outlier_ratio > 0.1
- 低质量特征：存在低方差或高相关特征

输出：数据特征分类标签

### 步骤3：评估聚类质量

从上下文读取质量指标，对照阈值判断：

**质量等级判定**：
- ✅ **优秀**：silhouette > 0.5 AND davies_bouldin < 1.5 AND 单样本簇 < 10%
- ⚠️ **可接受**：silhouette > 0.3 AND davies_bouldin < 2.0 AND 单样本簇 < 30%
- ❌ **不佳**：低于可接受标准

**异常簇结构识别**：
- 单样本簇过多：single_sample_clusters / n_clusters > 0.3
- 欠聚类：max_cluster_ratio > 0.7
- 噪声过多：noise_ratio > 0.3（仅DBSCAN）

输出：质量等级 + 异常簇结构列表

### 步骤4：解读簇级反馈

分析 `cluster_gathered` 文本，提取关键信号：
- "需要细分"、"样本差异大" → 信号：增加簇数或切换算法
- "过度聚类"、"样本高度相似" → 信号：减少簇数
- "无共性pattern"、"噪声" → 信号：可能是噪声簇，考虑DBSCAN

统计问题簇占比：
```
问题簇比例 = (提到"需要细分"的簇数) / (总簇数)
```

输出：反馈解读摘要 + 问题簇占比

### 步骤5：算法选择决策

按决策树选择算法（详见 `references/algorithm-selection-guide.md`）：

**决策逻辑**：
```
1. 检查算法切换历史
   if 上一轮刚切换算法（iteration - last_switch_iteration == 1）:
       禁止切换，只能调参数
       跳转到步骤6

2. 检查质量是否足够好
   if 质量等级 == "优秀" AND 问题簇占比 < 0.3:
       保持当前算法，微调参数
       跳转到步骤6

3. 检查是否需要切换算法
   if 质量等级 == "不佳":
       if 当前算法 == kmeans AND 单样本簇 > 30%:
           切换到 dbscan（噪声鲁棒）
       elif 当前算法 == kmeans AND 簇反馈提示非凸结构:
           切换到 gaussian_mixture 或 spectral
       elif 当前算法 == dbscan AND 噪声比例 > 30%:
           切换到 gaussian_mixture（软聚类）
       elif 维度比 > 0.5 AND 样本数 < 5000:
           切换到 spectral（流形学习）
       else:
           保持当前算法，大幅调整参数

4. 默认
   保持当前算法，调整参数
```

**禁止切换的场景**：
- ❌ 连续两轮切换算法
- ❌ 质量已达"优秀"且问题簇 < 30%
- ❌ 切换到Spectral但样本数 > 5000

输出：选定算法名称 + 切换理由（如有）

### 步骤6：配置参数

根据选定算法，查阅对应的调参指南：
- K-Means: `references/kmeans-tuning-guide.md`
- DBSCAN: `references/dbscan-tuning-guide.md`
- Gaussian Mixture: `references/gaussian-mixture-tuning-guide.md`
- Spectral: `references/spectral-tuning-guide.md`

应用调参规则，生成参数配置。

**参数合法性检查**：
- 参数值必须在算法的ParamSpace定义范围内
- 簇数类参数（n_clusters/n_components）不得超过样本数的50%
- DBSCAN的eps建议使用自动建议值（基于k-distance图）

输出：参数配置字典

### 步骤7：特征选择建议（可选）

基于步骤2的特征分析报告，决定是否剔除特征：

**剔除触发条件**：
- 维度比 > 0.5（高维诅咒）
- 存在 > 5个低方差特征（var < 0.01）
- 存在 > 3对高相关特征（|corr| > 0.95）

**剔除策略**：
- 优先剔除低方差特征
- 在高相关特征对中保留方差较大的
- 剔除数量不得超过候选特征的50%

输出：exclude_features数组（可为空）

### 步骤8：生成结构化决策

按以下JSON格式输出最终决策：

```json
{
  "reasoning": "简要说明决策理由（200字以内）：为什么选择这个算法？参数如何调整？是否剔除特征？",
  "cluster_func_name": "kmeans|dbscan|gaussian_mixture|spectral",
  "params": {
    // 算法参数，根据cluster_func_name不同而不同
    // 例如 K-Means: {"n_clusters": 25, "init": "k-means++", "max_iter": 300}
  },
  "exclude_features": [],  // 可选，要剔除的特征列名数组
  "custom_features": [  // 可选，仅当人工先验存在时输出
    {"name": "自定义特征名", "components": {"原特征A": 0.5, "原特征B": 0.5}}
  ],
  "feature_weights": {  // 可选，仅当人工先验存在时输出
    "特征名": 2.0  // >1强调，<1弱化，默认1.0
  }
}
```

**输出要求**：
- 必须是严格的JSON格式，包裹在 ```json``` 代码块中
- reasoning字段必须清晰说明决策依据
- params必须符合所选算法的参数定义
- exclude_features如果为空可省略或保留空数组

## 输出格式 (Output Format)

**JSON Schema**：

```json
{
  "type": "object",
  "required": ["reasoning", "cluster_func_name", "params"],
  "properties": {
    "reasoning": {
      "type": "string",
      "maxLength": 500,
      "description": "决策推理过程，说明为什么选择该算法和参数"
    },
    "cluster_func_name": {
      "type": "string",
      "enum": ["kmeans", "dbscan", "gaussian_mixture", "spectral"],
      "description": "选择的聚类算法名称"
    },
    "params": {
      "type": "object",
      "description": "算法参数配置，结构取决于cluster_func_name"
    },
    "exclude_features": {
      "type": "array",
      "items": {"type": "string"},
      "description": "要从聚类中剔除的特征列名（可选）"
    },
    "custom_features": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["name", "components"],
        "properties": {
          "name": {"type": "string", "description": "自定义特征名称"},
          "components": {
            "type": "object",
            "additionalProperties": {"type": "number"},
            "description": "线性组合系数，key=原特征名 value=系数"
          }
        }
      },
      "description": "自定义组合特征（可选，仅当人工先验存在时输出）"
    },
    "feature_weights": {
      "type": "object",
      "additionalProperties": {"type": "number", "minimum": 0, "maximum": 10},
      "description": "特征重要性权重乘数（可选，仅当人工先验存在时输出，默认1.0）"
    }
  }
}
```

## 合规红线 (Constraints)

1. **禁止连续切换算法**：如果上一轮已切换算法（algorithm_switch_history），本轮只能调参数
2. **禁止过度剔除特征**：exclude_features不得超过candidate_features的50%
3. **禁止极端参数**：
   - K-Means: n_clusters ∈ [2, min(50, n_samples/10)]
   - DBSCAN: eps ∈ [0.01, 10.0], min_samples ∈ [2, min(50, n_samples/20)]
   - Gaussian Mixture: n_components ∈ [2, min(20, n_samples/10)]
   - Spectral: n_clusters ∈ [2, min(20, n_samples/10)]
4. **Spectral限制**：样本数 > 5000 时禁止选择Spectral（计算复杂度O(N³)）
5. **禁止无依据调参**：参数调整必须基于质量指标或簇反馈，不得随机试探
6. **禁止重复无效决策**：若某算法+参数组合在历史决策库中标记为 `effective=false`，禁止原样重用；如确需使用相近参数，必须在reasoning中说明本次条件有何不同
7. **禁止修改业务逻辑**：不得在reasoning中包含风控业务建议
8. **禁止访问非授权文件**：仅允许读取context/目录、decision_history/目录和references/目录

## 审计追踪 (Audit Trail)

每次决策执行后，主流程会自动保存审计日志：

```json
{
  "iteration": 0,
  "timestamp": "2026-07-24T10:30:00+08:00",
  "input_context": {
    "n_samples": 1000,
    "n_features": 50,
    "prev_method": "kmeans",
    "clustering_metrics": {...}
  },
  "decision": {
    "reasoning": "...",
    "cluster_func_name": "dbscan",
    "params": {...}
  },
  "validation_passed": true
}
```

## 示例 (Examples)

### 示例1：K-Means表现良好，微调参数

**输入上下文**：
```json
{
  "n_samples": 1000,
  "n_features": 30,
  "prev_method": "kmeans",
  "prev_params": {"n_clusters": 30, "max_iter": 300},
  "clustering_metrics": {
    "silhouette_score": 0.52,
    "davies_bouldin_score": 1.3
  },
  "cluster_stats": {
    "single_sample_clusters": 2,
    "max_cluster_ratio": 0.15
  },
  "cluster_gathered": "大部分簇样本同质性良好"
}
```

**输出决策**：
```json
{
  "reasoning": "上一轮K-Means表现优秀（silhouette=0.52 > 0.5），簇结构合理，仅2个单样本簇。保持算法不变，微调簇数至28以进一步优化。",
  "cluster_func_name": "kmeans",
  "params": {
    "n_clusters": 28,
    "init": "k-means++",
    "max_iter": 300,
    "n_init": 10
  }
}
```

### 示例2：K-Means出现大量单样本簇，切换到DBSCAN

**输入上下文**：
```json
{
  "n_samples": 800,
  "prev_method": "kmeans",
  "prev_params": {"n_clusters": 40},
  "clustering_metrics": {
    "silhouette_score": 0.28,
    "davies_bouldin_score": 2.5
  },
  "cluster_stats": {
    "n_clusters": 40,
    "single_sample_clusters": 15,
    "max_cluster_ratio": 0.25
  },
  "cluster_gathered": "多个簇反馈'无共性pattern'，疑似噪声"
}
```

**输出决策**：
```json
{
  "reasoning": "K-Means产生15个单样本簇（37.5%），质量不佳（silhouette=0.28），簇反馈显示存在噪声。切换到DBSCAN以自动识别噪声点和任意形状簇。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 0.5,
    "min_samples": 5,
    "metric": "euclidean"
  }
}
```

### 示例3：DBSCAN噪声过多，切换到Gaussian Mixture

**输入上下文**：
```json
{
  "n_samples": 1200,
  "prev_method": "dbscan",
  "prev_params": {"eps": 0.3, "min_samples": 5},
  "clustering_metrics": {
    "silhouette_score": 0.35,
    "noise_ratio": 0.35
  },
  "cluster_stats": {
    "n_clusters": 5,
    "noise_ratio": 0.35
  }
}
```

**输出决策**：
```json
{
  "reasoning": "DBSCAN识别出35%的噪声点，过多的样本被排除在有效簇之外。切换到Gaussian Mixture进行软聚类，允许不确定样本以概率形式分配到簇。",
  "cluster_func_name": "gaussian_mixture",
  "params": {
    "n_components": 8,
    "covariance_type": "full",
    "max_iter": 200,
    "tol": 0.001,
    "reg_covar": 0.000001
  }
}
```

## 非功能范围 (Out of Scope)

- 本Skill不执行实际的聚类计算（由主流程调用adaptive_clustering模块完成）
- 本Skill不分析业务数据内容（不解读企业财务、风控规则等）
- 本Skill不生成可视化图表（簇分布图、轮廓系数曲线等）
- 本Skill不执行特征工程（特征提取、降维等由预处理模块完成）
- 如果用户请求以上内容，明确告知超出本Skill范围
