# Spectral Clustering 调参指南

## 算法概述

Spectral Clustering通过谱分析识别复杂非凸结构，适用于流形数据。

**适用场景**：
- ✅ 复杂非凸结构（环形、交错螺旋）
- ✅ 流形数据（低维流形嵌入高维空间）
- ✅ 小规模数据（N < 5000，计算复杂度O(N³)）

**不适用场景**：
- ❌ 大规模数据（N > 5000）
- ❌ 计算资源受限

## 参数空间

### n_clusters（簇数）⭐⭐⭐⭐⭐

**范围**：[2, min(20, N/10)]
**调整**：与K-Means类似

### affinity（相似度度量）⭐⭐⭐

**选项**：['rbf', 'nearest_neighbors']
- rbf：高斯核（默认）
- nearest_neighbors：k近邻图

### gamma（RBF核参数）⭐⭐

**范围**：[0.1, 10.0]
**默认**：1.0

## 示例决策

```json
{
  "reasoning": "K-Means和DBSCAN均失败，数据呈现非凸结构。切换到Spectral，样本数N=1200 < 5000满足要求。",
  "cluster_func_name": "spectral",
  "params": {
    "n_clusters": 12,
    "affinity": "rbf",
    "gamma": 1.0
  }
}
```

## 重要约束

⚠️ **禁止选择Spectral当N > 5000**（计算时间过长）
