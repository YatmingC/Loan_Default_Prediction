# Gaussian Mixture 调参指南

## 算法概述

Gaussian Mixture Model（GMM）假设数据由多个高斯分布混合而成，提供软聚类（概率分配）。

**适用场景**：
- ✅ 簇形状椭圆形（不同协方差结构）
- ✅ 需要概率分配（边界样本不确定性）
- ✅ 可用BIC/AIC自动选择簇数
- ✅ 中等规模数据（N > 500）

**不适用场景**：
- ❌ 非高斯分布
- ❌ 计算资源受限（比K-Means慢）

## 参数空间

### n_components（高斯分量数）⭐⭐⭐⭐⭐

**范围**：[2, min(20, N/10)]
**建议**：使用BIC准则循环选择最优值

**调整规则**：
- BIC持续下降 → 可能过拟合，限制n_components
- 质量不佳 → 调整±20%

### covariance_type（协方差类型）⭐⭐⭐⭐

**选项**：['full', 'tied', 'diag', 'spherical']
- full：最灵活（默认）
- tied：所有簇共享协方差
- diag：假设特征独立
- spherical：各向同性（类似K-Means）

### 其他参数

- max_iter: [100, 1000]，默认200
- tol: [1e-6, 1e-3]，默认1e-3
- reg_covar: [1e-7, 1e-2]，默认1e-6

## 示例决策

```json
{
  "reasoning": "从DBSCAN切换，噪声点过多。使用Gaussian Mixture软聚类，n_components=8基于BIC估计。",
  "cluster_func_name": "gaussian_mixture",
  "params": {
    "n_components": 8,
    "covariance_type": "full",
    "max_iter": 200,
    "tol": 0.001,
    "reg_covar": 0.000001
  }
}
```
