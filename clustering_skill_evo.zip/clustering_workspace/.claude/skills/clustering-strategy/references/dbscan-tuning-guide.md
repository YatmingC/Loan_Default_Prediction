# DBSCAN 调参指南

## 算法概述

DBSCAN（Density-Based Spatial Clustering of Applications with Noise）是基于密度的聚类算法，能够发现任意形状的簇并自动识别噪声点。

**适用场景**：
- ✅ 簇形状任意（非凸、环形、月牙形等）
- ✅ 存在噪声点（可标记为label=-1）
- ✅ 簇大小不均匀
- ✅ 不知道簇数（算法自动确定）
- ✅ 中等规模数据（N < 10000）

**不适用场景**：
- ❌ 簇密度差异很大（难以找到统一的eps）
- ❌ 高维数据（D > 20，距离度量失效）
- ❌ 超大规模数据（N > 50000，计算慢）

## 参数空间

### eps（邻域半径）⭐⭐⭐⭐⭐ 最重要

**类型**：浮点数
**范围**：[0.01, 10.0]
**默认建议**：使用k-distance图自动估计（调用DBSCANClustering.suggest_eps）

**调整规则**：

| 质量问题 | 调整方向 | 调整幅度 | 理由 |
|---------|---------|---------|------|
| 噪声点 > 30% | 增加 | +20% ~ +30% | eps过小，密度阈值过严 |
| 只有1-2个大簇 | 减少 | -20% ~ -30% | eps过大，欠聚类 |
| 轮廓系数 < 0.3 | 微调±10% | 尝试优化 | 密度阈值不合适 |
| 单样本簇多 | 增加 | +15% ~ +20% | 边界样本被孤立 |

**自动建议值**：
```python
# 使用k-distance图法
from adaptive_clustering.core.clustering import DBSCANClustering
suggested_eps = DBSCANClustering.suggest_eps(feature_matrix, min_samples=5)
# 返回k-distance曲线拐点处的值
```

**调整示例**：
```python
# 上一轮：eps=0.5, 噪声点占比35%
# 问题：噪声过多 → eps过小
# 调整：增加25% → eps=0.625
```

**特殊情况**：
- 如果增加eps后仍噪声 > 30% → 数据可能本身噪声多，切换到Gaussian Mixture
- 如果减少eps后仍只有1-2簇 → 数据可能本身簇数少，切换到K-Means

### min_samples（最小样本数）⭐⭐⭐⭐

**类型**：整数
**范围**：[2, min(50, N/20)]
**默认建议**：max(5, D+1)，其中D为特征维度

**调整规则**：

| 场景 | 建议值 | 理由 |
|------|--------|------|
| 低维数据（D < 10） | 5 | 标准值 |
| 高维数据（D > 20） | 2*D | 高维空间需要更多邻居 |
| 高噪声数据（> 15%异常点） | D+3 ~ 2*D | 提高密度阈值 |
| 低噪声数据（< 5%异常点） | 3-5 | 降低密度阈值 |
| 小规模数据（N < 500） | 3-5 | 避免要求过严 |

**与eps的关系**：
- min_samples越大 → 密度要求越高 → 更多样本被标记为噪声
- min_samples越小 → 更宽松 → 可能产生单样本簇

**调整示例**：
```python
# 场景：D=30（高维），噪声点占比40%
# 上一轮：min_samples=5（太小）
# 调整：增加到2*D=60，但不超过N/20
# 输出：min_samples=min(60, N/20)
```

### metric（距离度量）⭐⭐

**类型**：字符串
**范围**：['euclidean', 'manhattan', 'cosine']
**默认建议**：'euclidean'

**选择规则**：

| 数据特征 | 推荐metric | 理由 |
|---------|-----------|------|
| 数值特征为主，已归一化 | euclidean | 标准选择 |
| 特征尺度差异大 | manhattan | 对异常值鲁棒 |
| 文本特征（TF-IDF等） | cosine | 关注方向而非长度 |
| 稀疏特征 | cosine | 忽略零值维度 |

**不要轻易改变**：
- 除非有明确理由（如特征类型变化），否则保持euclidean
- 改变metric相当于改变距离定义，影响巨大

## 调参策略

### 策略1：首次使用DBSCAN（从K-Means切换）

**场景**：K-Means出现大量单样本簇，决定切换到DBSCAN

**步骤**：
1. 使用suggest_eps自动估计eps
2. min_samples设为max(5, D+1)
3. metric保持euclidean
4. 观察噪声点占比和簇数

**示例决策**：
```json
{
  "reasoning": "K-Means产生15个单样本簇（37.5%）。切换到DBSCAN，使用k-distance图自动估计eps=0.52，min_samples=5。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 0.52,
    "min_samples": 5,
    "metric": "euclidean"
  }
}
```

### 策略2：调整噪声点占比

**场景**：DBSCAN已运行，但噪声点过多或过少

**步骤**：

**如果噪声点 > 30%**（过多）：
1. 增加eps（20-30%）
2. 或减少min_samples（如果 > 5）
3. 优先调整eps

**如果噪声点 < 5%但轮廓系数低**（可能噪声太少）：
1. 减少eps（10-15%）
2. 或增加min_samples
3. 让算法更严格地识别噪声

**示例决策**：
```json
{
  "reasoning": "噪声点占比35% > 30%，过多样本被排除。增加eps 25%以放宽密度要求。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 0.65,  // 从0.52增加到0.65
    "min_samples": 5,
    "metric": "euclidean"
  }
}
```

### 策略3：调整簇数

**场景**：DBSCAN簇数不合理（过多或过少）

**步骤**：

**如果只有1-2个大簇**（欠聚类）：
1. 减少eps（20-30%）
2. 让密度阈值更严格

**如果簇数 > N/10**（过度聚类）：
1. 增加eps（20-30%）
2. 合并密度接近的簇

**示例决策**：
```json
{
  "reasoning": "DBSCAN识别出3个簇，其中1个占比75%，欠聚类。减少eps 25%以细分大簇。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 0.45,  // 从0.6减少到0.45
    "min_samples": 5,
    "metric": "euclidean"
  }
}
```

### 策略4：高维数据特殊处理

**场景**：特征维度 > 20

**步骤**：
1. 增加min_samples到2*D
2. 考虑切换metric到manhattan或cosine
3. 如果仍效果不佳，建议主流程先降维

**示例决策**：
```json
{
  "reasoning": "特征维度D=35 > 20，存在维度灾难。增加min_samples到2*D=70，切换到manhattan距离以提高鲁棒性。建议主流程考虑降维。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 1.2,
    "min_samples": 70,
    "metric": "manhattan"
  },
  "exclude_features": []  // 可建议剔除低方差特征
}
```

## 常见问题与解决方案

### 问题1：噪声点过多（> 30%）

**症状**：
- label=-1的样本占比 > 30%
- 有效簇的样本数很少

**原因分析**：
1. eps设置过小，密度阈值过严
2. min_samples过大
3. 数据本身噪声多

**解决方案**：
1. 增加eps（20-30%）
2. 如果min_samples > 10，尝试减少到5-8
3. 如果调整后仍 > 30% → **切换到Gaussian Mixture**（软聚类处理不确定性）

### 问题2：只有1-2个大簇

**症状**：
- 识别出的簇数 < 5
- 最大簇占比 > 70%

**原因分析**：
1. eps设置过大，几乎所有样本都连通
2. 数据本身簇数少（这可能是合理的）

**解决方案**：
1. 减少eps（20-30%）
2. 如果减少后仍只有1-2簇，检查数据是否本身就是少簇
3. 如果数据确实应该有更多簇 → **切换回K-Means**

### 问题3：簇数过多（> N/10）

**症状**：
- 识别出的簇数非常多
- 很多小簇（< 10个样本）

**原因分析**：
1. eps过小，密度连通性差
2. 数据分布确实很分散

**解决方案**：
1. 增加eps（20-30%）
2. 如果仍过多 → 考虑切换到K-Means或Gaussian Mixture

### 问题4：参数难以调优

**症状**：
- 调整eps后，要么噪声过多，要么欠聚类
- 无法找到合适的参数平衡点

**原因分析**：
1. 簇密度差异很大（DBSCAN的致命弱点）
2. 高维数据（距离度量失效）

**解决方案**：
1. **切换到Gaussian Mixture**（可以处理不同密度的簇）
2. 或建议主流程先降维再聚类

### 问题5：轮廓系数低但噪声点占比正常

**症状**：
- silhouette < 0.3
- 噪声点占比10-20%（合理范围）
- 簇数也合理

**原因分析**：
1. 簇边界模糊
2. 簇形状复杂，DBSCAN也难以完美分离

**解决方案**：
1. 微调eps（±10-15%）
2. 如果仍低 → 切换到Spectral（更强的非凸能力）

## eps自动估计原理

DBSCAN提供了suggest_eps方法，基于k-distance图：

```python
def suggest_eps(data: np.ndarray, min_samples: int = 5) -> float:
    """
    1. 计算每个样本到第k近邻的距离（k = min_samples）
    2. 将这些距离排序，绘制k-distance曲线
    3. 找到曲线的"肘点"（拐点），即曲率最大处
    4. 该点的k-distance值即为建议的eps
    
    理论依据：
    - 肘点左侧：样本密集区域
    - 肘点右侧：样本稀疏区域或噪声
    - eps设在肘点，恰好分离密集簇和噪声
    """
```

**使用建议**：
- 首次使用DBSCAN时，使用suggest_eps作为初始值
- 后续微调时，在建议值基础上±20-30%调整

## 参数组合建议

### 标准场景（中等规模、低维）

```json
{
  "eps": "使用suggest_eps自动估计",
  "min_samples": 5,
  "metric": "euclidean"
}
```

### 高噪声场景

```json
{
  "eps": "suggest_eps * 0.8",  // 略小于建议值，更严格
  "min_samples": 8,  // 增加密度要求
  "metric": "euclidean"
}
```

### 高维场景（D > 20）

```json
{
  "eps": "suggest_eps * 1.2",  // 略大于建议值，高维距离膨胀
  "min_samples": "min(2*D, N/20)",  // 增加邻居数要求
  "metric": "manhattan"  // 对高维更鲁棒
}
```

### 文本特征场景

```json
{
  "eps": 0.3,  // cosine距离通常在[0, 2]范围，eps较小
  "min_samples": 5,
  "metric": "cosine"
}
```

## 调参检查清单

在输出DBSCAN参数前，确认：

- [ ] eps ∈ [0.01, 10.0]
- [ ] min_samples ∈ [2, min(50, N/20)]
- [ ] 首次使用时，eps基于suggest_eps估计
- [ ] 高维数据（D > 20）时，min_samples ≥ D+1
- [ ] metric选择有依据（特征类型）
- [ ] 如果预计噪声点 > 30%，应考虑切换到Gaussian Mixture

## 示例决策

### 示例1：首次从K-Means切换

**输入**：
- 上一轮K-Means：单样本簇15个（37.5%）
- 切换原因：过度聚类 + 疑似噪声

**输出**：
```json
{
  "reasoning": "K-Means产生大量单样本簇，切换到DBSCAN。使用k-distance图估计eps=0.48，min_samples=5。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 0.48,
    "min_samples": 5,
    "metric": "euclidean"
  }
}
```

### 示例2：噪声过多调整

**输入**：
- 上一轮DBSCAN：噪声点占比38%
- 问题：过多样本被排除

**输出**：
```json
{
  "reasoning": "噪声点38% > 30%，eps=0.5过小。增加eps 30%至0.65以放宽密度要求。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 0.65,
    "min_samples": 5,
    "metric": "euclidean"
  }
}
```

### 示例3：欠聚类调整

**输入**：
- 上一轮DBSCAN：识别出2个簇，最大簇占比80%
- 问题：欠聚类

**输出**：
```json
{
  "reasoning": "仅2个簇且最大簇占比80%，eps=0.8过大导致欠聚类。减少eps 30%至0.56以细分。",
  "cluster_func_name": "dbscan",
  "params": {
    "eps": 0.56,
    "min_samples": 5,
    "metric": "euclidean"
  }
}
```

### 示例4：无法调优，准备切换

**输入**：
- 已尝试3轮DBSCAN调参
- eps=0.4时噪声35%，eps=0.6时只有2簇
- 无法找到平衡点

**输出**：
```json
{
  "reasoning": "DBSCAN参数难以平衡（密度差异大），已尝试eps=0.4/0.5/0.6均不理想。切换到Gaussian Mixture以处理不同密度的簇。",
  "cluster_func_name": "gaussian_mixture",
  "params": {
    "n_components": 10,
    "covariance_type": "full",
    "max_iter": 200,
    "tol": 0.001,
    "reg_covar": 0.000001
  }
}
```
