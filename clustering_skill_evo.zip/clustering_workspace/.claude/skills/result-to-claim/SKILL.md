---
name: result-to-claim
description: "根据实验结果评估 idea 是否成立，输出结构化 verdict（supported/partial/unsupported）。在每轮迭代的 experiment 记录完成后调用。"
allowed-tools: Bash(*), Read, Write, Edit, Grep, Glob
---

# Result-to-Claim: 实验结果判定

## 概述

实验产生数据，本 skill 判定数据的含义。收集实验指标的 before/after 对比，综合过程信息，输出结构化的 verdict 判断，并写入 `research_wiki/claims/` 目录。

## 使用时机

- 每轮聚类迭代（外层）的指标汇总后
- 每个簇的 skill 演进（内层）完成后
- 当需要对某个 idea 的效果做出结论时

## 工作流程

### Step 1: 收集证据

从 prompt 中提取：
- **Idea 描述**: 本轮提出的假设/变更内容
- **实验指标**: before/after metrics 及 delta
- **过程信息**: clustering_analyse / pattern_collections / 模型反馈

### Step 2: 评估判断

基于收集到的证据，综合判断 idea 是否被实验结果支持：

**判断标准：**

| 条件 | Verdict |
|------|---------|
| 核心指标（F1）显著提升（delta > 0.05）且无明显副作用 | supported |
| 核心指标有提升但幅度有限（0 < delta <= 0.05），或有部分副作用 | partial |
| 核心指标无提升或下降 | unsupported |

**置信度标准：**

| 条件 | Confidence |
|------|------------|
| 指标变化方向一致，样本量充足，无混杂因素 | high |
| 指标变化存在但有不确定性 | medium |
| 样本量不足、混杂因素多、或指标矛盾 | low |

### Step 3: 输出结构化 Verdict

输出严格遵循以下 JSON Schema（`json_schemas/claim_result.json`）：

```json
{
  "verdict": "supported | partial | unsupported",
  "confidence": "high | medium | low",
  "claim_statement": "一句话陈述 claim",
  "evidence_for": "支持 idea 的证据",
  "evidence_against": "不支持 idea 的证据",
  "conclusion": "综合结论，200字以内"
}
```

### Step 4: 写入 Claim 页面

1. 生成 claim_id: `claim_<iteration_type>_iter<iteration>[_<cluster_label>_evo<evo_iter>]`
2. 将 verdict 结果写入 `research_wiki/claims/<claim_id>.md`，格式：

```markdown
---
type: claim
node_id: claim:<claim_id>
idea_ref: idea:<对应的 idea_id>
exp_ref: exp:<对应的 exp_id>
verdict: <verdict>
confidence: <confidence>
created: <ISO timestamp>
---

# Claim: <claim_statement>

## 判断结果
- verdict: <verdict>
- confidence: <confidence>

## 支持证据
<evidence_for>

## 反对证据
<evidence_against>

## 综合结论
<conclusion>
```

3. 追加 log.md：`[<timestamp>] claim — <claim_id>: verdict=<verdict>, confidence=<confidence>`
4. 重建 index.md（更新 Claims 分区）

### Step 5: 更新 Idea Outcome

根据 verdict 回写对应 idea 页面的 `outcome` 字段：
- `supported` → `positive`
- `partial` → `mixed`
- `unsupported` → `negative`

## 关键规则

- **诚实判断，不夸大**。数据不支持的 claim 不要标记为 supported
- **单一正面结果不构成通用结论**。如果只在少数样本或特定簇上有效，verdict 应为 partial
- **evidence_against 不能为空**。即使 verdict 是 supported，也要指出可能的局限性
- **conclusion 控制在 200 字以内**，简明扼要
- **verdict 只基于指标数据**，不基于 agent 的主观描述
- **所有文件使用 UTF-8 编码**
