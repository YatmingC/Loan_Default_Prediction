---
name: research-wiki
description: "持久化研究知识库，记录自适应聚类迭代过程中的 idea（假设/变更）、experiment（实验指标）、claim（结论判断）。通过文件写入维护 research_wiki/ 目录。"
allowed-tools: Bash(*), Read, Write, Edit, Grep, Glob
---

# Research Wiki: 自适应聚类迭代知识库

## 概述

Research Wiki 是一个持久化的、按迭代积累的知识库，记录自适应聚类系统每轮迭代中的关键信息：
- **Idea**: 每轮迭代提出的假设或变更（聚类算法选择、参数调整、skill prompt 修改等）
- **Experiment**: 实验结果和指标数据
- **Claim**: 基于实验结果对 idea 的判断（supported / partial / unsupported）

## Wiki 目录结构

```
research_wiki/
  index.md              # 分类索引（每次写入后重建）
  log.md                # 追加式时间线
  ideas/                # 每个 idea 一个 .md 文件
  experiments/          # 每个 experiment 一个 .md 文件
  claims/               # 每个 claim 一个 .md 文件
```

## 实体格式

### Idea 页面 (`ideas/<idea_id>.md`)

```markdown
---
type: idea
node_id: idea:<idea_id>
iteration_type: clustering | skill_evo
iteration: <int>
cluster_label: <string | null>
evo_iter: <int | null>
created: <ISO timestamp>
outcome: pending | positive | mixed | negative
---

# <idea 标题>

## 假设描述
[从 agent reasoning / pattern_collections / 决策描述中提取的结构化假设]

## 变更内容
[具体做了什么变更：算法切换、参数调整、skill prompt 修改等]

## 预期效果
[期望这个变更带来什么改善]
```

### Experiment 页面 (`experiments/<exp_id>.md`)

```markdown
---
type: experiment
node_id: exp:<exp_id>
idea_ref: idea:<idea_id>
iteration_type: clustering | skill_evo
iteration: <int>
cluster_label: <string | null>
evo_iter: <int | null>
created: <ISO timestamp>
---

# Experiment: <exp_id>

## 关联 Idea
idea:<idea_id>

## 指标数据

| 指标 | Before | After | Delta |
|------|--------|-------|-------|
| f1   | ...    | ...   | ...   |
| precision | ... | ... | ...  |
| recall | ...  | ...   | ...   |

## 聚类指标（仅 clustering 类型）

| 指标 | 值 |
|------|----|
| silhouette_score | ... |
| composite_score  | ... |
| n_clusters       | ... |

## 过程信息
[clustering_analyse / 模型反馈汇总]
```

### Claim 页面 (`claims/<claim_id>.md`)

```markdown
---
type: claim
node_id: claim:<claim_id>
idea_ref: idea:<idea_id>
exp_ref: exp:<exp_id>
verdict: supported | partial | unsupported
confidence: high | medium | low
created: <ISO timestamp>
---

# Claim: <一句话陈述>

## 判断结果
- verdict: supported | partial | unsupported
- confidence: high | medium | low

## 支持证据
[evidence_for]

## 反对证据
[evidence_against]

## 综合结论
[conclusion, 200字以内]
```

## 工作流程

当收到 `record_iteration` 操作时，按以下步骤执行：

### Step 1: 解析输入上下文

从 prompt 中提取：
- 迭代类型（clustering / skill_evo）
- 迭代编号、簇标签、演进轮次
- Idea 原始信息（agent reasoning / pattern_collections / 决策描述）
- 实验指标（before / after metrics）
- 过程信息

### Step 2: 生成 Idea 页面

1. 生成 idea_id: `<iteration_type>_iter<iteration>[_<cluster_label>_evo<evo_iter>]`
2. 从原始信息中**提取并结构化** idea 描述（不要原样复制，要提炼假设和变更要点）
3. 写入 `research_wiki/ideas/<idea_id>.md`

### Step 3: 生成 Experiment 页面

1. 生成 exp_id: 与 idea_id 对应，前缀 `exp_`
2. 将指标数据格式化为 before/after 对比表格
3. 写入 `research_wiki/experiments/<exp_id>.md`

### Step 4: 追加 log.md

格式：`[<ISO timestamp>] <操作类型> — <简要描述>`

示例：
```
[2026-08-31T10:30:00] record_iteration — clustering iter 0: idea=切换到DBSCAN, exp=f1 0.65→0.72
[2026-08-31T10:35:00] record_iteration — skill_evo iter 0 cluster_3 evo 1: idea=修正逾期判断逻辑, exp=f1 0.55→0.78
```

### Step 5: 重建 index.md

按实体类型分类索引所有已有的 ideas / experiments / claims，格式：

```markdown
# Research Wiki Index

## Ideas
- [idea:clustering_iter0](ideas/clustering_iter0.md) — 切换到DBSCAN算法 (pending)
- [idea:skill_evo_iter0_cluster_3_evo1](ideas/skill_evo_iter0_cluster_3_evo1.md) — 修正逾期判断 (positive)

## Experiments
- [exp:exp_clustering_iter0](experiments/exp_clustering_iter0.md) — f1: 0.65→0.72
- ...

## Claims
- [claim:claim_clustering_iter0](claims/claim_clustering_iter0.md) — supported (high)
- ...
```

### Step 6: 输出 JSON 确认

完成所有文件写入后，输出以下 JSON 格式的确认信息（包裹在```json```代码块中）：

```json
{
  "idea_id": "idea:<生成的 idea_id>",
  "exp_id": "exp:<生成的 exp_id>",
  "summary": "简要描述本次记录内容"
}
```

## 关键规则

- **每次写入后必须重建 index.md**，确保索引与实际文件一致
- **log.md 只追加不覆盖**
- **Idea 描述要提炼结构化**，不要原样复制 agent 输出
- **指标表格要包含 before/after/delta**，便于一目了然
- **文件名使用小写+下划线**，与 node_id 保持一致
- **所有文件使用 UTF-8 编码**
