"""多算法自适应聚类的主流程（新版本）

与 main.py 的区别：
1. 支持多种聚类算法自动选择（K-Means/DBSCAN/Gaussian Mixture/Spectral）
2. 使用 clustering_strategy_skill 指导算法选择和参数调优
3. 记录算法切换历史，防止连续切换
4. 保持与 main.py 相同的目录结构和接口

使用方式：
    python main_multi_algo.py -i mock_data -o output --max_iterations 3
"""

import argparse
import json
import os
import pickle
import random
import shutil
import logging
from pathlib import Path
from datetime import datetime

from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)
logger.level = logging.DEBUG

BUSY_MAX_PARALLEL = 10  # 模型服务忙碌时间并发
IDLE_MAX_PARALLEL = 40  # 模型服务空闲时间并发
ACCEPT_THRESHOLD = 0.8

from src.utils_multi_algo import (
    dataload, clustering_func_multi_algo, build_feature_matrix,
    validation_skill, analyse_skill_result,
    interactive_agent, interactive_agent_send_message,
    run_agent, clean_agents,
    call_clustering_strategy_skill_v3,
    compute_cluster_statistics,
    clean_workspace, save_decision_record, backfill_last_decision_outcome,
    apply_clustering_priors,
    clean_agent_env, setup_provider
)
from src.tfgrpo_adapter import (
    validation_skill_multi_rollout,
    extract_experiences_from_rollouts,
    aggregate_cluster_experiences,
    majority_vote,
    build_rollout_groups,
)
from src.prompt_template import render
from adaptive_clustering.core.clustering.metrics import compute_all_clustering_metrics
import numpy as np


def get_score(answer_list, label_list):
    if len(answer_list) != len(label_list):
        raise ValueError("answer_list 和 label_list 长度必须相同")

    TP = FP = FN = TN = 0
    correct_ids = []
    error_ids = []

    for idx, (ans, lbl) in enumerate(zip(answer_list, label_list)):
        ans_stripped = ans.strip()
        if ans_stripped.endswith("是"):
            pred = 1
        elif ans_stripped.endswith("否"):
            pred = 0
        else:
            error_ids.append(idx)
            continue

        if pred == lbl:
            correct_ids.append(idx)
        else:
            error_ids.append(idx)

        if lbl == 1:
            if pred == 1:
                TP += 1
            else:
                FN += 1
        else:
            if pred == 1:
                FP += 1
            else:
                TN += 1

    precision = TP / (TP + FP) if (TP + FP) > 0 else 0.0
    recall = TP / (TP + FN) if (TP + FN) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "correct_ids": correct_ids,
        "error_ids": error_ids
    }


def construct_validation_prompt(data_line):
    return render("validation_prompt.j2", data_line=data_line)


def load_rubric(file_path):
    """读取 rubric 文件内容，# 开头的行视为注释不注入。文件不存在或为空则返回空字符串。"""
    path = Path(file_path)
    if not path.exists():
        return ""
    content = path.read_text(encoding="utf-8").strip()
    if not content:
        return ""
    lines = content.split("\n")
    non_comment_lines = [l for l in lines if not l.startswith("#") and l.strip()]
    return "\n".join(non_comment_lines).strip()


EVALUATION_RUBRIC_PATH = Path(__file__).parent / "rubrics" / "evaluation_rubric.md"
UPDATE_RUBRIC_PATH = Path(__file__).parent / "rubrics" / "update_rubric.md"
CLUSTERING_PRIOR_PATH = Path(__file__).parent / "rubrics" / "clustering_prior.md"


def construct_feedback_prompt(data_line):
    return render("feedback_prompt.j2", data_line=data_line, evaluation_rubric=load_rubric(EVALUATION_RUBRIC_PATH))


def parse_args():
    parser = argparse.ArgumentParser(description="多算法自适应聚类主流程")
    parser.add_argument("-i", "--input", type=str, required=True, help="输入数据目录")
    parser.add_argument("-o", "--output", type=str, required=True, help="输出目录")
    parser.add_argument("--max_iterations", type=int, default=2, help="最大迭代轮次")
    parser.add_argument("--max_skill_evo_iterations", type=int, default=2, help="每簇最大skill演进轮次")
    parser.add_argument("--harness_provider", type=str, default="claude", choices=["opencode", "codex", "claude"],
                       help="harness provider (claude/codex/opencode)")
    parser.add_argument("--model_provider", type=str, default="glm-5.1",
                       help="model provider (glm-5.1, deepseek-v4-flash, etc.)")
    parser.add_argument("--clustering_workspace", type=str, default="./clustering_workspace",
                       help="聚类策略工作空间目录")
    parser.add_argument("--tfgrpo_enabled", action="store_true",
                       help="启用 TFGRPO 机制（多 rollout + 三分法经验提取）")
    parser.add_argument("--num_rollouts", type=int, default=3,
                       help="每样本 rollout 次数（仅 --tfgrpo_enabled 时生效）")
    args = parser.parse_args()
    return args


def get_max_parallel():
    from datetime import datetime, time
    from zoneinfo import ZoneInfo

    busy_max_parallel = BUSY_MAX_PARALLEL
    idle_max_parallel = IDLE_MAX_PARALLEL
    # 模型忙碌开始时间(即模型空闲结束时间)07:30-2:00(预测耗时2h)=05:30
    busy_start_time_schedule = {
        "hour": 5,
        "minute": 30
    }
    # 模型忙碌结束时间(模型空闲开始时间)18:30
    busy_end_time_schedule = {
        "hour": 18,
        "minute": 30
    }

    if os.path.exists("model_parallel_config.json"):    
        with open("model_parallel_config.json", "r", encoding="utf-8") as f:
            model_parallel_config = json.load(f)

            busy_max_parallel = model_parallel_config["parallel_config"]["busy_max_parallel"]
            idle_max_parallel = model_parallel_config["parallel_config"]["idle_max_parallel"]

            busy_start_time_schedule["hour"] = model_parallel_config["time_config"]["busy_start_time"]["hour"]
            busy_start_time_schedule["minute"] = model_parallel_config["time_config"]["busy_start_time"]["minute"]

            busy_end_time_schedule["hour"] = model_parallel_config["time_config"]["busy_end_time"]["hour"]
            busy_end_time_schedule["minute"] = model_parallel_config["time_config"]["busy_end_time"]["minute"]
    
    china_tz = ZoneInfo("Asia/Shanghai")
    now = datetime.now(china_tz).time()  # 获取当前时间（仅时分秒）
    busy_start_time = time(busy_start_time_schedule["hour"], busy_start_time_schedule["minute"]) 
    busy_end_time = time(busy_end_time_schedule["hour"], busy_end_time_schedule["minute"])       

    if busy_start_time <= now <= busy_end_time:
        logger.info(f"time {now=} max_parallel_size={busy_max_parallel}")
        return busy_max_parallel
    else:
        logger.info(f"time {now=} max_parallel_size={idle_max_parallel}")
        return idle_max_parallel

def main():
    args = parse_args()

    # init：重启 paseo 环境 + 设置 provider
    clean_agent_env()

    setup_provider(harness_provider=args.harness_provider, model_provider=args.model_provider)
    logger.info(f"current using harness: {args.harness_provider=} model: {args.model_provider=}")

    # harness 对应的 skill 目录名（claude/codex → .claude，opencode → .opencode）
    skill_dir = ".opencode" if args.harness_provider == "opencode" else ".claude"

    # 验证clustering_workspace存在
    workspace_dir = Path(args.clustering_workspace)
    skills_dir = workspace_dir / skill_dir / "skills" / "clustering-strategy"
    if not skills_dir.exists():
        raise FileNotFoundError(
            f"聚类策略Skill不存在: {skills_dir}\n"
            f"请先运行: python scripts/setup_clustering_workspace.py"
        )

    # 清理workspace旧产物（保留skills/，可以修改添加自定义保留目录）
    clean_workspace(str(workspace_dir))

    # 确保 research_wiki 目录存在
    wiki_dir = workspace_dir / "research_wiki"
    wiki_dir.mkdir(exist_ok=True)
    for subdir in ["ideas", "experiments", "claims"]:
        (wiki_dir / subdir).mkdir(exist_ok=True)

    # 生成本次运行唯一标识
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")

    logger.info("="*80)
    logger.info("多算法自适应聚类系统 v1.0")
    logger.info(f"输入目录: {args.input}")
    logger.info(f"输出目录: {args.output}")
    logger.info(f"聚类工作空间: {args.clustering_workspace}")
    logger.info("="*80)

    # 数据加载
    data = dataload(
        data_path=os.path.join(args.input, "sampled_test_data_add_prompt.xlsx"),
        columns_desc_path=os.path.join(args.input, "columns_description.xlsx")
    )

    cluster_agent_id = None

    # 初始聚类配置（首轮使用默认K-Means）
    cluster_algo = {
        "cluster_func_name": "kmeans",
        "n_clusters": 30
    }
    excluded_features = []
    custom_features = None
    feature_weights = None
    algorithm_switch_history = []  # 记录算法切换历史

    # 用于 research wiki 记录的上下文变量
    prev_iteration_metrics = None  # 上一轮的聚类指标（before_metrics）
    prev_decision_reasoning = "初始默认配置：kmeans(n_clusters=30)"  # 上一轮的决策描述
    prev_cluster_gathered = ""  # 上一轮的簇分析汇总（process_info）

    column_configs = data["column_configs"]
    candidate_features = data["candidate_features"]
    raw_df = data["df"]

    # 写入初始默认配置记录（iteration=-1）
    initial_record = {
        "run_id": run_id,
        "iteration": -1,
        "timestamp": datetime.now().isoformat(),
        "data_signature": {"n_samples": len(raw_df), "n_features": len(candidate_features)},
        "decision": {
            "algorithm": "kmeans",
            "params": {"n_clusters": 30},
            "excluded_features": [],
            "reasoning": "初始默认配置（未经Agent决策）"
        },
        "before_decision_metric": None,
        "after_decision_metric": None,
        "impact": None
    }
    save_decision_record(str(workspace_dir), initial_record)
    logger.info("已记录初始聚类配置: kmeans(n_clusters=30)")

    for iteration in range(args.max_iterations):
        logger.info("="*80)
        logger.info(f"迭代 {iteration}/{args.max_iterations - 1} 开始")
        logger.info("="*80)

        os.makedirs(os.path.join(args.output, f"iteration_{iteration}"), exist_ok=True)
        project_dir = os.path.join(args.output, f"iteration_{iteration}")

        # 提取算法名和参数
        cluster_func_name = cluster_algo.pop("cluster_func_name")
        cluster_algo.pop("exclude_features", None)  # 移除非算法参数
        algorithm_params = cluster_algo

        # 构建特征矩阵
        excluded_set = set(excluded_features)
        active_features = [c for c in candidate_features if c not in excluded_set]
        logger.info(f"活跃特征: {len(active_features)}/{len(candidate_features)}, 剔除: {excluded_features}")

        feature_matrix, feature_names = build_feature_matrix(
            raw_df, column_configs, active_features, label_column="Default"
        )

        # 应用聚类先验（自定义特征 + 特征权重）
        if custom_features or feature_weights:
            feature_matrix, feature_names = apply_clustering_priors(
                feature_matrix, feature_names,
                custom_features=custom_features,
                feature_weights=feature_weights,
            )
            logger.info(f"已应用聚类先验: {len(custom_features or [])} 个自定义特征, "
                       f"{len(feature_weights or {})} 个特征权重")

        # 执行聚类
        logger.info(f"执行聚类: {cluster_func_name}, 参数: {algorithm_params}")
        cluster_result = clustering_func_multi_algo(
            method=cluster_func_name,
            algorithm_params=algorithm_params,
            feature_matrix=feature_matrix,
            raw_dataframe=data["raw_dataframe"]
        )

        # 计算质量指标
        labels = cluster_result["labels"]
        feat_np = np.array(feature_matrix, dtype=float)
        labels_np = np.array(labels)
        clustering_metrics = {}
        n_clusters = len(set(labels) - {-1})

        if n_clusters >= 2:
            try:
                metrics_obj = compute_all_clustering_metrics(feat_np, labels_np)
                clustering_metrics = metrics_obj.model_dump()
            except Exception as e:
                logger.warning(f"聚类指标计算失败: {e}")
        else:
            logger.info(f"簇数={n_clusters}，聚类指标不可用")

        # 记录噪声点统计（DBSCAN特有）
        noise_count = labels.count(-1)
        if noise_count > 0:
            noise_ratio = noise_count / len(labels)
            logger.info(f"DBSCAN识别噪声点: {noise_count} ({noise_ratio:.1%})")
            clustering_metrics["noise_ratio"] = noise_ratio
        else:
            clustering_metrics["noise_ratio"] = 0.0

        # 计算簇统计
        cluster_stats = compute_cluster_statistics(labels)
        logger.info(f"簇统计: n_clusters={cluster_stats['n_clusters']}, "
                   f"single_sample_clusters={cluster_stats['single_sample_clusters']}, "
                   f"max_cluster_ratio={cluster_stats['max_cluster_ratio']:.2%}, "
                   f"noise_ratio={cluster_stats['noise_ratio']:.2%}")

        # 保存模型
        logger.info(f"保存聚类模型到 {project_dir}/model.pkl")
        with open(os.path.join(project_dir, "model.pkl"), "wb") as f:
            pickle.dump(cluster_result["model"], f)

        # ========== 簇级skill演进（与main.py相同）==========
        for cluster_label, cluster_samples in zip(
            cluster_result["cluster_labels"],
            cluster_result["cluster_samples"]
        ):
            logger.info(f"处理 {cluster_label}: {cluster_samples['n_samples']}个样本")

            pre_compute_score = get_score(
                [sample["reasoning"] for sample in cluster_samples["samples"]],
                [sample["Default"] for sample in cluster_samples["samples"]]
            )

            logger.info(f"{pre_compute_score["precision"]=} {pre_compute_score["recall"]=} {pre_compute_score["f1"]=}")
            if pre_compute_score["f1"] > ACCEPT_THRESHOLD:
                logger.info(f"F1={pre_compute_score['f1']:.3f} > {ACCEPT_THRESHOLD}, 跳过演进")
                continue

            logger.info(f"F1={pre_compute_score['f1']:.3f} < {ACCEPT_THRESHOLD}, 检查正样本...")

            positive_samples = list(filter(lambda sample: sample["Default"] == 1, cluster_samples["samples"]))
            negative_samples = list(filter(lambda sample: sample["Default"] == 0, cluster_samples["samples"]))

            # 1:1采样
            if len(positive_samples) == 0:
                logger.info(f"{cluster_label}: 无正样本，跳过演进")
                continue
            else:
                choices_negative_samples = random.sample(
                    negative_samples,
                    min(len(positive_samples), len(negative_samples))
                )

            # 确认需要演进，创建目录
            logger.info(f"{cluster_label}: 开始skill演进")
            os.makedirs(os.path.join(project_dir, cluster_label), exist_ok=True)
            cluster_dir = os.path.join(project_dir, cluster_label)
            os.makedirs(os.path.join(cluster_dir, ".cache"), exist_ok=True)

            all_samples = positive_samples + choices_negative_samples
            logger.info(f"{cluster_label}: {len(positive_samples)}个正样本 + {len(choices_negative_samples)}个负样本")

            for i, sample in enumerate(all_samples):
                all_samples[i]["validation_prompt"] = construct_validation_prompt(sample)

            agent_id = None
            # 用于 research wiki 记录的上下文变量（内圈迭代）
            # wiki 记录的语义：当前轮验证的是"上一轮产生的 idea"
            # evo_iter=0 验证的是"初始skill"（对比不用skill的直推结果）
            # evo_iter=N 验证的是 evo_iter=N-1 产生的 pattern
            prev_evo_score = pre_compute_score
            prev_evo_pattern = "初始skill（default_skill/skills/post-loan-management）"

            for skill_evo_iter in range(args.max_skill_evo_iterations):
                # 关键隔离措施：只复制风控skill，不复制聚类skill
                # 复制到 cluster_dir/<skill_dir>/ 下，供 claude / paseo 自动发现
                if skill_evo_iter == 0:
                    os.makedirs(os.path.join(cluster_dir, skill_dir), exist_ok=True)
                    shutil.copytree(
                        "./default_skill/",
                        os.path.join(cluster_dir, skill_dir),
                        dirs_exist_ok=True
                    )

                if args.tfgrpo_enabled:
                    # ===== TFGRPO 流程：多 rollout 验证 =====
                    all_rollout_results = validation_skill_multi_rollout(
                        cluster_dir,
                        prompt_list=[render("validation_skill_wrapper.j2", prompt=sample["validation_prompt"]) for sample in all_samples],
                        num_rollouts=args.num_rollouts,
                        max_parallel_size=get_max_parallel()
                    )
                    # paseo 无法支持大并发，并发交由 claude cli 启动会话完成
                    # clean_agents([cluster_agent_id, agent_id])

                    voted_results = [majority_vote(rollouts) for rollouts in all_rollout_results]
                    for i, sample in enumerate(all_samples):
                        all_samples[i]["validation_result"] = voted_results[i]

                    score_result = get_score(
                        [sample["validation_result"]["risk_result"] for sample in all_samples],
                        [sample["Default"] for sample in all_samples],
                    )
                else:
                    # ===== 原流程：单次验证 =====
                    all_validation_result = validation_skill(
                        cluster_dir,
                        prompt_list=[sample["validation_prompt"] for sample in all_samples],
                        max_parallel_size=get_max_parallel()
                    )
                    # paseo 无法支持大并发，并发交由 claude cli 启动会话完成
                    # clean_agents([cluster_agent_id, agent_id])

                    for i, sample in enumerate(all_samples):
                        all_samples[i]["validation_result"] = all_validation_result[i]

                    score_result = get_score(
                        [sample["validation_result"]["risk_result"] for sample in all_samples],
                        [sample["Default"] for sample in all_samples],
                    )

                precision = score_result["precision"]
                recall = score_result["recall"]
                f1 = score_result["f1"]
                logger.info(f"{cluster_label} skill_evo={skill_evo_iter}: precision={precision:.3f}, recall={recall:.3f}, f1={f1:.3f}")

                if args.tfgrpo_enabled:
                    # ===== TFGRPO 流程：三分法经验提取 + 聚合 =====
                    rollout_groups = build_rollout_groups(all_samples, all_rollout_results)

                    skill_path = Path(cluster_dir) / skill_dir / "skills" / "post-loan-management" / "SKILL.md"
                    current_skill = skill_path.read_text(encoding="utf-8") if skill_path.exists() else ""

                    per_sample_exp = extract_experiences_from_rollouts(
                        iteration_dir=cluster_dir,
                        rollout_groups=rollout_groups,
                        skill_summary=current_skill[:2000],
                        max_parallel_size=get_max_parallel(),
                    )

                    merge_result = aggregate_cluster_experiences(
                        per_sample_experiences=per_sample_exp,
                        current_skill_content=current_skill[:3000],
                        iteration_dir=cluster_dir,
                    )

                    cluster_samples["pattern_collections"] = merge_result["pattern_collections"]
                    cluster_samples["clustering_analyse"] = merge_result.get("clustering_analyse", "")
                    cluster_samples["tfgrpo_experiences"] = per_sample_exp

                else:
                    # ===== 原流程：逐样本分析 + 归并 =====
                    for i, sample in enumerate(all_samples):
                        all_samples[i]["skill_feedback_prompt"] = construct_feedback_prompt(sample)

                    # 簇skill结果分析
                    all_analyse_result = analyse_skill_result(
                        cluster_dir,
                        prompt_list=[sample["skill_feedback_prompt"] for sample in all_samples],
                        max_parallel_size=get_max_parallel()
                    )
                    # paseo 无法支持大并发，并发交由 claude cli 启动会话完成
                    # clean_agents([cluster_agent_id, agent_id])

                    for i, sample in enumerate(all_samples):
                        all_samples[i]["skill_analyse_result"] = all_analyse_result[i]

                    # 簇skill结果分析汇总 & 簇聚类效果分析
                    merge_prompt = render("merge_summary_prompt.j2", samples=all_samples)
                    merge_result = run_agent(
                        cluster_dir,
                        output_schema_path=Path(__file__).parent / "json_schemas/merge_result.json",
                        prompt=merge_prompt,
                        parser=lambda x: x
                    )

                    cluster_samples["pattern_collections"] = merge_result["pattern_collections"]
                    cluster_samples["clustering_analyse"] = merge_result["clustering_analyse"]

                # 早停检查：F1达标则跳过skill更新
                early_stop = f1 >= ACCEPT_THRESHOLD
                if early_stop:
                    logger.info(f"{cluster_label} F1={f1:.3f} >= {ACCEPT_THRESHOLD}, skill已达标，跳过更新")
                else:
                    # 更新skill
                    update_skill_msg = render("update_skill_prompt.j2", pattern_collections=merge_result['pattern_collections'], update_rubric=load_rubric(UPDATE_RUBRIC_PATH))
                    if agent_id is None:
                        agent_id = interactive_agent(cluster_dir, update_skill_msg)["agent_id"]
                    else:
                        interactive_agent_send_message(agent_id, "/compact")
                        interactive_agent_send_message(agent_id, update_skill_msg, cwd=cluster_dir)

                # 缓存（无论是否早停都保存）
                with open(Path(cluster_dir) / f".cache/{skill_evo_iter}.json", "w", encoding="utf-8") as f:
                    json.dump(cluster_samples, f, ensure_ascii=False)
                shutil.copytree(
                    Path(cluster_dir) / skill_dir / "skills" / "post-loan-management",
                    Path(cluster_dir) / f".cache/{skill_evo_iter}_post-loan-management",
                    dirs_exist_ok=True
                )

                # ========== 记录当前 skill 演进迭代到 research wiki ==========
                # 时序语义：当前轮验证的是"上一轮产生的 idea"
                #   evo_iter=0: idea=初始skill, before=pre_compute(不用skill直推), after=score_0
                #   evo_iter=N: idea=pattern_{N-1}, before=score_{N-1}, after=score_N
                try:
                    wiki_prompt = render("research_wiki_prompt.j2",
                        iteration_type="skill_evo",
                        iteration=iteration,
                        cluster_label=cluster_label,
                        evo_iter=skill_evo_iter,
                        idea_source=prev_evo_pattern,
                        metrics={"precision": score_result["precision"], "recall": score_result["recall"], "f1": score_result["f1"]},
                        before_metrics={"precision": prev_evo_score["precision"], "recall": prev_evo_score["recall"], "f1": prev_evo_score["f1"]},
                        after_metrics={"precision": score_result["precision"], "recall": score_result["recall"], "f1": score_result["f1"]},
                        process_info=""
                    )
                    wiki_ack = run_agent(str(workspace_dir),
                        output_schema_path=Path(__file__).parent / "json_schemas/wiki_record_ack.json",
                        prompt=wiki_prompt, parser=lambda x: x)
                    logger.info(f"research wiki 记录完成 (iter={iteration}, cluster={cluster_label}, evo={skill_evo_iter}): {wiki_ack.get('summary', '')}")

                    claim_prompt = render("result_to_claim_prompt.j2",
                        iteration_type="skill_evo",
                        iteration=iteration,
                        cluster_label=cluster_label,
                        evo_iter=skill_evo_iter,
                        idea_description=prev_evo_pattern,
                        before_metrics={"precision": prev_evo_score["precision"], "recall": prev_evo_score["recall"], "f1": prev_evo_score["f1"]},
                        after_metrics={"precision": score_result["precision"], "recall": score_result["recall"], "f1": score_result["f1"]},
                        delta={"f1": round(score_result["f1"] - prev_evo_score["f1"], 4),
                               "precision": round(score_result["precision"] - prev_evo_score["precision"], 4),
                               "recall": round(score_result["recall"] - prev_evo_score["recall"], 4)},
                        process_info=""
                    )
                    claim_result = run_agent(str(workspace_dir),
                        output_schema_path=Path(__file__).parent / "json_schemas/claim_result.json",
                        prompt=claim_prompt, parser=lambda x: x)
                    logger.info(f"skill_evo claim (iter={iteration}, cluster={cluster_label}, evo={skill_evo_iter}): verdict={claim_result['verdict']}, confidence={claim_result['confidence']}")
                except Exception as e:
                    logger.warning(f"research wiki skill_evo 记录失败（不影响主流程）: {e}")

                # 更新上下文变量：当前轮的 pattern 和 score 成为下一轮的 "prev"
                prev_evo_pattern = merge_result["pattern_collections"]
                prev_evo_score = score_result

                # 早停：退出演进循环
                if early_stop:
                    break

            clean_agents([cluster_agent_id])

        # ========== 聚类策略调整（核心差异）==========
        cluster_gathered = "\n\n".join([
            sample.get('clustering_analyse') or '当前簇正常，无需调整'
            for sample in cluster_result["cluster_samples"]
        ])

        # 计算总指标
        answer_list = []
        gt_list = []
        for cluster_samples in cluster_result["cluster_samples"]:
            for sample in cluster_samples["samples"]:
                if "validation_result" in sample:
                    answer_list.append(sample["validation_result"]["risk_result"])
                else:
                    answer_list.append(sample["reasoning"])
                gt_list.append(sample["Default"])
        all_score = get_score(answer_list, gt_list)

        logger.info(f"迭代 {iteration} 总体评分: precision={all_score['precision']:.3f}, "
                   f"recall={all_score['recall']:.3f}, f1={all_score['f1']:.3f}")

        # 当前轮的聚类指标（after_metrics）
        current_iteration_metrics = {
            "clustering_metrics": clustering_metrics,
            "cluster_stats": cluster_stats,
            "overall_f1": all_score["f1"]
        }

        # 回填上一轮决策的结果到 decision_history（现在本轮聚类和评分已完成）
        backfill_last_decision_outcome(str(workspace_dir), current_iteration_metrics)

        # ========== 记录聚类迭代到 research wiki ==========
        # 记录的是上一轮产生的决策在本轮的执行效果
        # before_metrics: 上一轮指标, after_metrics: 当前轮指标
        try:
            # 如果是第一轮且没有 prev_iteration_metrics，使用当前指标作为 baseline
            before_metrics_for_wiki = prev_iteration_metrics if prev_iteration_metrics is not None else {
                "clustering_metrics": {},
                "cluster_stats": {},
                "overall_f1": 0.0
            }

            wiki_prompt = render("research_wiki_prompt.j2",
                iteration_type="clustering",
                iteration=iteration,
                cluster_label=None,
                evo_iter=None,
                idea_source=prev_decision_reasoning,  # 上一轮的决策描述
                metrics=current_iteration_metrics,
                before_metrics=before_metrics_for_wiki,  # 上一轮的指标
                after_metrics=current_iteration_metrics,  # 当前轮的指标
                process_info=prev_cluster_gathered
            )
            wiki_ack = run_agent(str(workspace_dir),
                output_schema_path=Path(__file__).parent / "json_schemas/wiki_record_ack.json",
                prompt=wiki_prompt, parser=lambda x: x)
            logger.info(f"research wiki clustering 记录完成 (iter={iteration}): {wiki_ack.get('summary', '')}")

            # 计算 delta
            prev_f1 = before_metrics_for_wiki.get("overall_f1", 0.0)
            current_f1 = current_iteration_metrics["overall_f1"]
            f1_delta = round(current_f1 - prev_f1, 4)

            claim_prompt = render("result_to_claim_prompt.j2",
                iteration_type="clustering",
                iteration=iteration,
                cluster_label=None,
                evo_iter=None,
                idea_description=prev_decision_reasoning,  # 上一轮的决策描述
                before_metrics=before_metrics_for_wiki,
                after_metrics=current_iteration_metrics,
                delta={"overall_f1": f1_delta},
                process_info=prev_cluster_gathered
            )
            claim_result = run_agent(str(workspace_dir),
                output_schema_path=Path(__file__).parent / "json_schemas/claim_result.json",
                prompt=claim_prompt, parser=lambda x: x)
            logger.info(f"clustering claim (iter={iteration}): verdict={claim_result['verdict']}, confidence={claim_result['confidence']}, f1_delta={f1_delta}")
        except Exception as e:
            logger.warning(f"research wiki clustering 记录失败（不影响主流程）: {e}")

        # 调用聚类策略skill，生成下一轮的决策
        clustering_prior = load_rubric(CLUSTERING_PRIOR_PATH)
        logger.info(f"调用clustering_strategy_skill进行算法选择...")
        try:
            cluster_decision = call_clustering_strategy_skill_v3(
                iteration=iteration,
                context={
                    "n_samples": len(labels),
                    "n_features": len(feature_names),
                    "dimension_ratio": len(feature_names) / len(labels) if len(labels) > 0 else 0,
                    "candidate_features": candidate_features,
                    "current_excluded": excluded_features,
                    "current_features": active_features,
                    "feature_matrix": feature_matrix,  # 会被单独保存为.npy
                    "prev_method": cluster_func_name,
                    "prev_params": algorithm_params,
                    "clustering_metrics": clustering_metrics,
                    "cluster_stats": cluster_stats,
                    "cluster_gathered": cluster_gathered,
                    "iteration": iteration,
                    "algorithm_switch_history": algorithm_switch_history
                },
                workspace_dir=args.clustering_workspace,
                clustering_prior=clustering_prior
            )
        except Exception as e:
            logger.error(f"聚类策略skill调用失败: {e}")
            logger.warning("回退到默认策略：保持当前算法，微调参数")
            # 简单回退策略
            cluster_decision = {
                "reasoning": f"Skill调用失败，保持{cluster_func_name}算法",
                "cluster_func_name": cluster_func_name,
                "params": algorithm_params
            }

        logger.info(f"Agent决策: {cluster_decision['reasoning']}")
        logger.info(f"选择算法: {cluster_decision['cluster_func_name']}")
        logger.info(f"参数配置: {cluster_decision['params']}")

        # 检测算法切换
        new_algorithm = cluster_decision["cluster_func_name"]
        if new_algorithm != cluster_func_name:
            algorithm_switch_history.append({
                "from": cluster_func_name,
                "to": new_algorithm,
                "iteration": iteration
            })
            logger.info(f"算法切换: {cluster_func_name} → {new_algorithm}")

        # 更新下一轮配置
        cluster_algo = {
            "cluster_func_name": new_algorithm,
            **cluster_decision["params"]
        }

        if "exclude_features" in cluster_decision:
            excluded_features = cluster_decision["exclude_features"]
            logger.info(f"更新特征剔除: {excluded_features}")

        # 更新聚类先验字段
        custom_features = cluster_decision.get("custom_features")
        feature_weights = cluster_decision.get("feature_weights")
        if custom_features or feature_weights:
            logger.info(f"更新聚类先验: custom_features={len(custom_features or [])}, "
                       f"feature_weights={len(feature_weights or {})}")

        # 写入历史决策库（JSONL追加，outcome留空待下轮回填）
        history_record = {
            "run_id": run_id,
            "iteration": iteration,
            "timestamp": datetime.now().isoformat(),
            "data_signature": {"n_samples": len(labels), "n_features": len(feature_names)},
            "decision": {
                "algorithm": cluster_decision["cluster_func_name"],
                "params": cluster_decision["params"],
                "excluded_features": cluster_decision.get("exclude_features", []),
                "reasoning": cluster_decision.get("reasoning", "")
            },
            "before_decision_metric": {
                "clustering_metrics": clustering_metrics,
                "cluster_stats": cluster_stats,
                "prev_f1": all_score["f1"]
            },
            "after_decision_metric": None,
            "impact": None
        }
        save_decision_record(str(workspace_dir), history_record)

        # 更新上下文变量，供下一轮使用
        prev_iteration_metrics = current_iteration_metrics
        prev_decision_reasoning = cluster_decision.get("reasoning", "")
        prev_cluster_gathered = cluster_gathered

        logger.info(f"迭代 {iteration} 完成\n")

    logger.info("="*80)
    logger.info("所有迭代完成！")
    logger.info(f"输出目录: {args.output}")
    logger.info(f"算法切换历史: {algorithm_switch_history}")
    logger.info("="*80)


if __name__ == "__main__":
    main()
    clean_agent_env()
