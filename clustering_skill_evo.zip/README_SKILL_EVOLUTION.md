# Skill 自演进 Inner Loop

每个 F1 < 0.8 的 cluster 最多迭代 2 轮（`max_skill_evo_iterations`）。

## 步骤总览

| 步骤 | 做什么 | 使用的 Prompt 模板 |
|------|--------|-------------------|
| 1. Skill 验证 | 用当前 skill 对 cluster 样本逐条做风险判定 | `validation_skill_wrapper.j2` |
| 2. 计算得分 | 对比 ground truth 计算 precision/recall/F1 | 无模板（纯 Python 逻辑） |
| 3. 错误分析 | 逐条分析 skill 判对/判错的原因 | `feedback_prompt.j2` + `analyse_skill_wrapper.j2` |
| 4. 模式归纳 | 汇总所有样本的分析结果，提炼错误模式 + 聚类反馈 | `merge_summary_prompt.j2` |
| 5. Skill 更新 | 根据归纳的模式修改 skill prompt | `update_skill_prompt.j2` |

## 数据流

```
验证(Step1) → 打分(Step2) → [F1≥0.8则提前终止] → 错误分析(Step3) → 模式归纳(Step4) → 更新Skill(Step5) → 下一轮迭代
```

## 各步骤详细说明

### Step 1: Skill 验证

- **函数**: `validation_skill()` (`src/utils.py`)
- **并行方式**: `run_agent_parallel()` 逐样本并行调用
- **输出 schema**: `json_schemas/validation_schema.json` → `{"risk_reason": string, "risk_result": boolean}`
- **结果**: 存入 `sample["validation_result"]`

### Step 2: 计算得分

- **函数**: `get_score()` (`main_multi_algo.py`)
- **逻辑**: 解析回答中的"是"/"否"，与 ground truth 对比计算 precision/recall/F1
- **提前终止**: F1 >= 0.8 时跳过 Step 3-5，结束迭代

### Step 3: 错误分析

- **函数**: `analyse_skill_result()` (`src/utils.py`)
- **并行方式**: `run_agent_parallel()` 逐样本并行调用
- **Prompt 构造**: `construct_feedback_prompt()` 生成包含原始 prompt + skill 推理过程 + ground truth 的反馈请求
- **输出 schema**: `json_schemas/analyse_skill_schema.json` → `{"analysis": string}`（<100字的错误模式描述）
- **结果**: 存入 `sample["skill_analyse_result"]`

### Step 4: 模式归纳

- **函数**: `run_agent()` 单次调用
- **输入**: 所有样本的 `skill_analyse_result`
- **输出 schema**: `json_schemas/merge_result.json` → `{"pattern_collections": string, "clustering_analyse": string}`
- **结果**: `pattern_collections`（错误/正确模式总结）+ `clustering_analyse`（聚类质量反馈）

### Step 5: Skill 更新

- **函数**: `interactive_agent()` / `interactive_agent_send_message()`
- **调用方式**: interactive session 多轮对话
  - 首次迭代（iter=0）: 通过 `interactive_agent()` 创建新 session
  - 后续迭代: 通过 `interactive_agent_send_message()` 复用 session（带 `/compact`）
- **输入**: Step 4 的 `pattern_collections`
- **效果**: 直接修改 `cluster_dir/skills/post-loan-management/SKILL.md`

## Rubric 注入接口

系统支持通过 rubric 文件注入业务约束，影响 skill 自演进过程。文件不存在或内容为空时按原样执行，不影响流程。

### 文件说明

| 文件 | 注入阶段 | 作用 |
|------|----------|------|
| `rubrics/evaluation_rubric.md` | Step 3（错误分析） | 业务维度的评价标准，指导 agent 按照特定维度判断 skill 的对错 |
| `rubrics/update_rubric.md` | Step 5（Skill 更新） | 方向性约束，指导 agent 在修改 skill prompt 时不偏离业务意图 |

### evaluation_rubric.md（Step 3 评价标准）

- **注入位置**: `templates/feedback_prompt.j2` 中，在"你需要依据该企业真实违约情况…"之前
- **读取方式**: `load_rubric(EVALUATION_RUBRIC_PATH)` → 传入模板变量 `evaluation_rubric`
- **效果**: 告诉错误分析 agent "按照这些业务维度去判断 skill 的对错"
- **示例内容**:
  ```
  - 逾期超过90天的客户无论其他指标如何都应判为高风险
  - 担保不足的客户应优先判定为违约倾向
  ```

### update_rubric.md（Step 5 更新约束）

- **注入位置**: `templates/update_skill_prompt.j2` 中，在 Patterns 之前
- **读取方式**: `load_rubric(UPDATE_RUBRIC_PATH)` → 传入模板变量 `update_rubric`
- **效果**: 告诉 skill 更新 agent "修改时必须遵循这些方向性约束"
- **示例内容**:
  ```
  - 不得降低对担保不足客户的风险敏感度
  - 修改后的 skill 必须保持对逾期客户的高召回率
  ```

### 使用方式

1. 在 `rubrics/` 目录下编辑对应文件，填入业务约束内容（markdown 格式）
2. 文件中以 `#` 开头的行会被自动过滤（视为注释）
3. 文件不存在或过滤后内容为空 → 模板中对应 rubric 区块不渲染，流程不受影响

## 关键工具函数

| 函数 | 位置 | 用途 |
|------|------|------|
| `validation_skill()` | `src/utils.py` | 批量验证当前 skill |
| `analyse_skill_result()` | `src/utils.py` | 批量错误/正确分析 |
| `run_agent()` | `src/utils.py` | 单次结构化 agent 调用（带 schema 校验 + 重试） |
| `run_agent_parallel()` | `src/utils.py` | 并行批量 agent 调用 |
| `interactive_agent()` | `src/utils.py` | 创建 interactive session |
| `interactive_agent_send_message()` | `src/utils.py` | 向已有 session 发送消息 |
| `interactive_agent_send_and_get()` | `src/utils.py` | 发送消息并获取回复 |

## 聚类先验接口

系统支持通过先验文件向聚类策略 skill 注入人工先验知识，影响特征权重和自定义特征组合。文件不存在或内容为空时按原样执行，不影响流程。

### 文件说明

| 文件 | 作用 |
|------|------|
| `rubrics/clustering_prior.md` | 自然语言描述的聚类先验（特征重要性、自定义特征组合） |

### 工作原理

1. `load_rubric(CLUSTERING_PRIOR_PATH)` 读取先验文件内容
2. 内容注入到 `call_clustering_strategy_skill_v3()` 的 prompt 中（`## 人工聚类先验` 段）
3. clustering-strategy skill 根据先验输出两个可选字段：
   - `custom_features`：自定义特征（原有特征的线性组合）
   - `feature_weights`：特征权重乘数（>1 强调，<1 弱化）
4. `apply_clustering_priors()` 在 `build_feature_matrix()` 之后对特征矩阵执行变换：
   - 按 `feature_weights` 缩放对应列
   - 按 `custom_features` 计算线性组合并追加为新列
5. 变换后的矩阵传入聚类算法

### 数据流

```
rubrics/clustering_prior.md (用户编写自然语言)
        ↓ load_rubric()
   注入 clustering-strategy skill prompt
        ↓ skill 输出
   custom_features + feature_weights (结构化JSON)
        ↓ apply_clustering_priors()
   特征矩阵变换（权重缩放 + 新列追加）
        ↓
   聚类算法执行
```

### 使用方式

1. 编辑 `rubrics/clustering_prior.md`，用自然语言描述先验知识
2. 以 `#` 开头的行为注释，会被自动过滤
3. 文件不存在或过滤后内容为空 → 不注入先验，skill 不输出新字段，流程不受影响

### 先验文件示例

```markdown
## 特征重要性
- "资产负债率" 是最重要的聚类维度，权重应为 3 倍
- "营业收入增长率" 重要性较低，权重 0.5 倍

## 自定义特征组合
- 将 "流动比率" 和 "速动比率" 等权组合为流动性综合评分
- 用 "资产负债率"（负向）+ "净利润率"（正向）构建财务健康度指标
```
