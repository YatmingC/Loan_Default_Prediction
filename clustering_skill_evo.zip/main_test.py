import argparse
import json
import os
import asyncio
import pandas as pd
import shutil
import logging
from pathlib import Path

from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)

MAX_PARALLEL = 30
ACCEPT_THRESHOLD = 0.8
sem = asyncio.Semaphore(MAX_PARALLEL)

from src.utils import dataload, clustering_func, validation_skill, analyse_skill_result, interactive_agent, interactive_agent_send_message, run_agent, clean_agents

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", type=str, required=True, help="input file dir")
    parser.add_argument("-o", "--output", type=str, required=True, help="output file dir")

    parser.add_argument("--max_iterations", type=int, default=3, help="max iterations")
    parser.add_argument("--max_skill_evo_iterations", type=int, default=2, help="max iterations")
    args = parser.parse_args()
    return args


def construct_validation_prompt(data_line):
    return (f"一期金融风控模型分析现状：\n\n "
            f"prompt:\n{data_line['prompt']}\nreasoning:\n{data_line['reasoning']}\n"
            f"answer:\n{data_line['answer']}\n\n")

def construct_feedback_prompt(data_line):
    return (f"一期金融风控模型分析现状：\n\n "
            f"prompt:\n{data_line['prompt']}\n"
            f"answer:\n{data_line['answer']}\n"
            f"一期模型分析结果用户反馈：\n{data_line['feedback']}\n\n"
            f"二期金融风控skill分析结论：\n{data_line['validation_result']['risk_reason']}\n\n"
            f"该企业真实违约情况(是：违约，否：未违约)：\n{data_line['Default']}"
            )

import time
def main():
    args = parse_args()

    data = pd.read_excel(os.path.join(args.input, "test_data.xlsx"))
    clean_agents([])

    for i in range(99999):
        clean_agents([])
        start_time = time.time()
        validation_skill("./output", prompt_list=[construct_validation_prompt(sample) for i, sample in data.iterrows()], max_parallel_size=MAX_PARALLEL)
        end_time = time.time()
        print(f"run {len(data)=} cost {end_time-start_time}")

if __name__ == "__main__":
    main()