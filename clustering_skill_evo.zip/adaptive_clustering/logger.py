"""统一日志配置模块

为项目提供带有时间戳的标准化 logger，替代 print 输出。
"""

import logging
import sys

# 日志格式：时间戳 | 级别 | 模块名 | 消息
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str | None = None, level: int = logging.INFO) -> logging.Logger:
    """获取配置好的 logger 实例。

    Args:
        name: logger 名称，通常传 __name__ 即可。
        level: 日志级别，默认 INFO。

    Returns:
        配置了带时间戳格式输出的 Logger 实例。
    """
    logger = logging.getLogger(name)

    # 避免重复添加 handler（多次调用 get_logger 时）
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            logging.Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
        )
        logger.addHandler(handler)

    logger.setLevel(level)
    # 防止日志向上层传播导致重复输出
    logger.propagate = False
    return logger
