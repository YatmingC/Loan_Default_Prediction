"""谱聚类方法

使用SpectralClustering算法对金融风控数据进行聚类，支持超参数调优。
"""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.cluster import SpectralClustering as SKLearnSpectralClustering

from adaptive_clustering.core.clustering.base import BaseClusteringMethod
from adaptive_clustering.core.clustering.param_space import ParamSpace


class SpectralClusteringMethod(BaseClusteringMethod):
    """谱聚类方法

    基于图论的聚类方法，适合处理非凸形状的簇。
    每个聚类方法即一个skill的承载者。

    可调参数：
    - n_clusters: 簇数量 (2-20)
    - affinity: 亲和度计算方式 ('rbf', 'nearest_neighbors')
    - gamma: RBF核系数 (0.001-100.0)
    - n_neighbors: 近邻数 (3-30)
    - assign_labels: 标签分配方式 ('kmeans', 'discretize')

    Attributes:
        name: 方法名称
        params: 当前参数
    """

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        """初始化谱聚类

        Args:
            params: 聚类参数，默认n_clusters=3
        """
        default_params: dict[str, Any] = {
            "n_clusters": 3,
            "affinity": "rbf",
            "gamma": 1.0,
            "n_neighbors": 10,
            "assign_labels": "kmeans",
        }
        if params:
            default_params.update(params)
        super().__init__(name="spectral", params=default_params)

    def fit(self, data: np.ndarray) -> tuple[np.ndarray, dict[str, Any]]:
        """执行谱聚类

        Args:
            data: 输入特征矩阵，shape=(n_samples, n_features)

        Returns:
            tuple[np.ndarray, dict[str, Any]]: (聚类标签, 附加信息)
        """
        n_clusters = int(self.params.get("n_clusters", 3))
        n_clusters = min(n_clusters, len(data))

        model_kwargs: dict[str, Any] = {
            "n_clusters": n_clusters,
            "assign_labels": self.params.get("assign_labels", "kmeans"),
            "random_state": 42,
        }

        affinity = self.params.get("affinity", "rbf")
        model_kwargs["affinity"] = affinity

        if affinity == "rbf":
            model_kwargs["gamma"] = float(self.params.get("gamma", 1.0))
        elif affinity == "nearest_neighbors":
            model_kwargs["n_neighbors"] = int(self.params.get("n_neighbors", 10))

        model = SKLearnSpectralClustering(**model_kwargs)
        labels = model.fit_predict(data)

        # 谱聚类没有cluster_centers_，计算各簇均值作为中心
        cluster_centers = self._compute_cluster_centers(data, labels)

        extra_info: dict[str, Any] = {
            "cluster_centers": cluster_centers,
            "affinity_matrix_shape": (
                model.affinity_matrix_.shape if hasattr(model, "affinity_matrix_") else None
            ),
            "model": model,
        }

        return labels, extra_info

    def _compute_cluster_centers(
        self, data: np.ndarray, labels: np.ndarray
    ) -> np.ndarray:
        """计算各簇的中心点（均值）

        Args:
            data: 特征矩阵
            labels: 聚类标签

        Returns:
            np.ndarray: 各簇中心，shape=(n_clusters, n_features)
        """
        unique_labels = sorted(set(labels.tolist()) - {-1})
        centers = []
        for label in unique_labels:
            mask = labels == label
            center = data[mask].mean(axis=0)
            centers.append(center)
        return np.array(centers) if centers else np.empty((0, data.shape[1]))

    def get_param_space(self) -> ParamSpace:
        """获取谱聚类参数搜索空间

        Returns:
            ParamSpace: 参数搜索空间定义
        """
        return (
            ParamSpace()
            .add_range("n_clusters", 2, 20, step=1)
            .add_choice("affinity", ["rbf", "nearest_neighbors"])
            .add_range("gamma", 0.001, 100.0, log_scale=True)
            .add_range("n_neighbors", 3, 30, step=1)
            .add_choice("assign_labels", ["kmeans", "discretize"])
        )
