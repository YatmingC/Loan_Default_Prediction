"""KMeans聚类方法

使用KMeans算法对金融风控数据进行聚类，支持超参数调优。
"""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.cluster import KMeans as SKLearnKMeans

from adaptive_clustering.core.clustering.base import BaseClusteringMethod
from adaptive_clustering.core.clustering.param_space import ParamSpace


class KMeansClustering(BaseClusteringMethod):
    """KMeans聚类方法

    每个聚类方法即一个skill的承载者。

    可调参数：
    - n_clusters: 簇数量 (2-20)
    - init: 初始化方法 ('k-means++', 'random')
    - n_init: 初始化次数 (1-20)
    - max_iter: 最大迭代次数 (100-1000)
    - tol: 收敛阈值 (1e-6 ~ 1e-2)

    Attributes:
        name: 方法名称
        params: 当前参数
    """

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        """初始化KMeans聚类

        Args:
            params: 聚类参数，默认n_clusters=3
        """
        default_params: dict[str, Any] = {
            "n_clusters": 3,
            "init": "k-means++",
            "n_init": 10,
            "max_iter": 300,
            "tol": 1e-4,
        }
        if params:
            default_params.update(params)
        super().__init__(name="kmeans", params=default_params)

    def fit(self, data: np.ndarray) -> tuple[np.ndarray, dict[str, Any]]:
        """执行KMeans聚类

        Args:
            data: 输入特征矩阵，shape=(n_samples, n_features)

        Returns:
            tuple[np.ndarray, dict[str, Any]]: (聚类标签, 附加信息含cluster_centers)
        """
        n_clusters = int(self.params.get("n_clusters", 3))
        n_clusters = min(n_clusters, len(data))

        model = SKLearnKMeans(
            n_clusters=n_clusters,
            init=self.params.get("init", "k-means++"),
            n_init=int(self.params.get("n_init", 10)),
            max_iter=int(self.params.get("max_iter", 300)),
            tol=float(self.params.get("tol", 1e-4)),
            random_state=42,
        )
        labels = model.fit_predict(data)

        extra_info: dict[str, Any] = {
            "cluster_centers": model.cluster_centers_,
            "inertia": float(model.inertia_),
            "n_iter": int(model.n_iter_),
            "model": model
        }

        return labels, extra_info

    def get_param_space(self) -> ParamSpace:
        """获取KMeans参数搜索空间

        Returns:
            ParamSpace: 参数搜索空间定义
        """
        return (
            ParamSpace()
            .add_range("n_clusters", 2, 20, step=1)
            .add_choice("init", ["k-means++", "random"])
            .add_range("n_init", 1, 20, step=1)
            .add_range("max_iter", 100, 1000, step=100)
            .add_range("tol", 1e-6, 1e-2, log_scale=True)
        )
