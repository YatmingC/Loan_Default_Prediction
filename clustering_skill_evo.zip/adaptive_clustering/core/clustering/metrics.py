"""聚类质量指标计算

提供Silhouette、Calinski-Harabasz和Davies-Bouldin三种聚类质量指标的计算。
"""

from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    calinski_harabasz_score,
    davies_bouldin_score,
    silhouette_score,
)

from adaptive_clustering.core.models.metrics import ClusteringMetrics


def compute_silhouette(data: np.ndarray, labels: np.ndarray) -> float:
    """计算轮廓系数（Silhouette Score）

    取值范围[-1, 1]，越大表示聚类效果越好。

    Args:
        data: 特征矩阵，shape=(n_samples, n_features)
        labels: 聚类标签，shape=(n_samples,)

    Returns:
        float: 轮廓系数值
    """
    unique_labels = set(labels.tolist()) - {-1}
    if len(unique_labels) < 2:
        return 0.0
    # 过滤掉噪声点
    mask = labels != -1
    if np.sum(mask) < 2:
        return 0.0
    try:
        return float(silhouette_score(data[mask], labels[mask]))
    except Exception:
        return 0.0


def compute_calinski_harabasz(data: np.ndarray, labels: np.ndarray) -> float:
    """计算Calinski-Harabasz指数

    值越大表示聚类效果越好。

    Args:
        data: 特征矩阵，shape=(n_samples, n_features)
        labels: 聚类标签，shape=(n_samples,)

    Returns:
        float: CH指数值
    """
    unique_labels = set(labels.tolist()) - {-1}
    if len(unique_labels) < 2:
        return 0.0
    mask = labels != -1
    if np.sum(mask) < 2:
        return 0.0
    try:
        return float(calinski_harabasz_score(data[mask], labels[mask]))
    except Exception:
        return 0.0


def compute_davies_bouldin(data: np.ndarray, labels: np.ndarray) -> float:
    """计算Davies-Bouldin指数

    值越小表示聚类效果越好。

    Args:
        data: 特征矩阵，shape=(n_samples, n_features)
        labels: 聚类标签，shape=(n_samples,)

    Returns:
        float: DB指数值
    """
    unique_labels = set(labels.tolist()) - {-1}
    if len(unique_labels) < 2:
        return 0.0
    mask = labels != -1
    if np.sum(mask) < 2:
        return 0.0
    try:
        return float(davies_bouldin_score(data[mask], labels[mask]))
    except Exception:
        return float("inf")


def compute_all_clustering_metrics(
    data: np.ndarray, labels: np.ndarray
) -> ClusteringMetrics:
    """计算所有聚类质量指标

    同时计算silhouette、CH和DB三种指标，并计算综合得分。

    Args:
        data: 特征矩阵，shape=(n_samples, n_features)
        labels: 聚类标签，shape=(n_samples,)

    Returns:
        ClusteringMetrics: 包含所有指标的聚类质量评估结果
    """
    silhouette = compute_silhouette(data, labels)
    ch = compute_calinski_harabasz(data, labels)
    db = compute_davies_bouldin(data, labels)

    n_valid_clusters = len(set(labels.tolist()) - {-1})
    n_noise = int(np.sum(labels == -1))

    metrics = ClusteringMetrics(
        silhouette_score=silhouette,
        calinski_harabasz_score=ch,
        davies_bouldin_score=db,
        n_clusters=n_valid_clusters,
        n_noise=n_noise,
    )
    metrics.compute_composite_score()
    return metrics
