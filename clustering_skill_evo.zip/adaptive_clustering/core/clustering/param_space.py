"""参数搜索空间定义

定义聚类算法的参数搜索空间，支持连续范围、离散选择和条件参数。
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ParamRange(BaseModel):
    """连续参数范围

    用于定义在[min_val, max_val]范围内搜索的连续参数。

    Attributes:
        name: 参数名称
        min_val: 最小值
        max_val: 最大值
        step: 搜索步长（0表示由搜索策略决定）
        log_scale: 是否使用对数尺度搜索
    """

    name: str = Field(..., description="参数名称")
    min_val: float = Field(..., description="最小值")
    max_val: float = Field(..., description="最大值")
    step: float = Field(default=0.0, ge=0.0, description="搜索步长")
    log_scale: bool = Field(default=False, description="是否使用对数尺度")

    def generate_values(self, n_points: int = 10) -> list[float]:
        """生成搜索值列表

        Args:
            n_points: 生成值的数量

        Returns:
            list[float]: 参数值列表
        """
        import numpy as np

        if self.log_scale:
            values = np.logspace(
                np.log10(self.min_val), np.log10(self.max_val), n_points
            )
        else:
            values = np.linspace(self.min_val, self.max_val, n_points)

        if self.step > 0:
            values = np.arange(self.min_val, self.max_val + self.step, self.step)
            values = values[values <= self.max_val]

        return [round(float(v), 6) for v in values]

    def to_json_schema_property(self) -> dict[str, Any]:
        """生成该维度对应的 JSON Schema 属性片段

        Returns:
            dict[str, Any]: JSON Schema 的属性定义
        """
        is_int_grid = (
            self.step >= 1
            and float(self.min_val).is_integer()
            and float(self.max_val).is_integer()
            and float(self.step).is_integer()
        )
        if is_int_grid:
            schema: dict[str, Any] = {
                "type": "integer",
                "minimum": int(self.min_val),
                "maximum": int(self.max_val),
                "multipleOf": int(self.step),
            }
        else:
            schema = {
                "type": "number",
                "minimum": self.min_val,
                "maximum": self.max_val,
            }
        description = f"{self.name} 的取值范围 [{self.min_val}, {self.max_val}]"
        if self.log_scale:
            description += "（对数尺度搜索）"
        schema["description"] = description
        return schema

    def contains(self, value: Any) -> bool:
        """检查值是否在范围内

        Args:
            value: 待检查的值

        Returns:
            bool: 是否在 [min_val, max_val] 范围内
        """
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return False
        return self.min_val <= float(value) <= self.max_val


class ParamChoice(BaseModel):
    """离散参数选择

    用于定义在固定候选值中选择的参数。

    Attributes:
        name: 参数名称
        choices: 候选值列表
    """

    name: str = Field(..., description="参数名称")
    choices: list[Any] = Field(..., min_length=1, description="候选值列表")

    def to_json_schema_property(self) -> dict[str, Any]:
        """生成该维度对应的 JSON Schema 属性片段

        类型推断：
            - 全部 bool → "boolean"
            - 全部 int 且无 bool → "integer"
            - 全部 int|float（数值）→ "number"
            - 全部 str → "string"
            - 其他（混合 / 含 None）→ 不写 type，仅给 enum

        Returns:
            dict[str, Any]: JSON Schema 的属性定义
        """
        choices = list(self.choices)
        schema: dict[str, Any] = {"enum": choices}

        all_bool = all(isinstance(c, bool) for c in choices)
        all_int = all(isinstance(c, int) and not isinstance(c, bool) for c in choices)
        all_num = all(
            isinstance(c, (int, float)) and not isinstance(c, bool) for c in choices
        )
        all_str = all(isinstance(c, str) for c in choices)

        if all_bool:
            schema["type"] = "boolean"
        elif all_int:
            schema["type"] = "integer"
        elif all_num:
            schema["type"] = "number"
        elif all_str:
            schema["type"] = "string"
        # 其他情况：保留纯 enum，不写 type

        schema["description"] = f"{self.name} 的候选值"
        return schema

    def contains(self, value: Any) -> bool:
        """检查值是否在候选列表中

        对全数值候选（不含 bool）做一次 float 容错比较，避免 1 != 1.0。

        Args:
            value: 待检查的值

        Returns:
            bool: 是否合法
        """
        if value in self.choices:
            return True
        if isinstance(value, bool):
            return False
        if isinstance(value, (int, float)):
            numeric_choices = [
                c for c in self.choices
                if isinstance(c, (int, float)) and not isinstance(c, bool)
            ]
            if numeric_choices and len(numeric_choices) == len(self.choices):
                try:
                    return any(float(c) == float(value) for c in numeric_choices)
                except (TypeError, ValueError):
                    return False
        return False


class ParamSpace(BaseModel):
    """参数搜索空间

    由多个参数维度（ParamRange和ParamChoice）组成的搜索空间。

    Attributes:
        dimensions: 参数维度列表
    """

    dimensions: list[ParamRange | ParamChoice] = Field(
        default_factory=list, description="参数维度列表"
    )

    def add_range(
        self,
        name: str,
        min_val: float,
        max_val: float,
        step: float = 0.0,
        log_scale: bool = False,
    ) -> ParamSpace:
        """添加连续参数范围

        Args:
            name: 参数名称
            min_val: 最小值
            max_val: 最大值
            step: 搜索步长
            log_scale: 是否使用对数尺度

        Returns:
            ParamSpace: self，支持链式调用
        """
        self.dimensions.append(
            ParamRange(
                name=name, min_val=min_val, max_val=max_val, step=step, log_scale=log_scale
            )
        )
        return self

    def add_choice(self, name: str, choices: list[Any]) -> ParamSpace:
        """添加离散参数选择

        Args:
            name: 参数名称
            choices: 候选值列表

        Returns:
            ParamSpace: self，支持链式调用
        """
        self.dimensions.append(ParamChoice(name=name, choices=choices))
        return self

    def to_json_schema(
        self,
        extra_properties: dict[str, dict[str, Any]] | None = None,
        extra_required: list[str] | None = None,
        additional_properties: bool = False,
    ) -> dict[str, Any]:
        """生成参数搜索空间对应的 JSON Schema (Draft 2020-12)

        每个 ParamRange / ParamChoice 维度变成 schema 的一个 property，
        所有维度名都进入 required。可通过 extra_properties / extra_required
        注入额外字段（例如 `cluster_func_name`），避免与方法注册表耦合。

        Args:
            extra_properties: 需要追加到 properties 的额外字段
            extra_required: 需要追加到 required 的额外字段名
            additional_properties: 是否允许 schema 之外的字段，默认 False

        Returns:
            dict[str, Any]: JSON Schema
        """
        properties: dict[str, Any] = {
            d.name: d.to_json_schema_property() for d in self.dimensions
        }
        if extra_properties:
            properties.update(extra_properties)

        required: list[str] = [d.name for d in self.dimensions]
        if extra_required:
            for name in extra_required:
                if name not in required:
                    required.append(name)

        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": additional_properties,
        }

    def validate_params(
        self, params: dict[str, Any], strict: bool = True
    ) -> list[str]:
        """校验参数字典是否合法

        Args:
            params: 待校验的参数字典
            strict: 为 True 时拒绝未知键（默认 True）

        Returns:
            list[str]: 错误描述列表，空列表表示合法
        """
        errors: list[str] = []
        dim_by_name: dict[str, ParamRange | ParamChoice] = {
            d.name: d for d in self.dimensions
        }

        for name in dim_by_name:
            if name not in params:
                errors.append(f"缺失参数: {name}")

        for key, value in params.items():
            if key not in dim_by_name:
                if strict:
                    errors.append(f"未知参数: {key}")
                continue
            dim = dim_by_name[key]
            if isinstance(dim, ParamRange):
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    errors.append(
                        f"参数 {key} 必须是数字，得到 {type(value).__name__}"
                    )
                elif not dim.contains(value):
                    errors.append(
                        f"参数 {key}={value} 超出范围 [{dim.min_val}, {dim.max_val}]"
                    )
            elif isinstance(dim, ParamChoice):
                if not dim.contains(value):
                    errors.append(
                        f"参数 {key}={value!r} 不在候选 {dim.choices}"
                    )

        return errors

    def validate_params_or_raise(
        self, params: dict[str, Any], strict: bool = True
    ) -> None:
        """校验参数字典，不合法时抛出 ValueError

        Args:
            params: 待校验的参数字典
            strict: 为 True 时拒绝未知键（默认 True）

        Raises:
            ValueError: 校验失败，message 为换行拼接的全部错误
        """
        errors = self.validate_params(params, strict=strict)
        if errors:
            raise ValueError("\n".join(errors))