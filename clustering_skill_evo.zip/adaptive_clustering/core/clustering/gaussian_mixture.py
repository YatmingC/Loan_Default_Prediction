"""高斯混合聚类方法

使用GaussianMixture算法对金融风控数据进行聚类，支持超参数调优。
"""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.mixture import GaussianMixture as SKLearnGaussianMixture

from adaptive_clustering.core.clustering.base import BaseClusteringMethod
from adaptive_clustering.core.clustering.param_space import ParamSpace


class GaussianMixtureClustering(BaseClusteringMethod):
    """高斯混合聚类方法

    使用高斯混合模型进行软聚类，通过最大后验概率确定簇归属。
    每个聚类方法即一个skill的承载者。

    可调参数：
    - n_components: 高斯分量数 (2-20)
    - covariance_type: 协方差类型 ('full', 'tied', 'diag', 'spherical')
    - max_iter: 最大迭代次数 (100-1000)
    - tol: 收敛阈值 (1e-6 ~ 1e-3)
    - reg_covar: 正则化系数 (1e-7 ~ 1e-2)

    Attributes:
        name: 方法名称
        params: 当前参数
    """

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        """初始化高斯混合聚类

        Args:
            params: 聚类参数，默认n_components=3
        """
        default_params: dict[str, Any] = {
            "n_components": 3,
            "covariance_type": "full",
            "max_iter": 200,
            "tol": 1e-3,
            "reg_covar": 1e-6,
        }
        if params:
            default_params.update(params)
        super().__init__(name="gaussian_mixture", params=default_params)

    def fit(self, data: np.ndarray) -> tuple[np.ndarray, dict[str, Any]]:
        """执行高斯混合聚类

        Args:
            data: 输入特征矩阵，shape=(n_samples, n_features)

        Returns:
            tuple[np.ndarray, dict[str, Any]]: (聚类标签, 附加信息含cluster_centers)
        """
        n_components = int(self.params.get("n_components", 3))
        n_components = min(n_components, len(data))

        model = SKLearnGaussianMixture(
            n_components=n_components,
            covariance_type=self.params.get("covariance_type", "full"),
            max_iter=int(self.params.get("max_iter", 200)),
            tol=float(self.params.get("tol", 1e-3)),
            reg_covar=float(self.params.get("reg_covar", 1e-6)),
            random_state=42,
        )
        labels = model.fit_predict(data)

        extra_info: dict[str, Any] = {
            "cluster_centers": model.means_,
            "weights": model.weights_.tolist(),
            "converged": model.converged_,
            "n_iter": int(model.n_iter_),
            "lower_bound": float(model.lower_bound_),
            "bic": float(model.bic(data)),
            "aic": float(model.aic(data)),
            "model": model,
        }

        return labels, extra_info

    def get_param_space(self) -> ParamSpace:
        """获取高斯混合参数搜索空间

        Returns:
            ParamSpace: 参数搜索空间定义
        """
        return (
            ParamSpace()
            .add_range("n_components", 2, 20, step=1)
            .add_choice("covariance_type", ["full", "tied", "diag", "spherical"])
            .add_range("max_iter", 100, 1000, step=100)
            .add_range("tol", 1e-6, 1e-3, log_scale=True)
            .add_range("reg_covar", 1e-7, 1e-2, log_scale=True)
        )
