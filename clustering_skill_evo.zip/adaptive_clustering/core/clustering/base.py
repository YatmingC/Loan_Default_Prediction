"""聚类方法基类

定义所有聚类方法的抽象接口，确保统一的fit/score/get_param_space接口。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np
from pydantic import BaseModel

from adaptive_clustering.core.clustering.param_space import ParamSpace
from adaptive_clustering.core.models import ClusterResult

def _get_method_registry() -> dict[str, type[BaseClusteringMethod]]:
    """获取聚类方法注册表（懒加载，避免循环依赖）

    Returns:
        dict[str, type[BaseClusteringMethod]]: 方法名到类的映射
    """
    from adaptive_clustering.core.clustering.dbscan import DBSCANClustering
    from adaptive_clustering.core.clustering.gaussian_mixture import GaussianMixtureClustering
    from adaptive_clustering.core.clustering.kmeans import KMeansClustering
    from adaptive_clustering.core.clustering.spectral import SpectralClusteringMethod

    return {
        "kmeans": KMeansClustering,
        "dbscan": DBSCANClustering,
        "gaussian_mixture": GaussianMixtureClustering,
        "spectral": SpectralClusteringMethod,
    }


def get_clustering_method(name: str, params: dict[str, Any] | None = None) -> BaseClusteringMethod:
    """根据名称获取聚类方法实例

    Args:
        name: 聚类方法名称（kmeans, dbscan, gaussian_mixture, spectral）
        params: 初始参数

    Returns:
        BaseClusteringMethod: 聚类方法实例

    Raises:
        ValueError: 不支持的聚类方法名称
    """
    methods = _get_method_registry()

    name_lower = name.lower()
    if name_lower not in methods:
        raise ValueError(
            f"不支持的聚类方法: {name}。支持的方法: {list(methods.keys())}"
        )

    return methods[name_lower](params=params)


def build_cluster_algo_output_schema(method_name: str) -> dict[str, Any]:
    """构造 LLM 输出契约的 JSON Schema

    在该方法的 ParamSpace 之上追加 `cluster_func_name`（const 锁定为本轮算法名），
    可作为 `paseo --output-schema` 的输入文件，约束 LLM 只能输出合法字段。

    Args:
        method_name: 聚类方法名（kmeans/dbscan/gaussian_mixture/spectral）

    Returns:
        dict[str, Any]: 完整的输出 JSON Schema
    """
    method = get_clustering_method(method_name)
    return method.get_param_space().to_json_schema(
        extra_properties={"cluster_func_name": {"const": method_name}},
        extra_required=["cluster_func_name"],
    )

class BaseClusteringMethod(ABC):
    """聚类方法抽象基类

    所有聚类方法必须实现fit、score和get_param_space接口。
    每个聚类方法即一个skill的承载者。

    Attributes:
        name: 聚类方法名称
        params: 当前参数配置
    """

    def __init__(self, name: str, params: dict[str, Any] | None = None) -> None:
        """初始化聚类方法

        Args:
            name: 聚类方法名称
            params: 初始参数配置
        """
        self.name = name
        self.params = params or {}

    @abstractmethod
    def fit(self, data: np.ndarray) -> tuple[np.ndarray, dict[str, Any]]:
        """执行聚类

        Args:
            data: 输入数据，shape=(n_samples, n_features)

        Returns:
            tuple[np.ndarray, dict[str, Any]]: (聚类标签数组, 聚类附加信息)
                - 标签数组: shape=(n_samples,)，-1表示噪声点
                - 附加信息: 包含cluster_centers等算法特定信息
        """

    @abstractmethod
    def get_param_space(self) -> ParamSpace:
        """获取参数搜索空间

        Returns:
            ParamSpace: 该方法的参数搜索空间定义
        """

    def run(
        self,
        data: np.ndarray,
    ) -> ClusterResult:
        """执行完整聚类流程

        包括fit、score和构建ClusterResult。

        Args:
            data: 输入特征矩阵

        Returns:
            ClusterResult: 完整的聚类结果
        """
        cluster_labels, extra_info = self.fit(data)

        return ClusterResult(
            method_name=self.name,
            params=self.params.copy(),
            labels=cluster_labels.tolist(),
            model=extra_info["model"]
        )

    def update_params(self, **kwargs: Any) -> None:
        """更新聚类参数

        Args:
            **kwargs: 要更新的参数键值对
        """
        self.params.update(kwargs)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name!r}, params={self.params})"
