"""DBSCAN聚类方法

使用DBSCAN算法对金融风控数据进行聚类，支持超参数调优。
"""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.cluster import DBSCAN as SKLearnDBSCAN
from sklearn.neighbors import NearestNeighbors

from adaptive_clustering.core.clustering.base import BaseClusteringMethod
from adaptive_clustering.core.clustering.param_space import ParamSpace


class DBSCANClustering(BaseClusteringMethod):
    """DBSCAN聚类方法

    基于密度的聚类方法，能够识别噪声点。
    每个聚类方法即一个skill的承载者。

    可调参数：
    - eps: 邻域半径 (0.01-10.0)
    - min_samples: 最小样本数 (2-50)
    - metric: 距离度量 ('euclidean', 'manhattan', 'cosine')

    Attributes:
        name: 方法名称
        params: 当前参数
    """

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        """初始化DBSCAN聚类

        Args:
            params: 聚类参数，默认eps=0.5, min_samples=5
        """
        default_params: dict[str, Any] = {
            "eps": 0.5,
            "min_samples": 5,
            "metric": "euclidean",
        }
        if params:
            default_params.update(params)
        super().__init__(name="dbscan", params=default_params)

    def fit(self, data: np.ndarray) -> tuple[np.ndarray, dict[str, Any]]:
        """执行DBSCAN聚类

        Args:
            data: 输入特征矩阵，shape=(n_samples, n_features)

        Returns:
            tuple[np.ndarray, dict[str, Any]]: (聚类标签, 附加信息含cluster_centers)
        """
        model = SKLearnDBSCAN(
            eps=float(self.params.get("eps", 0.5)),
            min_samples=int(self.params.get("min_samples", 5)),
            metric=self.params.get("metric", "euclidean"),
        )
        labels = model.fit_predict(data)

        # DBSCAN没有显式的cluster_centers，计算各簇的均值作为中心
        cluster_centers = self._compute_cluster_centers(data, labels)

        extra_info: dict[str, Any] = {
            "cluster_centers": cluster_centers,
            "n_core_samples": len(model.core_sample_indices_),
            "core_sample_indices": model.core_sample_indices_.tolist(),
            "model": model,
        }

        return labels, extra_info

    def _compute_cluster_centers(
        self, data: np.ndarray, labels: np.ndarray
    ) -> np.ndarray:
        """计算各簇的中心点（均值）

        Args:
            data: 特征矩阵
            labels: 聚类标签

        Returns:
            np.ndarray: 各簇中心，shape=(n_clusters, n_features)
        """
        unique_labels = sorted(set(labels.tolist()) - {-1})
        centers = []
        for label in unique_labels:
            mask = labels == label
            center = data[mask].mean(axis=0)
            centers.append(center)
        return np.array(centers) if centers else np.empty((0, data.shape[1]))

    def get_param_space(self) -> ParamSpace:
        """获取DBSCAN参数搜索空间

        Returns:
            ParamSpace: 参数搜索空间定义
        """
        return (
            ParamSpace()
            .add_range("eps", 0.01, 10.0, log_scale=True)
            .add_range("min_samples", 2, 50, step=1)
            .add_choice("metric", ["euclidean", "manhattan", "cosine"])
        )

    @staticmethod
    def suggest_eps(data: np.ndarray, min_samples: int = 5) -> float:
        """基于k-distance图建议eps值

        使用k近邻距离的拐点作为eps的参考值。

        Args:
            data: 特征矩阵
            min_samples: DBSCAN的min_samples参数

        Returns:
            float: 建议的eps值
        """
        k = min_samples
        nbrs = NearestNeighbors(n_neighbors=k).fit(data)
        distances, _ = nbrs.kneighbors(data)
        k_distances = np.sort(distances[:, -1])

        # 计算曲率最大的点作为拐点
        if len(k_distances) < 3:
            return float(k_distances[-1]) if len(k_distances) > 0 else 0.5

        # 使用二阶差分找拐点
        diffs = np.diff(k_distances)
        if len(diffs) < 2:
            return float(k_distances[len(k_distances) // 2])

        second_diffs = np.diff(diffs)
        knee_idx = int(np.argmax(second_diffs)) + 1

        return float(k_distances[min(knee_idx, len(k_distances) - 1)])
