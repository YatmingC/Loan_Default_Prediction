"""聚类模块 - 聚类算法实现、指标计算、参数搜索和超参数调优

提供以下功能：
- base: 聚类方法基类 BaseClusteringMethod
- kmeans: KMeans聚类方法
- dbscan: DBSCAN聚类方法
- gaussian_mixture: 高斯混合聚类方法
- spectral: 谱聚类方法
- metrics: 聚类质量指标计算（Silhouette, CH, DB）
- param_space: 参数搜索空间定义
- tuner: 超参数调优器
"""

from adaptive_clustering.core.clustering.base import BaseClusteringMethod, get_clustering_method
from adaptive_clustering.core.clustering.dbscan import DBSCANClustering
from adaptive_clustering.core.clustering.gaussian_mixture import GaussianMixtureClustering
from adaptive_clustering.core.clustering.kmeans import KMeansClustering
from adaptive_clustering.core.clustering.param_space import ParamChoice, ParamRange, ParamSpace
from adaptive_clustering.core.clustering.spectral import SpectralClusteringMethod

__all__ = [
    "BaseClusteringMethod",
    "KMeansClustering",
    "DBSCANClustering",
    "GaussianMixtureClustering",
    "SpectralClusteringMethod",
    "ParamRange",
    "ParamChoice",
    "ParamSpace",
    "get_clustering_method",
]
