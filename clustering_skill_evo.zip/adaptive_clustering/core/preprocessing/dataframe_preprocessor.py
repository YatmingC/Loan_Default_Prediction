"""混合类型DataFrame预处理器

将包含数值、类别、文本字段的pandas DataFrame转换为
纯数值的numpy数组，供下游聚类和归一化使用。

处理流程:
1. 自动推断或手动指定列类型
2. NaN缺失值填充
3. 类别列编码（OrdinalEncoder）
4. 文本列向量化（TF-IDF）
5. 输出数值矩阵 + 预处理元数据
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import Any, Optional

import numpy as np
import pandas as pd
from pydantic import BaseModel, Field

from sklearn.preprocessing import StandardScaler

from adaptive_clustering.core.models import Dataset, Sample

logger = logging.getLogger(__name__)


class ColumnType(str, Enum):
    """列类型枚举"""

    NUMERIC = "numeric"
    """数值列：int/float，NaN用中位数填充"""

    CATEGORICAL = "categorical"
    """类别列：低基数字符串，NaN用众数填充，OrdinalEncoder编码"""

    ENUM = "enum"
    """枚举列：文本类型的枚举值，处理方式与CATEGORICAL相同，NaN用众数填充，OrdinalEncoder编码"""

    TEXT = "text"
    """文本列：高基数字符串，NaN用空字符串填充，TF-IDF向量化"""


class ImputeStrategy(str, Enum):
    """缺失值填充策略"""

    MEDIAN = "median"
    """中位数填充（数值列默认）"""

    MODE = "mode"
    """众数填充（类别列默认）"""

    CONSTANT = "constant"
    """常量填充（文本列默认，填充空字符串）"""

    DROP = "drop"
    """删除含NaN的行"""


class ColumnRole(str, Enum):
    """列作用枚举"""

    NONE = "none"
    """无特殊作用"""

    LABEL = "label"
    """目标列：作为标签使用，不参与特征编码"""

    CLUSTERING = "clustering"
    """聚类列：参与聚类特征编码"""

    SKILL_GENERATION = "skill_generation"
    """skill生成列：数据保存到Sample.metadata中供SkillGenerator使用"""


class ColumnConfig(BaseModel):
    """列配置

    Attributes:
        name: 列名
        column_type: 列类型
        impute_strategy: 缺失值填充策略
        is_label: 是否为标签列（标签列不参与特征编码）
        participate_in_clustering: 是否参与聚类特征编码
        role: 列作用（LABEL/CLUSTERING/SKILL_GENERATION/NONE），
              fit_transform()会根据role自动同步is_label和participate_in_clustering
    """

    name: str = Field(..., description="列名")
    column_type: ColumnType = Field(
        default=ColumnType.NUMERIC, description="列类型"
    )
    impute_strategy: ImputeStrategy = Field(
        default=ImputeStrategy.MEDIAN, description="缺失值填充策略"
    )
    is_label: bool = Field(default=False, description="是否为标签列")
    participate_in_clustering: bool = Field(
        default=True, description="是否参与聚类特征编码（False时该列不出现在特征矩阵中，但数据保留在original_df中）"
    )
    role: ColumnRole = Field(
        default=ColumnRole.NONE, description="列作用：LABEL=目标列, CLUSTERING=聚类列, SKILL_GENERATION=skill生成列, NONE=无"
    )


class PreprocessResult(BaseModel):
    """预处理结果

    Attributes:
        dataset: 转换后的Dataset（features为纯数值）
        feature_names: 编码后的特征名列表
        column_configs: 列配置（含推断结果）
        preprocessing_metadata: 预处理元数据（编码器参数等）
    """

    model_config = {"arbitrary_types_allowed": True}

    dataset: Any = Field(..., description="转换后的Dataset")
    feature_names: list[str] = Field(
        default_factory=list, description="编码后的特征名列表"
    )
    column_configs: list[dict[str, Any]] = Field(
        default_factory=list, description="列配置"
    )
    preprocessing_metadata: dict[str, Any] = Field(
        default_factory=dict, description="预处理元数据"
    )
    original_df: Any = Field(
        default=None, description="原始DataFrame副本，用于导出时保留全部列"
    )
    skill_columns: list[str] = Field(
        default_factory=list, description="skill生成列名列表，对应数据保存在Sample.metadata中"
    )


class DataFramePreprocessor:
    """混合类型DataFrame预处理器

    将包含数值、类别、文本字段的pandas DataFrame转换为
    纯数值numpy数组，供下游聚类使用。

    使用方式：

        # 自动推断列类型
        preprocessor = DataFramePreprocessor()
        result = preprocessor.fit_transform(df, label_column="label")

        # 手动指定列类型
        configs = [
            ColumnConfig(name="amount", column_type=ColumnType.NUMERIC),
            ColumnConfig(name="type", column_type=ColumnType.CATEGORICAL),
            ColumnConfig(name="desc", column_type=ColumnType.TEXT),
            ColumnConfig(name="label", column_type=ColumnType.NUMERIC, is_label=True),
        ]
        preprocessor = DataFramePreprocessor(column_configs=configs)
        result = preprocessor.fit_transform(df, label_column="label")

    Attributes:
        column_configs: 列配置列表
        _is_fitted: 是否已完成fit
        _encoders: 类别编码器（OrdinalEncoder）映射
        _tfidf_vectorizers: TF-IDF向量化器映射
        _impute_values: 各列的填充值
        _feature_names_out: 编码后的特征名列表
    """

    def __init__(
        self,
        column_configs: list[ColumnConfig] | None = None,
        tfidf_max_features: int = 10,
    ) -> None:
        """初始化预处理器

        Args:
            column_configs: 列配置列表，None则自动推断
            tfidf_max_features: TF-IDF最大特征数（每列）
        """
        self.column_configs = column_configs
        self.tfidf_max_features = tfidf_max_features
        self._is_fitted: bool = False
        self._encoders: dict[str, Any] = {}
        self._tfidf_vectorizers: dict[str, Any] = {}
        self._impute_values: dict[str, Any] = {}
        self._feature_names_out: list[str] = []
        self._preprocessing_metadata: dict[str, Any] = {}

    @classmethod
    def load_column_configs(
        cls,
        description_path: str,
    ) -> list[ColumnConfig]:
        """从列描述xlsx文件加载列配置

        读取包含列名、列类型、列作用三列的描述文件，自动映射为ColumnConfig列表。

        列类型映射规则：
        - float/int → NUMERIC (median填充)
        - enum → ENUM (mode填充)
        - text → TEXT (constant填充)

        列作用映射规则：
        - 目标列 → LABEL (is_label=True, participate_in_clustering=False)
        - 聚类 → CLUSTERING (is_label=False, participate_in_clustering=True)
        - skill生成 → SKILL_GENERATION (is_label=False, participate_in_clustering=False)
        - 无 → NONE (is_label=False, participate_in_clustering=False)

        Args:
            description_path: 列描述文件路径（需包含列名、列类型、列作用三列）

        Returns:
            list[ColumnConfig]: 列配置列表

        Raises:
            FileNotFoundError: 描述文件不存在
            ValueError: 列类型或列作用值无法识别
        """
        from pathlib import Path

        path = Path(description_path)
        if not path.exists():
            raise FileNotFoundError(f"列描述文件不存在: {description_path}")

        df_desc = pd.read_excel(description_path)

        # 预期3列：列名、列类型、列作用
        cols = df_desc.columns.tolist()
        if len(cols) < 3:
            raise ValueError(f"列描述文件应至少包含3列（列名、列类型、列作用），当前仅有{len(cols)}列")

        col_name_col = cols[0]
        col_type_col = cols[1]
        col_role_col = cols[2]

        # 列类型映射
        type_mapping: dict[str, tuple[ColumnType, ImputeStrategy]] = {
            "float": (ColumnType.NUMERIC, ImputeStrategy.MEDIAN),
            "int": (ColumnType.NUMERIC, ImputeStrategy.MEDIAN),
            "numeric": (ColumnType.NUMERIC, ImputeStrategy.MEDIAN),
            "enum": (ColumnType.ENUM, ImputeStrategy.MODE),
            "categorical": (ColumnType.CATEGORICAL, ImputeStrategy.MODE),
            "text": (ColumnType.TEXT, ImputeStrategy.CONSTANT),
        }

        # 列作用映射（支持前缀匹配，如"skill生成-一期模型推理过程"匹配"skill生成"）
        role_mapping: dict[str, ColumnRole] = {
            "目标列": ColumnRole.LABEL,
            "label": ColumnRole.LABEL,
            "聚类": ColumnRole.CLUSTERING,
            "clustering": ColumnRole.CLUSTERING,
            "skill生成": ColumnRole.SKILL_GENERATION,
            "skill_generation": ColumnRole.SKILL_GENERATION,
            "无": ColumnRole.NONE,
            "none": ColumnRole.NONE,
        }

        def _match_role(raw: str) -> ColumnRole:
            """匹配列作用，支持前缀匹配

            精确匹配优先；无精确匹配时，检查raw是否以某个key为前缀
            （以"-"或"_"分隔），如"skill生成-一期模型推理过程"匹配"skill生成"。

            Args:
                raw: xlsx中的原始列作用字符串（已strip和lower）

            Returns:
                ColumnRole: 匹配到的列作用

            Raises:
                ValueError: 无法匹配任何已知列作用
            """
            if raw in role_mapping:
                return role_mapping[raw]
            # 前缀匹配：raw以"key-"或"key_"开头
            for prefix, role in role_mapping.items():
                if raw.startswith(f"{prefix}-") or raw.startswith(f"{prefix}_"):
                    return role
            raise ValueError(
                f"无法识别的列作用 '{raw}'（列名: {name}），"
                f"支持的作用: {list(role_mapping.keys())}（支持前缀匹配，如'skill生成-子类型'）"
            )

        configs: list[ColumnConfig] = []
        for _, row in df_desc.iterrows():
            name = str(row[col_name_col]).strip()
            type_str = str(row[col_type_col]).strip().lower()
            role_str = str(row[col_role_col]).strip().lower()

            # 映射列类型
            if type_str not in type_mapping:
                raise ValueError(f"无法识别的列类型 '{type_str}'（列名: {name}），支持的类型: {list(type_mapping.keys())}")
            column_type, impute_strategy = type_mapping[type_str]

            # 映射列作用（前缀匹配）
            role = _match_role(role_str)

            # 根据role设置is_label和participate_in_clustering
            is_label = role == ColumnRole.LABEL
            participate = role == ColumnRole.CLUSTERING

            configs.append(ColumnConfig(
                name=name,
                column_type=column_type,
                impute_strategy=impute_strategy,
                is_label=is_label,
                participate_in_clustering=participate,
                role=role,
            ))

        return configs

    def infer_column_types(self, df: pd.DataFrame) -> list[ColumnConfig]:
        """自动推断DataFrame各列的类型

        推断规则：
        - 数值dtype → NUMERIC
        - object dtype + 唯一值 < 20 → CATEGORICAL
        - object dtype + 唯一值 >= 20 或 平均字符串长度 > 20 → TEXT

        Args:
            df: 输入DataFrame

        Returns:
            list[ColumnConfig]: 推断的列配置列表
        """
        configs: list[ColumnConfig] = []
        for col_name in df.columns:
            dtype = df[col_name].dtype

            if pd.api.types.is_numeric_dtype(dtype):
                configs.append(ColumnConfig(
                    name=col_name,
                    column_type=ColumnType.NUMERIC,
                    impute_strategy=ImputeStrategy.MEDIAN,
                ))
            else:
                # object/string类型
                n_unique = df[col_name].nunique(dropna=True)
                avg_len = df[col_name].dropna().astype(str).str.len().mean()

                if n_unique < 20 and avg_len < 20:
                    configs.append(ColumnConfig(
                        name=col_name,
                        column_type=ColumnType.CATEGORICAL,
                        impute_strategy=ImputeStrategy.MODE,
                    ))
                else:
                    configs.append(ColumnConfig(
                        name=col_name,
                        column_type=ColumnType.TEXT,
                        impute_strategy=ImputeStrategy.CONSTANT,
                    ))

        return configs

    def fit_transform(
            self,
            df: pd.DataFrame,
            label_column: str = "label",
            clustering_columns: list[str] | None = None,
    ) -> PreprocessResult:
        """拟合并转换DataFrame

        Args:
            df: 输入DataFrame
            label_column: 标签列名
            clustering_columns: 参与聚类的原始列名子集。仅作用于 role==CLUSTERING
                的列：子集中的列 participate_in_clustering 置 True，其余 CLUSTERING
                列置 False。为 None 时使用全部 CLUSTERING 列（默认行为）。传入的列
                必须均为 CLUSTERING 列且非空。

        Returns:
            PreprocessResult: 预处理结果，包含Dataset和元数据

        Raises:
            ValueError: 标签列不存在，或 clustering_columns 含非聚类列/为空
        """
        if label_column not in df.columns:
            raise ValueError(f"标签列 '{label_column}' 不存在于DataFrame中")

        # 推断或使用提供的列配置
        if self.column_configs is None:
            self.column_configs = self.infer_column_types(df)

        # 根据role自动同步is_label和participate_in_clustering（仅对非NONE角色生效）
        # NONE角色为默认值，表示用户未指定role，保留is_label/participate_in_clustering原值
        for cfg in self.column_configs:
            if cfg.role == ColumnRole.LABEL:
                cfg.is_label = True
                cfg.participate_in_clustering = False
            elif cfg.role == ColumnRole.CLUSTERING:
                cfg.is_label = False
                cfg.participate_in_clustering = True
            elif cfg.role == ColumnRole.SKILL_GENERATION:
                cfg.is_label = False
                cfg.participate_in_clustering = False
            # NONE: 不覆盖，保留用户设置的is_label和participate_in_clustering

        # 确保label列标记为is_label（兼容无role的旧用法）
        for cfg in self.column_configs:
            if cfg.name == label_column and not cfg.is_label:
                cfg.is_label = True
                cfg.participate_in_clustering = False
                break

        # 可选：限定参与聚类的列子集（在 role 同步之后施加，避免被上面的逻辑覆盖）
        if clustering_columns is not None:
            valid_clustering = {
                cfg.name for cfg in self.column_configs if cfg.role == ColumnRole.CLUSTERING
            }
            if not clustering_columns:
                raise ValueError("clustering_columns 不能为空")
            unknown = [c for c in clustering_columns if c not in valid_clustering]
            if unknown:
                raise ValueError(
                    f"clustering_columns 含非聚类列: {unknown}，候选聚类列: {sorted(valid_clustering)}"
                )
            selected_set = set(clustering_columns)
            for cfg in self.column_configs:
                if cfg.role == ColumnRole.CLUSTERING:
                    cfg.participate_in_clustering = cfg.name in selected_set

        # 提取标签
        labels = df[label_column].values.astype(int)

        # 处理各特征列
        feature_arrays: list[np.ndarray] = []
        feature_names: list[str] = []

        for cfg in self.column_configs:
            if cfg.is_label or not cfg.participate_in_clustering:
                continue

            col_data = df[cfg.name].copy()

            if cfg.column_type == ColumnType.NUMERIC:
                arr, names = self._process_numeric(col_data, cfg.name)
            elif cfg.column_type in (ColumnType.CATEGORICAL, ColumnType.ENUM):
                arr, names = self._process_categorical(col_data, cfg.name)
            elif cfg.column_type == ColumnType.TEXT:
                arr, names = self._process_text(col_data, cfg.name)
            else:
                continue

            feature_arrays.append(arr)
            feature_names.extend(names)

        # 拼接所有特征
        if feature_arrays:
            feature_matrix = np.hstack(feature_arrays)
        else:
            feature_matrix = np.zeros((len(df), 0))

        # ---------- 新增：特征归一化处理 ----------
        feature_matrix = StandardScaler().fit_transform(feature_matrix)

        self._feature_names_out = feature_names
        self._is_fitted = True

        samples = []
        for i in range(len(df)):
            # 将skill生成列数据写入metadata
            skill_metadata = {}
            for cfg in self.column_configs:
                if cfg.role == ColumnRole.SKILL_GENERATION:
                    val = df.iloc[i][cfg.name]
                    # 将NaN转为None，避免序列化问题
                    if pd.isna(val):
                        skill_metadata[cfg.name] = None
                    else:
                        skill_metadata[cfg.name] = val

            samples.append(Sample(
                sample_id=f"sample_{i}",
                features=feature_matrix[i].tolist(),  # 这里使用的是归一化后的特征
                label=int(labels[i]),
                metadata=skill_metadata,
            ))

        dataset = Dataset(
            name="preprocessed_data",
            samples=samples,
            feature_names=feature_names,
        )

        # 记录预处理元数据
        self._preprocessing_metadata = self._build_metadata()

        # 可以将归一化信息加入元数据（可选）
        if getattr(self, 'normalize', False):
            self._preprocessing_metadata['normalization'] = {
                'method': 'StandardScaler',
                'mean': self._normalizer.mean_.tolist() if hasattr(self._normalizer, 'mean_') else None,
                'scale': self._normalizer.scale_.tolist() if hasattr(self._normalizer, 'scale_') else None,
            }

        return PreprocessResult(
            dataset=dataset,
            feature_names=feature_names,
            column_configs=[c.model_dump() for c in self.column_configs if not c.is_label],
            preprocessing_metadata=self._preprocessing_metadata,
            original_df=df.copy()
        )

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        """使用已拟合的预处理器转换新DataFrame

        Args:
            df: 输入DataFrame

        Returns:
            np.ndarray: 转换后的数值矩阵

        Raises:
            RuntimeError: 预处理器尚未fit
        """
        if not self._is_fitted:
            raise RuntimeError("预处理器尚未fit，请先调用fit_transform()方法")

        feature_arrays: list[np.ndarray] = []

        for cfg in self.column_configs:
            if cfg.is_label or not cfg.participate_in_clustering:
                continue

            col_data = df[cfg.name].copy()

            if cfg.column_type == ColumnType.NUMERIC:
                arr, _ = self._process_numeric(col_data, cfg.name)
            elif cfg.column_type in (ColumnType.CATEGORICAL, ColumnType.ENUM):
                arr, _ = self._process_categorical(col_data, cfg.name)
            elif cfg.column_type == ColumnType.TEXT:
                arr, _ = self._process_text(col_data, cfg.name)
            else:
                continue

            feature_arrays.append(arr)

        if feature_arrays:
            return np.hstack(feature_arrays)
        return np.zeros((len(df), 0))

    @property
    def feature_names_out(self) -> list[str]:
        """编码后的特征名列表

        Returns:
            list[str]: 特征名列表
        """
        return self._feature_names_out

    @property
    def preprocessing_metadata(self) -> dict[str, Any]:
        """预处理元数据

        Returns:
            dict[str, Any]: 元数据字典
        """
        return self._preprocessing_metadata

    def _process_numeric(
        self, col: pd.Series, name: str
    ) -> tuple[np.ndarray, list[str]]:
        """处理数值列：填充NaN

        Args:
            col: 数值列数据
            name: 列名

        Returns:
            tuple[np.ndarray, list[str]]: (特征数组, 特征名列表)
        """
        if name not in self._impute_values:
            self._impute_values[name] = col.median()
        fill_value = self._impute_values[name]
        filled = col.fillna(fill_value).values.astype(float).reshape(-1, 1)
        return filled, [name]

    def _process_categorical(
        self, col: pd.Series, name: str
    ) -> tuple[np.ndarray, list[str]]:
        """处理类别列：填充NaN + OrdinalEncoder编码

        Args:
            col: 类别列数据
            name: 列名

        Returns:
            tuple[np.ndarray, list[str]]: (特征数组, 特征名列表)
        """
        # 填充NaN
        if name not in self._impute_values:
            mode_values = col.mode()
            self._impute_values[name] = mode_values.iloc[0] if len(mode_values) > 0 else ""
        fill_value = self._impute_values[name]
        filled = col.fillna(fill_value).astype(str)

        # OrdinalEncoder编码
        if name not in self._encoders:
            from sklearn.preprocessing import OrdinalEncoder
            encoder = OrdinalEncoder(
                handle_unknown="use_encoded_value",
                unknown_value=-1,
            )
            encoder.fit(filled.values.reshape(-1, 1))
            self._encoders[name] = encoder

        encoder = self._encoders[name]
        encoded = encoder.transform(filled.values.reshape(-1, 1))
        return encoded, [f"{name}_encoded"]

    def _process_text(
        self, col: pd.Series, name: str
    ) -> tuple[np.ndarray, list[str]]:
        """处理文本列：填充NaN + TF-IDF向量化

        Args:
            col: 文本列数据
            name: 列名

        Returns:
            tuple[np.ndarray, list[str]]: (特征数组, 特征名列表)
        """
        # 填充NaN
        if name not in self._impute_values:
            self._impute_values[name] = ""
        fill_value = self._impute_values[name]
        filled = col.fillna(fill_value).astype(str)

        # TF-IDF向量化
        if name not in self._tfidf_vectorizers:
            from sklearn.feature_extraction.text import TfidfVectorizer
            vectorizer = TfidfVectorizer(
                max_features=self.tfidf_max_features,
                token_pattern=r"(?u)\b\w+\b",  # 支持中文单字和英文单词
            )
            vectorizer.fit(filled.values)
            self._tfidf_vectorizers[name] = vectorizer

        vectorizer = self._tfidf_vectorizers[name]
        tfidf_matrix = vectorizer.transform(filled.values).toarray()

        feature_names = [f"{name}_tfidf_{i}" for i in range(tfidf_matrix.shape[1])]
        return tfidf_matrix, feature_names

    def _build_metadata(self) -> dict[str, Any]:
        """构建预处理元数据

        Returns:
            dict[str, Any]: 元数据字典
        """
        metadata: dict[str, Any] = {
            "impute_values": {
                k: v if not isinstance(v, (np.floating, np.integer)) else float(v)
                for k, v in self._impute_values.items()
            },
            "categorical_encoders": {},
            "tfidf_vocabularies": {},
        }

        for name, encoder in self._encoders.items():
            metadata["categorical_encoders"][name] = {
                "categories": [
                    c if not isinstance(c, (np.floating, np.integer)) else float(c)
                    for cat in encoder.categories_
                    for c in cat
                ],
            }

        for name, vectorizer in self._tfidf_vectorizers.items():
            metadata["tfidf_vocabularies"][name] = {
                "vocabulary_size": len(vectorizer.vocabulary_),
                "max_features": self.tfidf_max_features,
            }

        return metadata
