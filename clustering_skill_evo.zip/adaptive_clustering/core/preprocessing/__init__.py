"""预处理模块 - 特征归一化与数据变换

提供以下功能：
- normalizer: 特征归一化器，支持RobustScaler等多种归一化策略
- dataframe_preprocessor: 混合类型DataFrame预处理器
"""

from adaptive_clustering.core.preprocessing.normalizer import (
    FeatureNormalizer,
    NormalizerConfig,
    NormalizerType,
)
from adaptive_clustering.core.preprocessing.dataframe_preprocessor import (
    ColumnConfig,
    ColumnRole,
    ColumnType,
    DataFramePreprocessor,
    ImputeStrategy,
    PreprocessResult,
)

__all__ = [
    "FeatureNormalizer",
    "NormalizerConfig",
    "NormalizerType",
    "ColumnConfig",
    "ColumnRole",
    "ColumnType",
    "DataFramePreprocessor",
    "ImputeStrategy",
    "PreprocessResult",
]
