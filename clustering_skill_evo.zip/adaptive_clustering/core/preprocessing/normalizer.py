"""特征归一化器

基于sklearn预处理算法的特征归一化，支持RobustScaler、StandardScaler、MinMaxScaler等策略。
默认使用RobustScaler，对金融风控数据中的异常值具有鲁棒性。
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

import numpy as np
from pydantic import BaseModel, Field
from sklearn.preprocessing import MinMaxScaler, RobustScaler, StandardScaler


class NormalizerType(str, Enum):
    """归一化策略类型"""

    ROBUST = "robust"
    """RobustScaler: 基于中位数和四分位距，对异常值鲁棒"""

    STANDARD = "standard"
    """StandardScaler: 基于均值和标准差的Z-score标准化"""

    MINMAX = "minmax"
    """MinMaxScaler: 归一化到[0, 1]范围"""

    NONE = "none"
    """不进行归一化，直接返回原始数据"""


class NormalizerConfig(BaseModel):
    """归一化器配置

    Attributes:
        normalizer_type: 归一化策略类型
        with_centering: 是否进行中心化（RobustScaler/StandardScaler适用）
        with_scaling: 是否进行缩放（RobustScaler/StandardScaler适用）
        quantile_range: 分位数范围（仅RobustScaler适用），默认(25.0, 75.0)即IQR
        clip: 是否裁剪到[0, 1]（仅MinMaxScaler适用）
    """

    normalizer_type: NormalizerType = Field(
        default=NormalizerType.ROBUST,
        description="归一化策略类型",
    )
    with_centering: bool = Field(
        default=True,
        description="是否进行中心化",
    )
    with_scaling: bool = Field(
        default=True,
        description="是否进行缩放",
    )
    quantile_range: tuple[float, float] = Field(
        default=(25.0, 75.0),
        description="分位数范围（仅RobustScaler适用）",
    )
    clip: bool = Field(
        default=False,
        description="是否裁剪到[0, 1]（仅MinMaxScaler适用）",
    )


class FeatureNormalizer:
    """特征归一化器

    封装sklearn预处理算法，提供fit/transform/inverse_transform接口。
    默认使用RobustScaler，对金融风控数据中的异常值具有鲁棒性。

    使用方式：
        # 默认RobustScaler
        normalizer = FeatureNormalizer()
        normalized_data = normalizer.fit_transform(data)

        # 指定其他策略
        config = NormalizerConfig(normalizer_type=NormalizerType.STANDARD)
        normalizer = FeatureNormalizer(config=config)
        normalized_data = normalizer.fit_transform(data)

    Attributes:
        config: 归一化器配置
        _scaler: sklearn scaler实例（fit后可用）
        _is_fitted: 是否已完成fit
    """

    def __init__(self, config: NormalizerConfig | None = None) -> None:
        """初始化归一化器

        Args:
            config: 归一化器配置，None则使用默认配置(RobustScaler)
        """
        self.config = config or NormalizerConfig()
        self._scaler: Any = None
        self._is_fitted: bool = False

    def fit(self, data: np.ndarray) -> FeatureNormalizer:
        """拟合归一化参数

        根据配置的策略，在输入数据上拟合归一化参数。

        Args:
            data: 输入特征矩阵，shape=(n_samples, n_features)

        Returns:
            FeatureNormalizer: self，支持链式调用

        Raises:
            ValueError: 归一化策略类型不支持
        """
        self._scaler = self._create_scaler()
        if self._scaler is not None:
            self._scaler.fit(data)
        self._is_fitted = True
        return self

    def transform(self, data: np.ndarray) -> np.ndarray:
        """对数据进行归一化变换

        Args:
            data: 输入特征矩阵，shape=(n_samples, n_features)

        Returns:
            np.ndarray: 归一化后的特征矩阵

        Raises:
            RuntimeError: 归一化器尚未fit
        """
        if not self._is_fitted or self._scaler is None:
            raise RuntimeError("归一化器尚未fit，请先调用fit()方法")
        return self._scaler.transform(data)

    def fit_transform(self, data: np.ndarray) -> np.ndarray:
        """拟合并变换数据

        Args:
            data: 输入特征矩阵，shape=(n_samples, n_features)

        Returns:
            np.ndarray: 归一化后的特征矩阵
        """
        self.fit(data)
        if self._scaler is None:
            # NormalizerType.NONE 时直接返回原始数据
            return data
        return self._scaler.transform(data)

    def inverse_transform(self, data: np.ndarray) -> np.ndarray:
        """逆归一化变换

        将归一化后的数据还原到原始尺度。

        Args:
            data: 归一化后的特征矩阵

        Returns:
            np.ndarray: 还原后的特征矩阵

        Raises:
            RuntimeError: 归一化器尚未fit
        """
        if not self._is_fitted or self._scaler is None:
            raise RuntimeError("归一化器尚未fit，请先调用fit()方法")
        return self._scaler.inverse_transform(data)

    def _create_scaler(self) -> Any:
        """根据配置创建sklearn scaler实例

        Returns:
            sklearn scaler实例，NormalizerType.NONE时返回None

        Raises:
            ValueError: 不支持的归一化策略
        """
        if self.config.normalizer_type == NormalizerType.ROBUST:
            return RobustScaler(
                with_centering=self.config.with_centering,
                with_scaling=self.config.with_scaling,
                quantile_range=self.config.quantile_range,
            )
        elif self.config.normalizer_type == NormalizerType.STANDARD:
            return StandardScaler(
                with_mean=self.config.with_centering,
                with_std=self.config.with_scaling,
            )
        elif self.config.normalizer_type == NormalizerType.MINMAX:
            return MinMaxScaler(clip=self.config.clip)
        elif self.config.normalizer_type == NormalizerType.NONE:
            return None
        else:
            raise ValueError(
                f"不支持的归一化策略: {self.config.normalizer_type}"
            )

    @property
    def is_fitted(self) -> bool:
        """是否已完成fit

        Returns:
            bool: 是否已完成拟合
        """
        return self._is_fitted

    @property
    def scaler_params(self) -> dict[str, Any]:
        """获取归一化器拟合参数（用于序列化和调试）

        返回的参数包含center_（中心化偏移）和scale_（缩放因子），
        可用于理解归一化效果和跨会话恢复归一化状态。

        Returns:
            dict[str, Any]: 归一化参数字典，包含center、scale等
        """
        if not self._is_fitted or self._scaler is None:
            return {}
        params: dict[str, Any] = {
            "normalizer_type": self.config.normalizer_type.value,
        }
        if hasattr(self._scaler, "center_"):
            params["center_"] = self._scaler.center_.tolist()
        if hasattr(self._scaler, "scale_"):
            params["scale_"] = self._scaler.scale_.tolist()
        if hasattr(self._scaler, "data_min_"):
            params["data_min_"] = self._scaler.data_min_.tolist()
        if hasattr(self._scaler, "data_max_"):
            params["data_max_"] = self._scaler.data_max_.tolist()
        return params

    def to_config_dict(self) -> dict[str, Any]:
        """导出配置为字典（用于PipelineContext序列化）

        Returns:
            dict[str, Any]: 配置字典，包含归一化器配置和拟合参数
        """
        return {
            "config": self.config.model_dump(),
            "scaler_params": self.scaler_params,
        }

    @classmethod
    def from_config_dict(cls, data: dict[str, Any]) -> FeatureNormalizer:
        """从配置字典恢复归一化器

        注意：恢复后的归一化器需要重新fit才能使用transform，
        scaler_params仅用于信息记录。

        Args:
            data: 配置字典，包含config和scaler_params

        Returns:
            FeatureNormalizer: 恢复的归一化器实例
        """
        config = NormalizerConfig(**data["config"])
        return cls(config=config)
