"""数据集与聚类结果数据模型

提供金融风控数据集、样本、聚类结果等核心数据结构。
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np
from pydantic import BaseModel, Field, field_validator


class Sample(BaseModel):
    """金融风控样本数据

    Attributes:
        sample_id: 样本唯一标识
        features: 样本特征向量（数值列表）
        label: 样本标签，0表示正常，1表示风险
        metadata: 样本附加元数据
    """

    sample_id: str
    features: list[float] = Field(..., description="样本特征向量")
    label: int = Field(..., ge=0, le=1, description="样本标签：0=正常, 1=风险")
    metadata: dict[str, Any] = Field(default_factory=dict, description="附加元数据")

    @field_validator("label")
    @classmethod
    def validate_label(cls, v: int) -> int:
        """验证标签值必须为0或1"""
        if v not in (0, 1):
            raise ValueError(f"label必须为0或1，当前值: {v}")
        return v

    def to_numpy(self) -> np.ndarray:
        """将特征向量转换为numpy数组

        Returns:
            np.ndarray: 特征向量数组
        """
        return np.array(self.features)


class Dataset(BaseModel):
    """金融风控数据集

    Attributes:
        name: 数据集名称
        samples: 样本列表
        feature_names: 特征名称列表
        description: 数据集描述
    """

    name: str = Field(..., description="数据集名称")
    samples: list[Sample] = Field(..., min_length=1, description="样本列表")
    feature_names: list[str] = Field(default_factory=list, description="特征名称列表")
    description: str = Field(default="", description="数据集描述")

    @property
    def feature_matrix(self) -> np.ndarray:
        """获取所有样本的特征矩阵

        Returns:
            np.ndarray: shape=(n_samples, n_features)的特征矩阵
        """
        return np.array([s.features for s in self.samples])

    @property
    def labels(self) -> np.ndarray:
        """获取所有样本的标签数组

        Returns:
            np.ndarray: shape=(n_samples,)的标签数组
        """
        return np.array([s.label for s in self.samples])

    @property
    def label_1_samples(self) -> list[Sample]:
        """获取所有label=1（风险）的样本

        Returns:
            list[Sample]: label=1的样本列表
        """
        return [s for s in self.samples if s.label == 1]

    @property
    def label_0_samples(self) -> list[Sample]:
        """获取所有label=0（正常）的样本

        Returns:
            list[Sample]: label=0的样本列表
        """
        return [s for s in self.samples if s.label == 0]

    @property
    def n_samples(self) -> int:
        """样本数量"""
        return len(self.samples)

    @property
    def n_features(self) -> int:
        """特征维度"""
        return len(self.samples[0].features) if self.samples else 0

    @property
    def label_distribution(self) -> dict[int, int]:
        """标签分布统计

        Returns:
            dict[int, int]: 各标签的样本数量
        """
        dist: dict[int, int] = {0: 0, 1: 0}
        for s in self.samples:
            dist[s.label] += 1
        return dist


class ClusterAssignment(BaseModel):
    """簇分配结果

    Attributes:
        cluster_id: 簇编号
        sample_ids: 属于该簇的样本ID列表
        label_1_sample_ids: 属于该簇的label=1样本ID列表
        cluster_center: 簇中心坐标
        size: 簇内样本数量
    """

    cluster_id: int = Field(..., ge=0, description="簇编号")
    sample_ids: list[str] = Field(default_factory=list, description="簇内样本ID列表")
    label_1_sample_ids: list[str] = Field(default_factory=list, description="簇内label=1样本ID列表")
    cluster_center: Optional[list[float]] = Field(default=None, description="簇中心坐标")
    size: int = Field(default=0, ge=0, description="簇内样本数量")

    @property
    def label_1_ratio(self) -> float:
        """簇内label=1样本占比

        Returns:
            float: label=1样本比例，空簇返回0.0
        """
        if self.size == 0:
            return 0.0
        return len(self.label_1_sample_ids) / self.size


class ClusterResult(BaseModel):
    """聚类结果

    Attributes:
        method_name: 聚类方法名称
        params: 聚类参数
        labels: 每个样本的簇标签（-1表示噪声点）
        cluster_assignments: 各簇的分配详情
        clustering_metrics: 聚类质量指标
        behavior_trajectories: 聚类Agent行为轨迹
    """

    method_name: str = Field(..., description="聚类方法名称")
    model: object = Field(..., description="聚类模型")
    params: dict[str, Any] = Field(default_factory=dict, description="聚类参数")
    labels: list[int] = Field(..., description="每个样本的簇标签")
    cluster_assignments: list[ClusterAssignment] = Field(default_factory=list, description="各簇分配详情")
    clustering_metrics: Optional[Any] = Field(default=None, description="聚类质量指标(ClusteringMetrics)")
    behavior_trajectories: list[Any] = Field(default_factory=list, description="聚类Agent行为轨迹")

    @property
    def cluster_ids(self) -> list[int]:
        """获取所有有效簇ID（排除噪声点-1）

        Returns:
            list[int]: 有效簇ID列表
        """
        unique = set(self.labels)
        return sorted(cid for cid in unique if cid >= 0)

    @property
    def n_clusters(self) -> int:
        """有效簇数量"""
        return len(self.cluster_ids)

    @property
    def n_noise(self) -> int:
        """噪声点数量（标签为-1的样本）"""
        return sum(1 for l in self.labels if l == -1)

    def get_label_1_samples(self, cluster_id: int, dataset: "Dataset") -> list[Sample]:
        """获取指定簇中label=1的样本

        Args:
            cluster_id: 簇编号
            dataset: 原始数据集

        Returns:
            list[Sample]: 该簇中label=1的样本列表
        """
        sample_ids_in_cluster = set()
        for assignment in self.cluster_assignments:
            if assignment.cluster_id == cluster_id:
                sample_ids_in_cluster = set(assignment.label_1_sample_ids)
                break

        return [s for s in dataset.samples if s.sample_id in sample_ids_in_cluster]

    def get_samples_in_cluster(self, cluster_id: int, dataset: "Dataset") -> list[Sample]:
        """获取指定簇中的所有样本

        Args:
            cluster_id: 簇编号
            dataset: 原始数据集

        Returns:
            list[Sample]: 该簇中的所有样本
        """
        sample_ids_in_cluster = set()
        for assignment in self.cluster_assignments:
            if assignment.cluster_id == cluster_id:
                sample_ids_in_cluster = set(assignment.sample_ids)
                break

        return [s for s in dataset.samples if s.sample_id in sample_ids_in_cluster]
