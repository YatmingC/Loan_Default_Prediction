"""指标数据模型

定义聚类质量指标、分类指标和指标历史记录。
"""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


class ClusteringMetrics(BaseModel):
    """聚类质量指标

    使用三种常用指标评估聚类质量：
    - Silhouette Score: 轮廓系数，越大越好 (-1, 1)
    - Calinski-Harabasz Index: CH指数，越大越好
    - Davies-Bouldin Index: DB指数，越小越好

    Attributes:
        silhouette_score: 轮廓系数
        calinski_harabasz_score: CH指数
        davies_bouldin_score: DB指数
        n_clusters: 有效簇数量
        n_noise: 噪声点数量
        composite_score: 综合得分（加权组合）
    """

    silhouette_score: float = Field(
        default=0.0, ge=-1.0, le=1.0, description="轮廓系数，越大越好"
    )
    calinski_harabasz_score: float = Field(
        default=0.0, ge=0.0, description="CH指数，越大越好"
    )
    davies_bouldin_score: float = Field(
        default=0.0, ge=0.0, description="DB指数，越小越好"
    )
    n_clusters: int = Field(default=0, ge=0, description="有效簇数量")
    n_noise: int = Field(default=0, ge=0, description="噪声点数量")
    composite_score: float = Field(default=0.0, description="综合得分")

    def compute_composite_score(
        self,
        silhouette_weight: float = 0.4,
        ch_weight: float = 0.3,
        db_weight: float = 0.3,
    ) -> float:
        """计算综合得分

        综合得分 = silhouette_weight * silhouette_score
                  + ch_weight * normalized_ch
                  - db_weight * normalized_db

        CH和DB需要归一化到[0, 1]范围。

        Args:
            silhouette_weight: 轮廓系数权重
            ch_weight: CH指数权重
            db_weight: DB指数权重

        Returns:
            float: 综合得分
        """
        # 归一化CH到[0, 1]（使用sigmoid近似）
        normalized_ch = self.calinski_harabasz_score / (
            1.0 + self.calinski_harabasz_score
        )
        # 归一化DB（越小越好，取倒数后归一化）
        normalized_db = 1.0 / (1.0 + self.davies_bouldin_score) if self.davies_bouldin_score > 0 else 1.0

        self.composite_score = (
            silhouette_weight * (self.silhouette_score + 1.0) / 2.0
            + ch_weight * normalized_ch
            + db_weight * normalized_db
        )
        return self.composite_score


class ClassificationMetrics(BaseModel):
    """分类指标

    评估Skill在整个数据集上的precision和recall。

    Attributes:
        precision: 精确率
        recall: 召回率
        f1: F1分数
        accuracy: 准确率
        true_positives: 真阳性数
        false_positives: 假阳性数
        true_negatives: 真阴性数
        false_negatives: 假阴性数
        support: 总样本数
    """

    precision: float = Field(default=0.0, ge=0.0, le=1.0, description="精确率")
    recall: float = Field(default=0.0, ge=0.0, le=1.0, description="召回率")
    f1: float = Field(default=0.0, ge=0.0, le=1.0, description="F1分数")
    accuracy: float = Field(default=0.0, ge=0.0, le=1.0, description="准确率")
    true_positives: int = Field(default=0, ge=0, description="真阳性数")
    false_positives: int = Field(default=0, ge=0, description="假阳性数")
    true_negatives: int = Field(default=0, ge=0, description="真阴性数")
    false_negatives: int = Field(default=0, ge=0, description="假阴性数")
    support: int = Field(default=0, ge=0, description="总样本数")

    @classmethod
    def from_confusion_matrix(
        cls,
        true_positives: int,
        false_positives: int,
        true_negatives: int,
        false_negatives: int,
    ) -> ClassificationMetrics:
        """从混淆矩阵计算分类指标

        Args:
            true_positives: 真阳性数
            false_positives: 假阳性数
            true_negatives: 真阴性数
            false_negatives: 假阴性数

        Returns:
            ClassificationMetrics: 计算得到的分类指标
        """
        support = true_positives + false_positives + true_negatives + false_negatives

        precision = (
            true_positives / (true_positives + false_positives)
            if (true_positives + false_positives) > 0
            else 0.0
        )
        recall = (
            true_positives / (true_positives + false_negatives)
            if (true_positives + false_negatives) > 0
            else 0.0
        )
        f1 = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else 0.0
        )
        accuracy = (
            (true_positives + true_negatives) / support if support > 0 else 0.0
        )

        return cls(
            precision=precision,
            recall=recall,
            f1=f1,
            accuracy=accuracy,
            true_positives=true_positives,
            false_positives=false_positives,
            true_negatives=true_negatives,
            false_negatives=false_negatives,
            support=support,
        )


class MetricRecord(BaseModel):
    """指标记录

    记录单次迭代的完整指标。

    Attributes:
        iteration: 迭代轮次
        clustering_metrics: 聚类质量指标
        classification_metrics: 分类指标
        clustering_method: 使用的聚类方法
        clustering_params: 使用的聚类参数
        timestamp: 记录时间戳
    """

    iteration: int = Field(..., ge=1, description="迭代轮次")
    clustering_metrics: Optional[ClusteringMetrics] = Field(
        default=None, description="聚类质量指标"
    )
    classification_metrics: Optional[ClassificationMetrics] = Field(
        default=None, description="分类指标"
    )
    clustering_method: str = Field(default="", description="聚类方法")
    clustering_params: dict[str, Any] = Field(
        default_factory=dict, description="聚类参数"
    )
    timestamp: float = Field(default=0.0, description="记录时间戳")


class MetricHistory(BaseModel):
    """指标历史记录

    按迭代轮次存储指标历史，支持版本比较和最优指标追踪。

    Attributes:
        records: 指标记录列表
    """

    records: list[MetricRecord] = Field(default_factory=list, description="指标记录列表")

    def add_record(self, record: MetricRecord) -> None:
        """添加指标记录

        Args:
            record: 指标记录
        """
        self.records.append(record)

    @property
    def best_classification_metrics(self) -> Optional[ClassificationMetrics]:
        """获取历史最优分类指标

        Returns:
            Optional[ClassificationMetrics]: 最优分类指标，无记录时返回None
        """
        if not self.records:
            return None

        best: Optional[ClassificationMetrics] = None
        for record in self.records:
            if record.classification_metrics is None:
                continue
            if best is None or is_better_metrics(record.classification_metrics, best):
                best = record.classification_metrics
        return best

    @property
    def best_iteration(self) -> Optional[int]:
        """获取最优指标对应的迭代轮次

        Returns:
            Optional[int]: 最优轮次，无记录时返回None
        """
        if not self.records:
            return None

        best_iter: Optional[int] = None
        best: Optional[ClassificationMetrics] = None
        for record in self.records:
            if record.classification_metrics is None:
                continue
            if best is None or is_better_metrics(record.classification_metrics, best):
                best = record.classification_metrics
                best_iter = record.iteration
        return best_iter

    @property
    def latest_record(self) -> Optional[MetricRecord]:
        """获取最新指标记录

        Returns:
            Optional[MetricRecord]: 最新记录，无记录时返回None
        """
        if not self.records:
            return None
        return self.records[-1]

    @property
    def n_records(self) -> int:
        """记录数量"""
        return len(self.records)


def is_better_metrics(
    current: ClassificationMetrics, previous: Optional[ClassificationMetrics]
) -> bool:
    """比较指标是否更优

    判断规则（需求6）：
    - 相同precision，recall更高 → 更优
    - 相同recall，precision更高 → 更优
    - 两者都更高 → 更优
    - 其他情况 → 非更优

    Args:
        current: 当前指标
        previous: 上一指标（None表示第一次，自动更优）

    Returns:
        bool: 当前指标是否更优
    """
    if previous is None:
        return True

    p_better = current.precision > previous.precision
    p_same = abs(current.precision - previous.precision) < 1e-9
    r_better = current.recall > previous.recall
    r_same = abs(current.recall - previous.recall) < 1e-9

    # 两者都更高
    if p_better and r_better:
        return True
    # 相同precision，recall更高
    if p_same and r_better:
        return True
    # 相同recall，precision更高
    if r_same and p_better:
        return True

    return False
