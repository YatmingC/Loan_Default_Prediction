#!/usr/bin/env python3
"""
风险分类评估脚本
根据五级分类政策评估当前风险分类是否准确。

改进说明（基于贷后风险重审分析）：
- 增加不确定性缓冲带机制：低风险结论不再绝对化，保留不确定性余量
- 增加风险信号强制传导：每个预警信号必须在最终结论中被回应
- 增加循环信贷动态风险考量：余额为零不代表无风险
- 增加综合风险评级分级：当识别到风险信号时，即使无逾期也上调结论
- 增加降级模式：输入数据不可用时输出提示而非崩溃

Usage:
    python scripts/evaluate_risk_classification.py --input <assessment_data.json> --policy <five-classification-policy.md>

Exit codes:
    0: 分类准确无需调整，或输入不可用（降级模式）
    1: 分类需调整（建议在 stdout 中输出）
"""

import argparse
import json
import sys


OVERDUE_THRESHOLDS = {
    "关注": 90,
    "次级": 270,
    "可疑": 360,
    "损失": 365,
}

WARNING_SIGNAL_WEIGHTS = {
    "黄色": 1,
    "橙色": 2,
    "红色": 3,
}

MANDATORY_RISK_SIGNAL_CATEGORIES = [
    "担保不足",
    "无担保",
    "行业周期性",
    "信用贷款",
    "循环贷",
    "无抵押",
    "微型企业",
    "衰退期",
]


def assess_overall_risk_grade(warning_signals: list, overdue_days: int,
                               collateral_adequacy: str) -> dict:
    """综合评估风险等级，包含不确定性缓冲带。"""
    total_weight = 0
    red_count = 0
    signal_categories = set()
    has_credit_loan = False
    has_revolving = False
    has_industry_risk = False
    is_micro = False
    in_recession = False

    for signal in warning_signals:
        level = signal.get("level", "黄色")
        total_weight += WARNING_SIGNAL_WEIGHTS.get(level, 1)
        if level == "红色":
            red_count += 1
        desc = signal.get("description", "").lower()
        cat = signal.get("category", "").lower()

        if any(kw in desc or kw in cat for kw in ["信用", "无担保", "无抵押", "credit"]):
            has_credit_loan = True
            signal_categories.add("信用贷款/无担保")
        if any(kw in desc or kw in cat for kw in ["循环", "revolving", "循环贷"]):
            has_revolving = True
            signal_categories.add("循环贷")
        if any(kw in desc or kw in cat for kw in ["周期", "衰退", "行业"]):
            has_industry_risk = True
            signal_categories.add("行业周期/衰退")
        if any(kw in desc or kw in cat for kw in ["微型", "小微", "micro"]):
            is_micro = True
            signal_categories.add("微型企业")
        if any(kw in desc or kw in cat for kw in ["衰退", "recession"]):
            in_recession = True
            signal_categories.add("衰退期")

    risk_upgrade_factors = []

    if collateral_adequacy in ["不足", "较差", "无抵押"]:
        signal_categories.add("担保不足")
        has_credit_loan = True
        total_weight += 1

    if red_count > 0:
        base_grade = "高"
        confidence = "高"
    elif total_weight >= 6:
        base_grade = "高"
        confidence = "高"
    elif total_weight >= 4:
        base_grade = "中高"
        confidence = "中"
    elif total_weight >= 2:
        base_grade = "中"
        confidence = "中"
    elif overdue_days > 90:
        base_grade = "中高"
        confidence = "中"
    elif overdue_days > 30:
        base_grade = "中"
        confidence = "中"
    else:
        risk_upgrade_factors = []
        if has_credit_loan:
            risk_upgrade_factors.append("无担保/信用贷款")
        if has_revolving:
            risk_upgrade_factors.append("循环贷（余额为零不代表无风险）")
        if has_industry_risk:
            risk_upgrade_factors.append("行业周期性/衰退风险")
        if is_micro and in_recession:
            risk_upgrade_factors.append("衰退期微型企业脆弱性叠加")
        if collateral_adequacy in ["不足", "较差"]:
            risk_upgrade_factors.append("担保不足")

        if risk_upgrade_factors:
            base_grade = "中低"
            confidence = "中"
            uncertainty_note = (
                f"存在风险信号（{'；'.join(risk_upgrade_factors)}），"
                f"虽未触发风险信号强制传导机制，"
                f"最终判断上调至中低风险等级。"
            )
        else:
            base_grade = "低"
            confidence = "低"
            uncertainty_note = (
                "当前未观察到明显风险信号，但不能排除潜在风险。"
                "低违约概率区间存在异常违约可能性，结论保留不确定性余量。"
                "不排除在外部环境恶化时风险上升的可能。"
            )
            return {
                "grade": base_grade,
                "confidence": confidence,
                "uncertainty_note": uncertainty_note,
                "risk_upgrade_factors": risk_upgrade_factors,
                "signal_categories": list(signal_categories),
                "total_weight": total_weight,
            }

    uncertainty_note = ""
    return {
        "grade": base_grade,
        "confidence": confidence,
        "uncertainty_note": uncertainty_note,
        "risk_upgrade_factors": risk_upgrade_factors,
        "signal_categories": list(signal_categories),
        "total_weight": total_weight,
    }


def evaluate_classification(assessment_data: dict) -> dict:
    """评估风险分类（含不确定性缓冲带和风险信号强制传导）。"""
    result = {
        "current_classification": assessment_data.get("current_classification", "未知"),
        "overdue_days": assessment_data.get("overdue_days", 0),
        "warning_signals": assessment_data.get("warning_signals", []),
        "repayment_ability": assessment_data.get("repayment_ability", "未知"),
        "collateral_adequacy": assessment_data.get("collateral_adequacy", "未知"),
        "credit_type": assessment_data.get("credit_type", "未知"),
        "credit_balance": assessment_data.get("credit_balance", None),
        "is_micro_enterprise": assessment_data.get("is_micro_enterprise", False),
        "macro_environment": assessment_data.get("macro_environment", "正常"),
    }

    total_weight = 0
    red_count = 0
    for signal in result["warning_signals"]:
        level = signal.get("level", "黄色")
        total_weight += WARNING_SIGNAL_WEIGHTS.get(level, 1)
        if level == "红色":
            red_count += 1

    result["signal_weight_total"] = total_weight
    result["red_signal_count"] = red_count

    suggested_min = "正常"
    for classification, days in sorted(OVERDUE_THRESHOLDS.items(), key=lambda x: x[1]):
        if result["overdue_days"] > days:
            suggested_min = classification

    result["suggested_min_classification"] = suggested_min

    risk_grade = assess_overall_risk_grade(
        result["warning_signals"],
        result["overdue_days"],
        result["collateral_adequacy"],
    )
    result["risk_grade"] = risk_grade

    revolving_note = ""
    if result["credit_type"] == "循环贷" and (result["credit_balance"] is None or result["credit_balance"] == 0):
        revolving_note = (
            "⚠️ 循环贷风险提示：当前授信余额为零，但循环信贷具有随时提款的动态使用特性。"
            "余额为零仅说明客户当前未使用授信，不代表未来不会提款或违约。"
            "贷后风险管理评估的是客户未来还款能力和违约可能性，而非当前敞口状态。"
            "建议继续按正常频率执行贷后检查，不得因余额为零降低检查频率。"
        )
    result["revolving_risk_note"] = revolving_note

    if red_count > 0:
        result["recommendation"] = "建议下调分类（存在红色预警信号）"
        result["needs_adjustment"] = True
    elif total_weight >= 4:
        result["recommendation"] = "建议关注，可能存在分类下调风险"
        result["needs_adjustment"] = total_weight >= 6
    elif result["overdue_days"] > 90 and result["current_classification"] == "正常":
        result["recommendation"] = "逾期超过 90 天，建议至少调整为关注类"
        result["needs_adjustment"] = True
    elif risk_grade["grade"] in ("中低", "中"):
        result["recommendation"] = (
            f"综合风险评级为{risk_grade['grade']}，"
            f"存在风险信号（{'; '.join(risk_grade.get('risk_upgrade_factors', []))}），"
            f"虽未触发逾期或高权重预警，但根据风险信号强制传导机制，"
            f"建议维持当前分类并加强监测。{risk_grade['uncertainty_note']}"
        )
        result["needs_adjustment"] = False
    else:
        result["recommendation"] = (
            "当前分类合理，无需调整。"
            f"{risk_grade['uncertainty_note']}"
        )
        result["needs_adjustment"] = False

    return result


def main():
    parser = argparse.ArgumentParser(description="风险分类评估")
    parser.add_argument("--input", required=True, help="评估数据 JSON 文件路径")
    parser.add_argument("--policy", required=False, help="分类政策文件路径")
    args = parser.parse_args()

    try:
        with open(args.input, "r", encoding="utf-8") as f:
            assessment_data = json.load(f)
    except FileNotFoundError:
        print(f"提示: 评估数据文件不存在 - {args.input}", file=sys.stderr)
        print("降级模式: 请基于前述步骤的分析结果进行综合判断，不使用脚本辅助。")
        sys.exit(0)
    except json.JSONDecodeError as e:
        print(f"提示: 评估数据 JSON 解析失败 - {e}", file=sys.stderr)
        print("降级模式: 请基于前述步骤的分析结果进行综合判断，不使用脚本辅助。")
        sys.exit(0)

    result = evaluate_classification(assessment_data)

    print(f"当前分类: {result['current_classification']}")
    print(f"逾期天数: {result['overdue_days']} 天")
    print(f"预警信号数: {len(result['warning_signals'])} (加权总分: {result['signal_weight_total']})")
    print(f"综合风险评级: {result['risk_grade']['grade']} (置信度: {result['risk_grade']['confidence']})")
    print(f"建议最低分类: {result['suggested_min_classification']}")
    if result['risk_grade']['uncertainty_note']:
        print(f"不确定性说明: {result['risk_grade']['uncertainty_note']}")
    if result['revolving_risk_note']:
        print(f"循环贷提示: {result['revolving_risk_note']}")
    print(f"建议: {result['recommendation']}")

    if result["needs_adjustment"]:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()
