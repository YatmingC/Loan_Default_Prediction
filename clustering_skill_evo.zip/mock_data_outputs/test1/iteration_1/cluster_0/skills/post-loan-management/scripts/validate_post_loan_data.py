#!/usr/bin/env python3
"""
贷后数据验证脚本
验证输入数据的完整性和基本勾稽关系。

Usage:
    python scripts/validate_post_loan_data.py --customer <customer_data.json> --financial <financial_data.json>

Exit codes:
    0: 验证通过或验证发现问题（问题不阻断流程，仅标注在报告中）
"""

import argparse
import json
import sys


def validate_customer_data(customer_path: str) -> list[str]:
    """验证客户数据完整性。"""
    errors = []
    try:
        with open(customer_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        required_fields = [
            "enterprise_name",
            "credit_code",
            "credit_limit",
            "credit_balance",
            "credit_term_start",
            "credit_term_end",
            "guarantee_type",
            "risk_classification",
        ]
        for field in required_fields:
            if field not in data or data[field] is None:
                errors.append(f"缺失必填字段: {field}")
        valid_risk_classes = ["正常", "关注", "次级", "可疑", "损失"]
        if "risk_classification" in data and data["risk_classification"] not in valid_risk_classes:
            errors.append(f"风险分类无效: {data['risk_classification']}，有效值: {valid_risk_classes}")
    except FileNotFoundError:
        errors.append(f"客户数据文件不存在: {customer_path}（将按降级策略继续）")
    except json.JSONDecodeError as e:
        errors.append(f"客户数据 JSON 解析失败: {e}（将按降级策略继续）")
    return errors


def validate_financial_data(financial_path: str) -> list[str]:
    """验证财务数据完整性和基本勾稽关系。"""
    errors = []
    try:
        with open(financial_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for statement in ["balance_sheet", "income_statement", "cash_flow_statement"]:
            if statement not in data:
                errors.append(f"缺失财务报表: {statement}")
        if "balance_sheet" in data:
            bs = data["balance_sheet"]
            if all(k in bs for k in ["total_assets", "total_liabilities", "equity"]):
                diff = bs["total_assets"] - (bs["total_liabilities"] + bs["equity"])
                tolerance = abs(bs["total_assets"]) * 0.01
                if abs(diff) > tolerance:
                    errors.append(
                        f"资产负债表不平衡: 总资产={bs['total_assets']}, "
                        f"总负债+权益={bs['total_liabilities'] + bs['equity']}, "
                        f"差异={diff}"
                    )
        if "cash_flow_statement" in data and "balance_sheet" in data:
            cfs = data["cash_flow_statement"]
            bs = data["balance_sheet"]
            if "ending_cash" in cfs and "cash_and_equivalents" in bs:
                diff = abs(cfs["ending_cash"] - bs["cash_and_equivalents"])
                tolerance = abs(bs["cash_and_equivalents"]) * 0.01
                if diff > tolerance:
                    errors.append(
                        f"现金流量表期末余额与资产负债表货币资金不匹配: "
                        f"现金流期末={cfs['ending_cash']}, 货币资金={bs['cash_and_equivalents']}"
                    )
    except FileNotFoundError:
        errors.append(f"财务数据文件不存在: {financial_path}（将按降级策略继续）")
    except json.JSONDecodeError as e:
        errors.append(f"财务数据 JSON 解析失败: {e}（将按降级策略继续）")
    return errors


def main():
    parser = argparse.ArgumentParser(description="贷后数据验证脚本")
    parser.add_argument("--customer", required=False, help="客户数据 JSON 文件路径")
    parser.add_argument("--financial", required=False, help="财务数据 JSON 文件路径")
    args = parser.parse_args()

    all_errors = []

    if args.customer:
        all_errors.extend(validate_customer_data(args.customer))
    if args.financial:
        all_errors.extend(validate_financial_data(args.financial))

    if not args.customer and not args.financial:
        print("提示: 未提供验证数据文件。如需验证，请使用 --customer 和/或 --financial 参数指定 JSON 文件路径。")
        print("降级模式: 将基于用户对话中提供的信息进行分析，不执行自动化验证。")
        sys.exit(0)

    if all_errors:
        print("验证发现问题（不阻断流程，问题将标注在报告中）:")
        for err in all_errors:
            print(f"  - {err}", file=sys.stderr)
        print(f"共 {len(all_errors)} 项问题，建议按降级策略处理。")
        sys.exit(0)
    else:
        print("验证通过")
        sys.exit(0)


if __name__ == "__main__":
    main()
