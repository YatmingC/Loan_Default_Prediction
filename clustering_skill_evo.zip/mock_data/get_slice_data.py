import pandas as pd
import sys

from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)

def stratified_sample(input_file, output_file, stratify_col='Default', n=100, random_state=42):
    """
    从 Excel 中按指定列分层采样，最终抽取 n 条记录。

    参数:
        input_file: 输入 Excel 文件路径
        output_file: 输出 Excel 文件路径
        stratify_col: 用于分层的列名（默认 'Default'）
        n: 最终采样总数（默认 100）
        random_state: 随机种子，保证可复现
    """
    # 读取数据
    df = pd.read_excel(input_file)
    logger.info(f"原始数据量: {len(df)}")

    # 计算每一层的比例
    counts = df[stratify_col].value_counts(normalize=True)
    sampled_parts = []

    # 按比例从每层抽取
    for label, frac in counts.items():
        stratum = df[df[stratify_col] == label]
        k = int(round(frac * n))          # 该层应抽数量
        k = min(k, len(stratum))          # 不能超过该层实际样本数
        if k > 0:
            sampled_parts.append(stratum.sample(n=k, random_state=random_state))
            logger.info(f"层 {label}: 应抽 {int(round(frac * n))}，实抽 {k} 条")

    # 合并已抽取的样本
    result = pd.concat(sampled_parts)

    # 如果因为某些层样本太少导致总数不足 n，从剩余数据中补齐
    if len(result) < n:
        remaining = df.drop(result.index)
        extra_needed = n - len(result)
        extra_sample = remaining.sample(n=extra_needed, random_state=random_state)
        result = pd.concat([result, extra_sample])
        logger.info(f"由于部分层样本不足，从剩余数据中随机补充 {extra_needed} 条")

    # 保存结果
    result.to_excel(output_file, index=False)
    logger.info(f"分层采样完成，共抽取 {len(result)} 条记录，保存至: {output_file}")

if __name__ == "__main__":
    # 支持命令行传参，也可直接修改默认文件名
    input_file = 'test_data.xlsx'
    output_file = 'sampled_test_data.xlsx'
    stratified_sample(input_file, output_file, n=10)