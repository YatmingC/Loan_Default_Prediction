import pandas as pd
import sys

from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)

def add_prompt_column(input_file, output_file, target_col='Default'):
    """
    读取 Excel，为每一行生成判断违约风险的 prompt，存入新列 'prompt'。

    参数:
        input_file:  输入 Excel 文件路径
        output_file: 输出 Excel 文件路径
        target_col:  目标列名（会被排除在 prompt 之外），默认 'Default'
    """
    df = pd.read_excel(input_file)

    # 所有需要作为特征展示的列
    feature_cols = [col for col in df.columns if col != target_col]

    prompts = []
    for _, row in df.iterrows():
        # 构造 key: value 列表
        info_lines = [f"{col}: {row[col]}" for col in feature_cols]
        info_block = "\n".join(info_lines)

        prompt = (
            f"根据以下企业信息，判断该企业是否存在违约风险。\n"
            f"{info_block}\n"
            f"请对企业违约风险进行分析，最终回答企业是否存在违约风险，答案放在【】中。"
        )
        prompts.append(prompt)

    df['prompt'] = prompts
    df.to_excel(output_file, index=False)
    logger.info(f"已生成 prompt 列，共 {len(df)} 条记录，保存至: {output_file}")

if __name__ == "__main__":
    input_file = 'sampled_test_data.xlsx'
    output_file = 'sampled_test_data_add_prompt.xlsx'
    add_prompt_column(input_file, output_file)