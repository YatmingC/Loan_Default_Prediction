"""测试 Rubric 注入 + 聚类先验特性的管道正确性"""

import sys
import pytest
import numpy as np
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent))


# ============================================================
# 1. load_rubric() 单元测试
# ============================================================

from main_multi_algo import load_rubric


class TestLoadRubric:
    def test_file_not_exists(self, tmp_path):
        result = load_rubric(tmp_path / "nonexistent.md")
        assert result == ""

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.md"
        f.write_text("", encoding="utf-8")
        assert load_rubric(f) == ""

    def test_only_comments(self, tmp_path):
        f = tmp_path / "comments.md"
        f.write_text("# comment line 1\n# comment line 2\n", encoding="utf-8")
        assert load_rubric(f) == ""

    def test_mixed_content(self, tmp_path):
        f = tmp_path / "mixed.md"
        f.write_text("# this is a comment\nactual content\n# another comment\nmore content\n", encoding="utf-8")
        result = load_rubric(f)
        assert "actual content" in result
        assert "more content" in result
        assert "# this is a comment" not in result

    def test_content_without_comments(self, tmp_path):
        f = tmp_path / "pure.md"
        f.write_text("line one\nline two\n", encoding="utf-8")
        result = load_rubric(f)
        assert "line one" in result
        assert "line two" in result


# ============================================================
# 2. Rubric 注入到 Jinja2 模板验证
# ============================================================

from src.prompt_template import render


class TestRubricTemplateInjection:
    def _mock_data_line(self):
        return {
            "prompt": "test prompt",
            "answer": "test answer",
            "feedback": "test feedback",
            "validation_result": {"risk_reason": "test reason"},
            "Default": 1,
        }

    def test_feedback_template_with_rubric(self):
        result = render(
            "feedback_prompt.j2",
            data_line=self._mock_data_line(),
            evaluation_rubric="逾期超过90天应判为高风险",
        )
        assert "## 评价标准（Rubric）" in result
        assert "逾期超过90天应判为高风险" in result

    def test_feedback_template_without_rubric(self):
        result = render(
            "feedback_prompt.j2",
            data_line=self._mock_data_line(),
            evaluation_rubric="",
        )
        assert "## 评价标准（Rubric）" not in result

    def test_update_template_with_rubric(self):
        result = render(
            "update_skill_prompt.j2",
            pattern_collections="some patterns",
            update_rubric="不得降低对担保不足客户的风险敏感度",
        )
        assert "## 更新约束（Rubric）" in result
        assert "不得降低对担保不足客户的风险敏感度" in result

    def test_update_template_without_rubric(self):
        result = render(
            "update_skill_prompt.j2",
            pattern_collections="some patterns",
            update_rubric="",
        )
        assert "## 更新约束（Rubric）" not in result


# ============================================================
# 3. 聚类先验 prompt 注入验证
# ============================================================

class TestClusteringPriorPromptInjection:
    def _build_prior_section(self, clustering_prior: str) -> str:
        """复现 call_clustering_strategy_skill_v3 中的 prior_section 拼接逻辑"""
        if clustering_prior:
            return f"""
## 人工聚类先验

用户提供了以下聚类先验知识，请在决策中参考这些先验来设定 custom_features 和 feature_weights 字段：

{clustering_prior}
"""
        return ""

    def test_prior_injected_when_content_present(self):
        section = self._build_prior_section("资产负债率权重应为3倍")
        assert "## 人工聚类先验" in section
        assert "资产负债率权重应为3倍" in section

    def test_prior_not_injected_when_empty(self):
        section = self._build_prior_section("")
        assert section == ""
        assert "人工聚类先验" not in section


# ============================================================
# 4. apply_clustering_priors() 单元测试
# ============================================================

from src.utils_multi_algo import apply_clustering_priors


class TestApplyClusteringPriors:
    def _sample_matrix(self):
        return [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]]

    def _sample_names(self):
        return ["feat_a", "feat_b", "feat_c"]

    def test_no_priors_returns_unchanged(self):
        mat = self._sample_matrix()
        names = self._sample_names()
        result_mat, result_names = apply_clustering_priors(mat, names)
        assert result_mat == mat
        assert result_names == names

    def test_none_priors_returns_unchanged(self):
        mat = self._sample_matrix()
        names = self._sample_names()
        result_mat, result_names = apply_clustering_priors(
            mat, names, custom_features=None, feature_weights=None
        )
        assert result_mat == mat
        assert result_names == names

    def test_feature_weights_scaling(self):
        mat = self._sample_matrix()
        names = self._sample_names()
        result_mat, result_names = apply_clustering_priors(
            mat, names, feature_weights={"feat_a": 2.0}
        )
        arr = np.array(result_mat)
        assert arr[0, 0] == pytest.approx(2.0)
        assert arr[1, 0] == pytest.approx(8.0)
        assert arr[2, 0] == pytest.approx(14.0)
        # 其余列不变
        assert arr[0, 1] == pytest.approx(2.0)
        assert arr[0, 2] == pytest.approx(3.0)
        assert result_names == names

    def test_custom_features_linear_combination(self):
        mat = self._sample_matrix()
        names = self._sample_names()
        result_mat, result_names = apply_clustering_priors(
            mat, names,
            custom_features=[{"name": "ab_avg", "components": {"feat_a": 0.5, "feat_b": 0.5}}],
        )
        arr = np.array(result_mat)
        assert arr.shape == (3, 4)
        assert result_names == ["feat_a", "feat_b", "feat_c", "ab_avg"]
        # 0.5*1 + 0.5*2 = 1.5
        assert arr[0, 3] == pytest.approx(1.5)
        # 0.5*4 + 0.5*5 = 4.5
        assert arr[1, 3] == pytest.approx(4.5)
        # 0.5*7 + 0.5*8 = 7.5
        assert arr[2, 3] == pytest.approx(7.5)

    def test_weights_applied_before_custom_features(self):
        """custom_features 基于加权后的矩阵计算"""
        mat = [[1.0, 2.0], [3.0, 4.0]]
        names = ["x", "y"]
        result_mat, result_names = apply_clustering_priors(
            mat, names,
            feature_weights={"x": 2.0},
            custom_features=[{"name": "xy_sum", "components": {"x": 1.0, "y": 1.0}}],
        )
        arr = np.array(result_mat)
        # x加权后: [2.0, 6.0], y不变: [2.0, 4.0]
        # xy_sum = x_weighted + y = [4.0, 10.0]
        assert arr[0, 2] == pytest.approx(4.0)
        assert arr[1, 2] == pytest.approx(10.0)

    def test_unknown_feature_names_ignored(self):
        mat = [[1.0, 2.0], [3.0, 4.0]]
        names = ["x", "y"]
        result_mat, result_names = apply_clustering_priors(
            mat, names,
            feature_weights={"nonexistent": 5.0},
            custom_features=[{"name": "combo", "components": {"nonexistent": 1.0, "x": 1.0}}],
        )
        arr = np.array(result_mat)
        # x,y 不变; combo = 0 (nonexistent) + 1*x
        assert arr[0, 0] == pytest.approx(1.0)
        assert arr[0, 2] == pytest.approx(1.0)
        assert arr[1, 2] == pytest.approx(3.0)

    def test_multiple_custom_features(self):
        mat = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]
        names = ["a", "b", "c"]
        result_mat, result_names = apply_clustering_priors(
            mat, names,
            custom_features=[
                {"name": "ab", "components": {"a": 1.0, "b": -1.0}},
                {"name": "bc", "components": {"b": 0.5, "c": 0.5}},
            ],
        )
        arr = np.array(result_mat)
        assert arr.shape == (2, 5)
        assert result_names == ["a", "b", "c", "ab", "bc"]
        # ab: 1-2=-1, 4-5=-1
        assert arr[0, 3] == pytest.approx(-1.0)
        assert arr[1, 3] == pytest.approx(-1.0)
        # bc: 0.5*2+0.5*3=2.5, 0.5*5+0.5*6=5.5
        assert arr[0, 4] == pytest.approx(2.5)
        assert arr[1, 4] == pytest.approx(5.5)


# ============================================================
# 5. validate_clustering_decision() 对新字段的校验
# ============================================================

from src.utils_multi_algo import validate_clustering_decision


class TestValidateClusteringDecisionNewFields:
    def _base_decision(self):
        return {
            "reasoning": "test reasoning",
            "cluster_func_name": "kmeans",
            "params": {
                "n_clusters": 10,
                "init": "k-means++",
                "n_init": 10,
                "max_iter": 300,
                "tol": 1e-4,
            },
        }

    def _base_context(self):
        return {
            "candidate_features": ["a", "b", "c"],
            "n_samples": 100,
            "prev_method": "kmeans",
            "iteration": 0,
            "algorithm_switch_history": [],
        }

    def test_no_new_fields_passes(self):
        validate_clustering_decision(self._base_decision(), self._base_context())

    def test_valid_custom_features_passes(self):
        decision = self._base_decision()
        decision["custom_features"] = [
            {"name": "combo", "components": {"a": 0.5, "b": 0.5}}
        ]
        validate_clustering_decision(decision, self._base_context())

    def test_valid_feature_weights_passes(self):
        decision = self._base_decision()
        decision["feature_weights"] = {"a": 2.0, "b": 0.5}
        validate_clustering_decision(decision, self._base_context())

    def test_custom_features_not_array_fails(self):
        decision = self._base_decision()
        decision["custom_features"] = "not an array"
        with pytest.raises(ValueError, match="custom_features必须是数组"):
            validate_clustering_decision(decision, self._base_context())

    def test_custom_features_missing_name_fails(self):
        decision = self._base_decision()
        decision["custom_features"] = [{"components": {"a": 1.0}}]
        with pytest.raises(ValueError, match="缺少'name'或'components'"):
            validate_clustering_decision(decision, self._base_context())

    def test_custom_features_missing_components_fails(self):
        decision = self._base_decision()
        decision["custom_features"] = [{"name": "x"}]
        with pytest.raises(ValueError, match="缺少'name'或'components'"):
            validate_clustering_decision(decision, self._base_context())

    def test_custom_features_components_not_dict_fails(self):
        decision = self._base_decision()
        decision["custom_features"] = [{"name": "x", "components": [1, 2]}]
        with pytest.raises(ValueError, match="components必须是字典"):
            validate_clustering_decision(decision, self._base_context())

    def test_custom_features_non_numeric_coeff_fails(self):
        decision = self._base_decision()
        decision["custom_features"] = [{"name": "x", "components": {"a": "bad"}}]
        with pytest.raises(ValueError, match="系数必须是数值"):
            validate_clustering_decision(decision, self._base_context())

    def test_feature_weights_not_dict_fails(self):
        decision = self._base_decision()
        decision["feature_weights"] = [1, 2, 3]
        with pytest.raises(ValueError, match="feature_weights必须是字典"):
            validate_clustering_decision(decision, self._base_context())

    def test_feature_weights_negative_fails(self):
        decision = self._base_decision()
        decision["feature_weights"] = {"a": -1.0}
        with pytest.raises(ValueError, match="权重不能为负"):
            validate_clustering_decision(decision, self._base_context())

    def test_feature_weights_exceeds_max_fails(self):
        decision = self._base_decision()
        decision["feature_weights"] = {"a": 15.0}
        with pytest.raises(ValueError, match="权重超过上限10.0"):
            validate_clustering_decision(decision, self._base_context())

    def test_feature_weights_non_numeric_fails(self):
        decision = self._base_decision()
        decision["feature_weights"] = {"a": "high"}
        with pytest.raises(ValueError, match="权重必须是数值"):
            validate_clustering_decision(decision, self._base_context())
