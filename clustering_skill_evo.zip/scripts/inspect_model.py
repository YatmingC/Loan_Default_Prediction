"""检查和可视化聚类模型

Usage:
    python scripts/inspect_model.py output/iteration_0/model.pkl
"""

import pickle
import sys
from pathlib import Path

def inspect_model(model_path: str):
    """加载并检查聚类模型"""

    model_file = Path(model_path)
    if not model_file.exists():
        print(f"❌ 模型文件不存在: {model_path}")
        return

    print(f"加载模型: {model_path}")
    with open(model_file, "rb") as f:
        model = pickle.load(f)

    print(f"\n模型类型: {type(model).__name__}")
    print("=" * 60)

    # KMeans
    if hasattr(model, "cluster_centers_"):
        print(f"✓ KMeans 模型")
        print(f"  簇数: {len(model.cluster_centers_)}")
        print(f"  特征维度: {model.cluster_centers_.shape[1]}")
        print(f"  迭代次数: {model.n_iter_}")
        print(f"  惯性 (inertia): {model.inertia_:.2f}")
        print(f"\n簇中心 (前3个特征):")
        for i, center in enumerate(model.cluster_centers_):
            print(f"  Cluster {i}: {center[:3]}")

    # DBSCAN
    elif hasattr(model, "core_sample_indices_"):
        print(f"✓ DBSCAN 模型")
        print(f"  核心样本数: {len(model.core_sample_indices_)}")
        print(f"  eps: {model.eps}")
        print(f"  min_samples: {model.min_samples}")

        if hasattr(model, "labels_"):
            unique_labels = set(model.labels_)
            n_clusters = len(unique_labels - {-1})
            n_noise = list(model.labels_).count(-1)
            print(f"  识别簇数: {n_clusters}")
            print(f"  噪声点数: {n_noise}")

    # GaussianMixture
    elif hasattr(model, "means_"):
        print(f"✓ Gaussian Mixture 模型")
        print(f"  组件数: {len(model.means_)}")
        print(f"  特征维度: {model.means_.shape[1]}")
        print(f"  协方差类型: {model.covariance_type}")
        print(f"  收敛: {model.converged_}")
        print(f"\n组件权重:")
        for i, weight in enumerate(model.weights_):
            print(f"  Component {i}: {weight:.4f}")

    # Spectral
    elif hasattr(model, "affinity_matrix_"):
        print(f"✓ Spectral Clustering 模型")
        print(f"  簇数: {model.n_clusters}")
        print(f"  亲和矩阵形状: {model.affinity_matrix_.shape}")

    else:
        print(f"⚠️  未知模型类型")
        print(f"可用属性: {[attr for attr in dir(model) if not attr.startswith('_')]}")

    print("\n" + "=" * 60)
    print("💡 提示：可以用 model.predict(new_data) 对新数据进行聚类")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/inspect_model.py <model_path>")
        print("Example: python scripts/inspect_model.py output/iteration_0/model.pkl")
        sys.exit(1)

    inspect_model(sys.argv[1])
