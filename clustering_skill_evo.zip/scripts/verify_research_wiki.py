#!/usr/bin/env python3
"""Research Wiki 验证脚本

检查 main_multi_algo.py 运行后生成的 research_wiki/ 目录的完整性和正确性。

使用方式：
    python scripts/verify_research_wiki.py ./clustering_workspace/research_wiki
    python scripts/verify_research_wiki.py  # 默认路径
"""

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path


VALID_VERDICTS = {"supported", "partial", "unsupported"}
VALID_CONFIDENCES = {"high", "medium", "low"}
VALID_OUTCOMES = {"pending", "positive", "mixed", "negative"}
VALID_ITERATION_TYPES = {"clustering", "skill_evo"}

IDEA_REQUIRED_SECTIONS = ["## 假设描述", "## 变更内容", "## 预期效果"]
EXP_REQUIRED_SECTIONS = ["## 关联 Idea", "## 指标数据", "## 过程信息"]
CLAIM_REQUIRED_SECTIONS = ["## 判断结果", "## 支持证据", "## 反对证据", "## 综合结论"]

JINJA_PATTERN = re.compile(r"\{\{.*?\}\}|\{%.*?%\}")
LOG_LINE_PATTERN = re.compile(r"^\[(\d{4}-\d{2}-\d{2}T[\d:]+)\].*—.*")
INDEX_LINK_PATTERN = re.compile(r"\[.*?\]\((.*?\.md)\)")


class Report:
    def __init__(self):
        self.passes = 0
        self.fails = 0
        self.warns = 0

    def ok(self, msg: str):
        self.passes += 1
        print(f"  [PASS] {msg}")

    def fail(self, msg: str):
        self.fails += 1
        print(f"  [FAIL] {msg}")

    def warn(self, msg: str):
        self.warns += 1
        print(f"  [WARN] {msg}")
    def summary(self) -> int:
        total = self.passes + self.fails + self.warns
        print(f"\n总计: {self.passes} PASS, {self.fails} FAIL, {self.warns} WARN (共 {total} 项)")
        return 1 if self.fails > 0 else 0


def parse_frontmatter(text: str) -> dict | None:
    """解析 markdown 文件开头的 YAML frontmatter。"""
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return None
    fm = {}
    for line in m.group(1).strip().split("\n"):
        if ":" not in line:
            continue
        key, _, val = line.partition(":")
        fm[key.strip()] = val.strip().strip('"').strip("'")
    return fm


def get_section_content(text: str, header: str) -> str | None:
    """提取 ## header 下到下一个 ## 或文件末尾之间的内容。"""
    pattern = re.compile(
        rf"^{re.escape(header)}\s*\n(.*?)(?=^## |\Z)",
        re.MULTILINE | re.DOTALL,
    )
    m = pattern.search(text)
    return m.group(1).strip() if m else None


def read_md(path: Path) -> str:
    return path.read_text(encoding="utf-8")


# ── 各检查项 ────────────────────────────────────────────────

def check_directory_structure(wiki: Path, r: Report):
    print("\n[1] 目录结构")
    ok = True
    for name in ["ideas", "experiments", "claims"]:
        d = wiki / name
        if d.is_dir():
            r.ok(f"{name}/ 存在")
        else:
            r.fail(f"{name}/ 不存在")
            ok = False
    for name in ["index.md", "log.md"]:
        f = wiki / name
        if f.is_file():
            r.ok(f"{name} 存在")
        else:
            r.fail(f"{name} 不存在")
            ok = False
    return ok


def check_file_counts(wiki: Path, r: Report) -> tuple[list[Path], list[Path], list[Path]]:
    print("\n[2] 文件数量")
    ideas = sorted((wiki / "ideas").glob("*.md"))
    exps = sorted((wiki / "experiments").glob("*.md"))
    claims = sorted((wiki / "claims").glob("*.md"))

    r.ok(f"ideas: {len(ideas)}, experiments: {len(exps)}, claims: {len(claims)}")

    if len(ideas) == len(exps) == len(claims):
        r.ok("三类实体数量一致")
    else:
        r.fail(f"数量不一致: ideas={len(ideas)}, experiments={len(exps)}, claims={len(claims)}")

    if len(ideas) == 0:
        r.fail("ideas/ 为空，没有生成任何记录")
    return ideas, exps, claims


def check_idea_frontmatter(fm: dict, fname: str, r: Report):
    if fm.get("type") != "idea":
        r.fail(f"{fname}: type 应为 'idea'，实际 '{fm.get('type')}'")
    if not fm.get("node_id", "").startswith("idea:"):
        r.fail(f"{fname}: node_id 应以 'idea:' 开头")
    if fm.get("iteration_type") not in VALID_ITERATION_TYPES:
        r.fail(f"{fname}: iteration_type '{fm.get('iteration_type')}' 不合法")
    if fm.get("outcome") not in VALID_OUTCOMES:
        r.fail(f"{fname}: outcome '{fm.get('outcome')}' 不合法")
    else:
        r.ok(f"{fname}: frontmatter 合规")


def check_exp_frontmatter(fm: dict, fname: str, r: Report):
    if fm.get("type") != "experiment":
        r.fail(f"{fname}: type 应为 'experiment'，实际 '{fm.get('type')}'")
    if not fm.get("node_id", "").startswith("exp:"):
        r.fail(f"{fname}: node_id 应以 'exp:' 开头")
    if not fm.get("idea_ref", "").startswith("idea:"):
        r.fail(f"{fname}: idea_ref 应以 'idea:' 开头")
    else:
        r.ok(f"{fname}: frontmatter 合规")


def check_claim_frontmatter(fm: dict, fname: str, r: Report):
    if fm.get("type") != "claim":
        r.fail(f"{fname}: type 应为 'claim'，实际 '{fm.get('type')}'")
    if fm.get("verdict") not in VALID_VERDICTS:
        r.fail(f"{fname}: verdict '{fm.get('verdict')}' 不合法")
    if fm.get("confidence") not in VALID_CONFIDENCES:
        r.fail(f"{fname}: confidence '{fm.get('confidence')}' 不合法")
    if not fm.get("idea_ref", "").startswith("idea:"):
        r.fail(f"{fname}: idea_ref 应以 'idea:' 开头")
    if not fm.get("exp_ref", "").startswith("exp:"):
        r.fail(f"{fname}: exp_ref 应以 'exp:' 开头")
    else:
        r.ok(f"{fname}: frontmatter 合规")


def check_sections(text: str, required: list[str], fname: str, r: Report):
    for section in required:
        content = get_section_content(text, section)
        if content is None:
            r.fail(f"{fname}: 缺少节 '{section}'")
        elif not content:
            r.warn(f"{fname}: 节 '{section}' 内容为空")
        else:
            r.ok(f"{fname}: '{section}' 存在且非空")


def check_claim_evidence_against(text: str, fname: str, r: Report):
    content = get_section_content(text, "## 反对证据")
    if content is None or not content.strip():
        r.fail(f"{fname}: 反对证据为空（即使 verdict=supported 也应有内容）")


def check_referential_integrity(wiki: Path, exps: list[Path], claims: list[Path], r: Report):
    print("\n[5] 引用完整性")
    idea_stems = {p.stem for p in (wiki / "ideas").glob("*.md")}
    exp_stems = {p.stem for p in (wiki / "experiments").glob("*.md")}

    for p in exps:
        fm = parse_frontmatter(read_md(p))
        if fm and fm.get("idea_ref"):
            ref_id = fm["idea_ref"].removeprefix("idea:")
            if ref_id in idea_stems:
                r.ok(f"{p.name}: idea_ref → {ref_id} 存在")
            else:
                r.fail(f"{p.name}: idea_ref → {ref_id} 在 ideas/ 中不存在")

    for p in claims:
        fm = parse_frontmatter(read_md(p))
        if not fm:
            continue
        idea_ref = (fm.get("idea_ref") or "").removeprefix("idea:")
        exp_ref = (fm.get("exp_ref") or "").removeprefix("exp:")
        if idea_ref and idea_ref not in idea_stems:
            r.fail(f"{p.name}: idea_ref → {idea_ref} 在 ideas/ 中不存在")
        if exp_ref and exp_ref not in exp_stems:
            r.fail(f"{p.name}: exp_ref → {exp_ref} 在 experiments/ 中不存在")
        if idea_ref in idea_stems and exp_ref in exp_stems:
            r.ok(f"{p.name}: 引用完整")


def check_index_consistency(wiki: Path, r: Report):
    print("\n[6] index.md 一致性")
    index_path = wiki / "index.md"
    if not index_path.is_file():
        r.fail("index.md 不存在，跳过一致性检查")
        return

    text = read_md(index_path)
    linked = set(INDEX_LINK_PATTERN.findall(text))

    all_files = set()
    for sub in ["ideas", "experiments", "claims"]:
        for p in (wiki / sub).glob("*.md"):
            all_files.add(f"{sub}/{p.name}")

    missing_in_index = all_files - linked
    dangling_links = linked - all_files

    if not missing_in_index:
        r.ok(f"所有 {len(all_files)} 个实体文件都在 index.md 中被索引")
    else:
        for f in sorted(missing_in_index):
            r.fail(f"index.md 缺少索引: {f}")

    if not dangling_links:
        r.ok("index.md 无悬空链接")
    else:
        for f in sorted(dangling_links):
            r.fail(f"index.md 包含悬空链接: {f}")


def check_log(wiki: Path, r: Report):
    print("\n[7] log.md 格式")
    log_path = wiki / "log.md"
    if not log_path.is_file():
        r.fail("log.md 不存在")
        return

    lines = [l for l in read_md(log_path).strip().split("\n") if l.strip()]
    if not lines:
        r.fail("log.md 为空")
        return

    r.ok(f"log.md 包含 {len(lines)} 条记录")
    prev_ts = None
    bad_format = 0
    out_of_order = 0
    for i, line in enumerate(lines):
        m = LOG_LINE_PATTERN.match(line)
        if not m:
            bad_format += 1
            if bad_format <= 3:
                r.fail(f"log.md 第 {i+1} 行格式不匹配: {line[:80]}")
            continue
        try:
            ts = datetime.fromisoformat(m.group(1))
            if prev_ts and ts < prev_ts:
                out_of_order += 1
                if out_of_order <= 3:
                    r.fail(f"log.md 第 {i+1} 行时间戳非递增")
            prev_ts = ts
        except ValueError:
            r.fail(f"log.md 第 {i+1} 行时间戳格式错误: {m.group(1)}")

    if bad_format == 0:
        r.ok("log.md 所有行格式正确")
    elif bad_format > 3:
        r.fail(f"log.md 共 {bad_format} 行格式不匹配（仅显示前 3 条）")

    if out_of_order == 0 and prev_ts is not None:
        r.ok("log.md 时间戳单调递增")


def check_no_jinja_residue(wiki: Path, r: Report):
    print("\n[8] 模板残留检查")
    found = []
    for md in wiki.rglob("*.md"):
        text = read_md(md)
        if JINJA_PATTERN.search(text):
            rel = md.relative_to(wiki)
            found.append(str(rel))
            r.fail(f"{rel}: 包含 Jinja2 模板标记残留")
    if not found:
        r.ok("所有 .md 文件无模板残留")


# ── 主流程 ───────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Research Wiki 验证脚本")
    parser.add_argument(
        "wiki_dir",
        nargs="?",
        default="./clustering_workspace/research_wiki",
        help="research_wiki 目录路径（默认 ./clustering_workspace/research_wiki）",
    )
    args = parser.parse_args()
    wiki = Path(args.wiki_dir)

    print("=" * 60)
    print("Research Wiki 验证报告")
    print(f"目录: {wiki.resolve()}")
    print("=" * 60)

    if not wiki.is_dir():
        print(f"\n[FAIL] 目录不存在: {wiki}")
        sys.exit(1)

    r = Report()

    if not check_directory_structure(wiki, r):
        code = r.summary()
        sys.exit(code)

    ideas, exps, claims = check_file_counts(wiki, r)

    print("\n[3] Frontmatter 校验")
    for p in ideas:
        text = read_md(p)
        fm = parse_frontmatter(text)
        if fm is None:
            r.fail(f"{p.name}: 无法解析 frontmatter")
        else:
            check_idea_frontmatter(fm, p.name, r)

    for p in exps:
        text = read_md(p)
        fm = parse_frontmatter(text)
        if fm is None:
            r.fail(f"{p.name}: 无法解析 frontmatter")
        else:
            check_exp_frontmatter(fm, p.name, r)

    for p in claims:
        text = read_md(p)
        fm = parse_frontmatter(text)
        if fm is None:
            r.fail(f"{p.name}: 无法解析 frontmatter")
        else:
            check_claim_frontmatter(fm, p.name, r)

    print("\n[4] Markdown 节结构")
    for p in ideas:
        check_sections(read_md(p), IDEA_REQUIRED_SECTIONS, p.name, r)

    for p in exps:
        check_sections(read_md(p), EXP_REQUIRED_SECTIONS, p.name, r)

    for p in claims:
        text = read_md(p)
        check_sections(text, CLAIM_REQUIRED_SECTIONS, p.name, r)
        check_claim_evidence_against(text, p.name, r)

    check_referential_integrity(wiki, exps, claims, r)
    check_index_consistency(wiki, r)
    check_log(wiki, r)
    check_no_jinja_residue(wiki, r)

    code = r.summary()
    sys.exit(code)


if __name__ == "__main__":
    main()
