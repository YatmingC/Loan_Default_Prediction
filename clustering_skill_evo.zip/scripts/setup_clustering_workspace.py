#!/usr/bin/env python3
"""初始化聚类策略工作空间

运行一次即可创建完整的目录结构
使用方式：
    python scripts/setup_clustering_workspace.py
"""

import os
from pathlib import Path


def create_workspace():
    """创建聚类工作空间目录结构"""
    base = Path("./clustering_workspace")

    print(f"开始创建聚类工作空间: {base.absolute()}")

    # 创建目录结构（skill 放在 .claude/skills 下，供 claude / paseo 自动发现）
    dirs_to_create = [
        base / ".claude" / "skills" / "clustering-strategy" / "references",
        base / ".claude" / "skills" / "clustering-strategy" / "scripts",
        base / ".claude" / "skills" / "research-wiki",
        base / ".claude" / "skills" / "result-to-claim",
        base / "context",
        base / "research_wiki" / "ideas",
        base / "research_wiki" / "experiments",
        base / "research_wiki" / "claims",
    ]

    for dir_path in dirs_to_create:
        dir_path.mkdir(parents=True, exist_ok=True)
        print(f"✓ 创建目录: {dir_path}")

    print(f"\n✅ 聚类工作空间已创建: {base.absolute()}")
    print(f"   - Skill目录: {base / '.claude' / 'skills' / 'clustering-strategy'}")
    print(f"   - 上下文目录: {base / 'context'}")
    print(f"\n说明：")
    print(f"   - SKILL.md 和调参指南已存在")
    print(f"   - analyze_clustering_context.py 脚本已存在")
    print(f"   - 工作空间已就绪，可运行 main_multi_algo.py")


if __name__ == "__main__":
    create_workspace()
