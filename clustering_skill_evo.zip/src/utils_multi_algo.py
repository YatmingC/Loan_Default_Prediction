"""多算法支持的工具函数（扩展版）

与 src/utils.py 的区别：
1. 支持 kmeans/dbscan/gaussian_mixture/spectral 四种算法
2. 新增 call_clustering_strategy_skill_v3 调用聚类策略Skill
3. 新增 validate_clustering_decision 进行决策校验
4. 继承原有的所有其他函数
"""

from src.utils import *  # 继承原有所有函数
from pathlib import Path
import json
import shutil
import numpy as np
import json_repair
from datetime import datetime
from adaptive_clustering.core.clustering import get_clustering_method
from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)


def clean_workspace(workspace_dir: str) -> None:
    workspace = Path(workspace_dir)
    if not workspace.exists():
        return
    # preserve = {".claude", "decision_history", "research_wiki"}
    preserve = {".claude"}
    for item in workspace.iterdir():
        if item.name in preserve:
            continue
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()
    logger.info(f"Workspace已清理: {workspace_dir}（保留 {preserve}）")


def save_decision_record(workspace_dir: str, record: dict) -> None:
    history_dir = Path(workspace_dir) / "decision_history"
    history_dir.mkdir(parents=True, exist_ok=True)
    history_file = history_dir / "decisions.jsonl"
    with open(history_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    logger.info(f"决策记录已追加: iteration={record.get('iteration')}")


def backfill_last_decision_outcome(workspace_dir: str, outcome_metrics: dict) -> None:
    history_file = Path(workspace_dir) / "decision_history" / "decisions.jsonl"
    if not history_file.exists():
        return

    lines = history_file.read_text(encoding="utf-8").strip().split("\n")
    if not lines:
        return

    last_record = json.loads(lines[-1])
    if last_record.get("after_decision_metric") is not None:
        return

    last_record["after_decision_metric"] = outcome_metrics

    before_metric = last_record.get("before_decision_metric") or {}
    prev_f1 = before_metric.get("prev_f1", 0)
    prev_silhouette = before_metric.get("clustering_metrics", {}).get("silhouette_score", 0)
    prev_composite = before_metric.get("clustering_metrics", {}).get("composite_score", 0)

    new_f1 = outcome_metrics.get("overall_f1", 0)
    new_silhouette = outcome_metrics.get("clustering_metrics", {}).get("silhouette_score", 0)
    new_composite = outcome_metrics.get("clustering_metrics", {}).get("composite_score", 0)

    f1_delta = new_f1 - prev_f1
    silhouette_delta = new_silhouette - prev_silhouette
    composite_delta = new_composite - prev_composite

    last_record["impact"] = {
        "f1_delta": round(f1_delta, 4),
        "silhouette_delta": round(silhouette_delta, 4),
        "composite_delta": round(composite_delta, 4),
        "effective": f1_delta > 0 or composite_delta > 0.05
    }

    lines[-1] = json.dumps(last_record, ensure_ascii=False)
    history_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    logger.info(f"回填上一轮决策outcome: f1_delta={f1_delta:.4f}, effective={last_record['impact']['effective']}")


def clustering_func_multi_algo(
    method: str,
    algorithm_params: dict,
    feature_matrix: list,
    raw_dataframe: list
) -> dict:
    """支持多种聚类算法的聚类函数

    与原clustering_func的区别：
    - 支持 kmeans/dbscan/gaussian_mixture/spectral
    - 统一处理各算法的输出格式

    Args:
        method: 聚类方法名 (kmeans/dbscan/gaussian_mixture/spectral)
        algorithm_params: 算法参数字典
        feature_matrix: 预处理后的特征向量矩阵
        raw_dataframe: 每行一个dict，包含所有原始列

    Returns:
        dict: 聚类结果，包含method_name, model, params, cluster_ids等
    """
    import numpy as np

    # 参数校验
    supported_methods = ["kmeans", "dbscan", "gaussian_mixture", "spectral"]
    if method not in supported_methods:
        raise ValueError(f"不支持的聚类方法: {method}，支持: {supported_methods}")

    logger.info(f"执行聚类: method={method}, params={algorithm_params}")

    # 转换为numpy数组
    feature_matrix_np = np.array(feature_matrix, dtype=float)

    # 动态实例化聚类算法
    clustering_method = get_clustering_method(method, params=algorithm_params)

    # 执行聚类
    cluster_result = clustering_method.run(feature_matrix_np)

    # 构建簇样本数据（与原逻辑相同）
    cluster_ids = sorted(set(cluster_result.labels) - {-1})
    cluster_samples = []
    for cid in cluster_ids:
        cluster_indices = [i for i, label in enumerate(cluster_result.labels) if label == cid]
        cluster_rows = [raw_dataframe[i] for i in cluster_indices if i < len(raw_dataframe)]
        cluster_samples.append({
            "cluster_id": cid,
            "samples": cluster_rows,
            "n_samples": len(cluster_rows),
        })

    return {
        "method_name": method,
        "method_class": clustering_method,  # 保留类引用以获取param_space
        "model": cluster_result.model,
        "params": clustering_method.params.copy(),
        "cluster_ids": cluster_ids,
        "cluster_samples": cluster_samples,
        "cluster_labels": [f"cluster_{cid}" for cid in cluster_ids],
        "labels": cluster_result.labels,
    }


def apply_clustering_priors(
    feature_matrix: list[list[float]],
    feature_names: list[str],
    custom_features: list[dict] | None = None,
    feature_weights: dict[str, float] | None = None,
) -> tuple[list[list[float]], list[str]]:
    """对特征矩阵应用聚类先验（权重缩放 + 自定义线性组合特征）。

    在 build_feature_matrix（含 StandardScaler）之后、clustering_func_multi_algo 之前调用。
    """
    mat = np.array(feature_matrix, dtype=float)
    names = list(feature_names)
    name_to_idx = {name: idx for idx, name in enumerate(names)}

    if feature_weights:
        for fname, weight in feature_weights.items():
            if fname in name_to_idx:
                mat[:, name_to_idx[fname]] *= weight

    if custom_features:
        for cf in custom_features:
            cf_name = cf.get("name", "custom")
            components = cf.get("components", {})
            new_col = np.zeros(mat.shape[0])
            for comp_name, coeff in components.items():
                if comp_name in name_to_idx:
                    new_col += coeff * mat[:, name_to_idx[comp_name]]
            mat = np.hstack([mat, new_col.reshape(-1, 1)])
            names.append(cf_name)

    return mat.tolist(), names


def call_clustering_strategy_skill_v3(
    iteration: int,
    context: dict,
    workspace_dir: str = "./clustering_workspace",
    max_retries: int = 3,
    clustering_prior: str = ""
) -> dict:
    """调用聚类策略skill（v3：符合JiuwenSwarm规范，带重试纠错）

    工作流程：
    1. 序列化上下文数据到 workspace/context/
    2. 通过交互式session调用JiuwenSwarm Agent，cwd=workspace_dir
    3. Agent加载 skills/clustering-strategy/SKILL.md
    4. Agent执行决策流程并输出JSON
    5. 解析并校验决策，校验失败时反馈错误让Agent修正

    Args:
        iteration: 当前迭代轮次
        context: 包含所有输入数据的字典
        workspace_dir: 聚类工作空间根目录
        max_retries: 校验失败时最大重试次数
        clustering_prior: 人工聚类先验内容（自然语言），为空则不注入

    Returns:
        dict: 聚类决策，包含reasoning, cluster_func_name, params, exclude_features,
              以及可选的 custom_features, feature_weights
    """
    import numpy as np

    # 1. 序列化上下文数据到workspace/context/
    context_dir = Path(workspace_dir) / "context"
    context_dir.mkdir(parents=True, exist_ok=True)

    context_file = context_dir / f"iteration_{iteration}_context.json"

    # 分离大对象（feature_matrix）单独存储
    feature_matrix = context.pop("feature_matrix", None)
    if feature_matrix is not None:
        feature_matrix_file = context_dir / f"iteration_{iteration}_feature_matrix.npy"
        np.save(feature_matrix_file, np.array(feature_matrix))
        context["feature_matrix_path"] = str(feature_matrix_file)
        logger.info(f"特征矩阵已保存到: {feature_matrix_file}")

    # 保存剩余上下文（JSON可序列化部分）
    with open(context_file, "w", encoding="utf-8") as f:
        json.dump(context, f, ensure_ascii=False, indent=2)
    logger.info(f"上下文已保存到: {context_file}")

    # 2. 构造Prompt
    prior_section = ""
    if clustering_prior:
        prior_section = f"""
## 人工聚类先验

用户提供了以下聚类先验知识，请在决策中参考这些先验来设定 custom_features 和 feature_weights 字段：

{clustering_prior}
"""

    prompt = f"""请根据聚类策略Skill（.claude/skills/clustering-strategy/SKILL.md）的流程，分析当前聚类效果并给出优化建议。

## 输入数据位置
上下文文件：context/iteration_{iteration}_context.json
特征矩阵：context/iteration_{iteration}_feature_matrix.npy
历史决策库：decision_history/decisions.jsonl（JSONL格式，每行一条历史记录，包含before_decision_metric、after_decision_metric和impact字段）

## 任务要求
请严格按照Skill定义的步骤执行：
1. 读取上下文文件，了解数据特征和历史聚类结果
1.5. 读取 decision_history/decisions.jsonl，分析历史决策的效果，识别已证明无效的参数组合（impact.effective=false），通过before_decision_metric和after_decision_metric对比决策前后效果
2. 运行 python .claude/skills/clustering-strategy/scripts/analyze_clustering_context.py --context context/iteration_{iteration}_context.json 分析特征
3. 分析聚类质量指标和簇级反馈
4. 根据决策树选择最优算法
5. 配置算法参数
6. （可选）建议剔除特征
7. （可选）根据人工先验设定自定义特征和特征权重
8. 输出结构化决策（JSON格式）
{prior_section}
## 输出格式要求
你必须严格按照以下JSON格式输出决策（包裹在```json```代码块中）：

```json
{{
  "reasoning": "你的推理过程（200字以内）：为什么选择这个算法？参数如何调整？是否剔除特征？",
  "cluster_func_name": "kmeans|dbscan|gaussian_mixture|spectral",
  "params": {{
    // 算法参数，根据cluster_func_name不同而不同
  }},
  "exclude_features": [],  // 可选，要剔除的特征列名数组
  "custom_features": [  // 可选，仅当人工先验存在时输出
    {{"name": "自定义特征名", "components": {{"原特征A": 系数, "原特征B": 系数}}}}
  ],
  "feature_weights": {{  // 可选，仅当人工先验存在时输出
    "特征名": 权重乘数  // 默认1.0，>1强调，<1弱化
  }}
}}
```

## 重要约束
- 禁止连续两轮切换算法（检查algorithm_switch_history）
- 禁止选择Spectral当样本数 > 5000
- 参数必须在合法范围内（参考references/中的调参指南）
- reasoning必须清晰说明决策依据
- custom_features 和 feature_weights 仅在人工先验段存在时需要输出，否则可省略
"""

    # 3. 通过 paseo 交互式 agent 调用（支持重试纠错）
    #    paseo 输出需通过 fetch_agent_logs 抓取，再用 extract_last_json_block 解析
    logger.info(f"调用clustering_strategy_skill: iteration={iteration}, cwd={workspace_dir}")

    agent_id = interactive_agent(cwd=workspace_dir, prompt=prompt)["agent_id"]

    agent_logs = fetch_agent_logs(agent_id)
    decision = extract_last_json_block(agent_logs)

    # 4. 解析并校验，失败时重试
    for attempt in range(1, max_retries + 1):
        if decision is None:
            errors = ["未在回复中找到有效的 ```json``` 围栏代码块"]
        elif not isinstance(decision, dict):
            errors = [f"输出必须是JSON对象，得到 {type(decision).__name__}"]
        else:
            # 校验决策合法性
            try:
                validate_clustering_decision(decision, context)
                errors = []
            except ValueError as e:
                errors = [str(e)]

        if not errors:
            logger.info(f"聚类策略决策（attempt={attempt}）: {decision.get('reasoning', 'N/A')}")
            logger.info(f"选择算法: {decision['cluster_func_name']}, 参数: {decision['params']}")
            return decision

        # 校验失败，反馈给Agent修正
        if attempt >= max_retries:
            raise ValueError(f"聚类策略决策校验失败（已重试{max_retries}次）:\n" + "\n".join(errors))

        errors_msg = "\n".join(errors)
        logger.warning(f"决策校验失败（attempt={attempt}）: {errors_msg}")

        retry_prompt = (
            f"你的输出解析时提示以下错误：\n{errors_msg}\n\n"
            f"请重新以 ```json``` 围栏代码块的形式给出修正后的完整JSON决策。"
        )
        interactive_agent_send_message(
            agent_id=agent_id, prompt=retry_prompt, cwd=workspace_dir
        )
        agent_logs = fetch_agent_logs(agent_id)
        decision = extract_last_json_block(agent_logs)


def validate_clustering_decision(decision: dict, context: dict) -> None:
    """校验聚类决策的合法性

    检查项：
    - 算法名称是否支持
    - 参数是否在合法范围内
    - 是否违反连续切换规则
    - Spectral是否满足样本数限制
    - exclude_features是否合法

    Args:
        decision: Agent输出的决策字典
        context: 上下文信息（用于检查历史和候选特征）

    Raises:
        ValueError: 校验失败时抛出，包含详细错误信息
    """
    errors = []

    # 检查必需字段
    if not isinstance(decision, dict):
        raise ValueError(f"决策必须是字典类型，得到: {type(decision).__name__}")

    required_fields = ["reasoning", "cluster_func_name", "params"]
    for field in required_fields:
        if field not in decision:
            errors.append(f"缺失必需字段: {field}")

    if errors:
        raise ValueError(f"决策格式错误: {'; '.join(errors)}")

    # 校验算法名
    algorithm = decision["cluster_func_name"]
    supported = ["kmeans", "dbscan", "gaussian_mixture", "spectral"]
    if algorithm not in supported:
        errors.append(f"不支持的算法: {algorithm}，支持: {supported}")

    # 校验算法参数
    if not errors:  # 只有算法名有效才校验参数
        try:
            method = get_clustering_method(algorithm)
            param_space = method.get_param_space()
            param_errors = param_space.validate_params(decision["params"])
            if param_errors:
                errors.extend([f"参数错误: {err}" for err in param_errors])
        except Exception as e:
            errors.append(f"参数校验异常: {str(e)}")

    # 校验exclude_features
    if "exclude_features" in decision:
        excl = decision["exclude_features"]
        candidate_features = context.get("candidate_features", [])

        if not isinstance(excl, list):
            errors.append(f"exclude_features必须是数组，得到: {type(excl).__name__}")
        else:
            cand_set = set(candidate_features)
            bad = [c for c in excl if not isinstance(c, str) or c not in cand_set]
            if bad:
                errors.append(f"exclude_features含非法列名: {bad}，候选: {candidate_features}")

            remaining = len(candidate_features) - len(set(excl))
            if remaining < 1:
                errors.append("exclude_features不能剔除全部特征，至少保留1列")

            if len(excl) > len(candidate_features) * 0.5:
                logger.warning(f"exclude_features剔除了{len(excl)}/{len(candidate_features)}列（>{50}%），可能过度剔除")

    # 防止连续切换算法
    algorithm_switch_history = context.get("algorithm_switch_history", [])
    prev_method = context.get("prev_method")
    current_iteration = context.get("iteration", 0)

    if len(algorithm_switch_history) > 0:
        last_switch = algorithm_switch_history[-1]
        # 如果上一轮刚切换，本轮不允许再切换
        if last_switch["iteration"] == current_iteration - 1:
            if algorithm != prev_method:
                error_msg = (
                    f"禁止连续切换算法：上一轮已从{last_switch['from']}切换到{last_switch['to']}，"
                    f"本轮不允许再切换到{algorithm}"
                )
                errors.append(error_msg)
                logger.warning(error_msg)

    # Spectral限制：样本数过大时禁止
    if algorithm == "spectral":
        n_samples = context.get("n_samples", 0)
        if n_samples > 5000:
            errors.append(
                f"Spectral Clustering不适用于大规模数据（当前N={n_samples} > 5000），"
                f"计算复杂度O(N³)，请选择其他算法"
            )

    # 校验 custom_features（可选字段）
    if "custom_features" in decision:
        cfs = decision["custom_features"]
        if not isinstance(cfs, list):
            errors.append(f"custom_features必须是数组，得到: {type(cfs).__name__}")
        else:
            for i, cf in enumerate(cfs):
                if not isinstance(cf, dict):
                    errors.append(f"custom_features[{i}]必须是对象")
                    continue
                if "name" not in cf or "components" not in cf:
                    errors.append(f"custom_features[{i}]缺少'name'或'components'字段")
                    continue
                if not isinstance(cf["components"], dict):
                    errors.append(f"custom_features[{i}].components必须是字典")
                    continue
                for comp_name, coeff in cf["components"].items():
                    if not isinstance(coeff, (int, float)):
                        errors.append(f"custom_features[{i}].components[{comp_name}]系数必须是数值")

    # 校验 feature_weights（可选字段）
    if "feature_weights" in decision:
        fw = decision["feature_weights"]
        if not isinstance(fw, dict):
            errors.append(f"feature_weights必须是字典，得到: {type(fw).__name__}")
        else:
            for fname, weight in fw.items():
                if not isinstance(weight, (int, float)):
                    errors.append(f"feature_weights[{fname}]权重必须是数值")
                elif weight < 0:
                    errors.append(f"feature_weights[{fname}]权重不能为负: {weight}")
                elif weight > 10.0:
                    errors.append(f"feature_weights[{fname}]权重超过上限10.0: {weight}")

    # 如果有错误，抛出异常
    if errors:
        error_summary = "\n".join([f"  - {err}" for err in errors])
        raise ValueError(f"聚类决策校验失败:\n{error_summary}")

    logger.info("✓ 聚类决策校验通过")


def compute_cluster_statistics(labels: list) -> dict:
    """计算簇结构统计信息

    统计项：
    - n_clusters: 有效簇数量（不含噪声点-1）
    - single_sample_clusters: 单样本簇数量
    - max_cluster_ratio: 最大簇占比
    - noise_ratio: 噪声点占比（DBSCAN）
    - min/max/avg_cluster_size: 簇大小统计

    Args:
        labels: 聚类标签列表

    Returns:
        dict: 簇统计信息
    """
    from collections import Counter

    counter = Counter(labels)
    n_samples = len(labels)
    unique_labels = set(labels) - {-1}
    n_clusters = len(unique_labels)

    if n_clusters == 0:
        return {
            "n_clusters": 0,
            "single_sample_clusters": 0,
            "max_cluster_ratio": 0.0,
            "noise_ratio": counter.get(-1, 0) / n_samples if n_samples > 0 else 0.0,
            "min_cluster_size": 0,
            "max_cluster_size": 0,
            "avg_cluster_size": 0.0
        }

    cluster_sizes = [counter[label] for label in unique_labels]
    single_sample_clusters = sum(1 for size in cluster_sizes if size == 1)
    max_cluster_size = max(cluster_sizes)
    min_cluster_size = min(cluster_sizes)
    avg_cluster_size = sum(cluster_sizes) / len(cluster_sizes)

    return {
        "n_clusters": n_clusters,
        "single_sample_clusters": single_sample_clusters,
        "max_cluster_ratio": max_cluster_size / n_samples if n_samples > 0 else 0.0,
        "noise_ratio": counter.get(-1, 0) / n_samples if n_samples > 0 else 0.0,
        "min_cluster_size": min_cluster_size,
        "max_cluster_size": max_cluster_size,
        "avg_cluster_size": avg_cluster_size
    }
