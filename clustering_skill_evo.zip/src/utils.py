from typing import Any
import subprocess
import shutil
import json
import os
import re
import uuid
import concurrent.futures

import pandas as pd
import numpy as np

from adaptive_clustering.core.preprocessing import DataFramePreprocessor, ColumnRole
from adaptive_clustering.core.clustering import get_clustering_method
from src.prompt_template import render
from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)

# 全局 provider 配置，由 main 入口调用 setup_provider 设置
_harness_provider = "claude"
_model_provider = "glm-5.1"

# 二进制路径
_PASEO_BIN = shutil.which('paseo')
_CLAUDE_BIN = shutil.which('claude')

env = os.environ.copy()
env["PASEO_HOME"] = os.path.expanduser("~/.paseo")

# 长 prompt 写入文件的字符阈值：超过此值时改走文件路径，避免 OSError: Argument list too long
# （Linux ARG_MAX 限制单条命令参数总长，中文 UTF-8 占 3 字节，2w 字符约 6w 字节，
# 留足安全余量；短 prompt 仍走命令行以避免不必要的 I/O 开销和 agent 行为差异）
_PROMPT_FILE_THRESHOLD = 20000
# 临时 prompt 文件存放的子目录名（相对于 agent cwd）
_PROMPT_DIR_NAME = "temp_prompt"
# 占位指令模板：让 agent 去读文件中的真实 prompt
_FILE_PROMPT_PLACEHOLDER = "请阅读当前目录下 {rel_path} 文件中的任务内容并执行。"


def setup_provider(harness_provider: str = "claude", model_provider: str = "glm-5.1"):
    global _harness_provider, _model_provider
    _harness_provider = harness_provider
    _model_provider = model_provider


def _get_mode() -> str:
    return "general" if _harness_provider == "opencode" else "bypassPermissions"


def _get_provider() -> str:
    return f"{_harness_provider}/skill_evo/{_model_provider}" if _harness_provider == "opencode" else f"{_harness_provider}/{_model_provider}"


def _should_use_file_prompt(prompt: str) -> bool:
    """判断是否需要将 prompt 写入文件以绕过 ARG_MAX 限制。

    - 以 '/' 开头的控制指令（如 /compact）免阈值，始终走命令行
    - 其余业务 prompt 超过 _PROMPT_FILE_THRESHOLD 字符时走文件路径
    """
    if not prompt:
        return False
    # /compact 等控制指令长度极短，无需文件化
    if prompt.lstrip().startswith("/"):
        return False
    return len(prompt) > _PROMPT_FILE_THRESHOLD


def _write_prompt_file(cwd: str, prompt: str) -> str:
    """将长 prompt 写入 cwd 下的 temp_prompt/ 目录，返回相对路径。

    文件名 prompt_{uuid[:20]}.txt，目录创建加 exist_ok=True。
    返回相对于 cwd 的路径（供占位指令使用）。
    """
    prompt_dir = os.path.join(cwd, _PROMPT_DIR_NAME)
    os.makedirs(prompt_dir, exist_ok=True)
    file_name = f"prompt_{uuid.uuid4().hex[:20]}.txt"
    file_path = os.path.join(prompt_dir, file_name)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(prompt)
    # 返回相对路径，让 agent 在其 cwd 下能读到
    rel_path = os.path.join(_PROMPT_DIR_NAME, file_name)
    return rel_path


def _resolve_prompt(cwd: str, prompt: str) -> tuple[str, str | None]:
    """根据 prompt 长度决定传参方式。

    :returns: (effective_prompt, file_to_cleanup)
        - effective_prompt: 实际传给 paseo 的 prompt（短则原样，长则占位指令）
        - file_to_cleanup: 需要清理的文件绝对路径；None 表示无需清理
    """
    if not _should_use_file_prompt(prompt):
        return prompt, None
    rel_path = _write_prompt_file(cwd, prompt)
    effective = _FILE_PROMPT_PLACEHOLDER.format(rel_path=rel_path)
    abs_path = os.path.join(cwd, rel_path)
    return effective, abs_path


def _cleanup_prompt_file(file_path: str | None) -> None:
    """安全删除临时 prompt 文件，忽略已不存在的情况。"""
    if file_path is None:
        return
    try:
        os.remove(file_path)
    except OSError as e:
        logger.warning(f"清理临时 prompt 文件失败 {file_path}: {e}")


def dataload(
    data_path: str,
    columns_desc_path: str
) -> dict:
    """数据加载与预处理 ComputeNode 函数。

    从 xlsx 文件加载原始数据，使用 DataFramePreprocessor 进行特征预处理，
    提取特征矩阵和所有原始列数据供下游使用。

    :param data_path: 数据文件路径（xlsx）
    :param columns_desc_path: 列描述文件路径（xlsx）
    :returns: 匹配 LoadedData schema 的输出字典
    """
    label_column = "Default"

    # 加载列配置
    column_configs = DataFramePreprocessor.load_column_configs(columns_desc_path)

    # 初始化预处理器并 fit_transform
    preprocessor = DataFramePreprocessor(column_configs=column_configs)
    df = pd.read_excel(data_path)
    # add logic
    if "feedback" not in df.columns.tolist():
        df["feedback"] = ""
        print("origin data not feedback， add empty feedback！")
    result = preprocessor.fit_transform(df, label_column=label_column)

    # 提取原始数据（所有列）和预处理后的特征矩阵
    raw_dataframe = df.to_dict(orient="records")
    feature_matrix = result.dataset.feature_matrix.tolist()

    # 候选聚类特征：所有 role==CLUSTERING 的原始列名
    candidate_features = [c.name for c in column_configs if c.role == ColumnRole.CLUSTERING]

    return {
        "raw_dataframe": raw_dataframe,
        "feature_matrix": feature_matrix,
        "column_configs": column_configs,
        "df": df,
        "candidate_features": candidate_features,
    }


def build_feature_matrix(
    df: pd.DataFrame,
    column_configs: list,
    selected_columns: list[str],
    label_column: str = "Default",
) -> tuple[list, list]:
    """按选定的原始列子集重建特征矩阵。

    每轮聚类迭代时，根据 agent 的 exclude 选择计算出本轮要使用的列子集
    `selected_columns`，复用同一份列配置重新预处理，得到对应的特征矩阵与
    编码后特征名。

    :param df: 原始 DataFrame
    :param column_configs: 列配置（来自 dataload，会被深拷贝以免跨轮污染）
    :param selected_columns: 本轮参与聚类的原始列名（候选列剔除后剩余）
    :param label_column: 标签列名
    :returns: (feature_matrix, feature_names) 特征矩阵列表与编码后特征名列表
    """
    # 深拷贝列配置，避免 fit_transform 就地修改 participate_in_clustering 污染跨轮状态
    configs = [c.model_copy(deep=True) for c in column_configs]
    preprocessor = DataFramePreprocessor(column_configs=configs)
    result = preprocessor.fit_transform(
        df, label_column=label_column, clustering_columns=selected_columns
    )
    return result.dataset.feature_matrix.tolist(), result.feature_names


def clustering_func(
    method: str = "dbscan",
    algorithm_params: dict = {},
    feature_matrix: list = [],
    raw_dataframe: list = []
) -> dict:
    """

    优先使用 OptimizationNode 的更新参数（循环迭代时），否则使用默认值。
    重要约束：聚类特征不包含 Default（ground truth）字段。

    :param method: 聚类方法
    :param algorithm_params: 算法参数
    :param feature_matrix: 预处理后的特征向量矩阵
    :param raw_dataframe: 每行一个dict，包含所有原始列
    :returns: 匹配 ClusteringResult schema 的输出字典
    """
    # 优先使用 OptimizationNode 的更新参数（循环迭代时），否则使用默认值
    method_name = method
    params = algorithm_params

    # 将特征矩阵转为 numpy 数组
    feature_matrix_np = np.array(feature_matrix, dtype=float)

    # 通过工厂函数动态实例化聚类算法
    clustering_method = get_clustering_method(method_name, params=params)

    # 执行聚类
    cluster_result = clustering_method.run(feature_matrix_np)

    # 构建每簇完整样本数据
    cluster_ids = sorted(set(cluster_result.labels) - {-1})
    cluster_samples = []
    for cid in cluster_ids:
        cluster_indices = [i for i, label in enumerate(cluster_result.labels) if label == cid]
        cluster_rows = [raw_dataframe[i] for i in cluster_indices if i < len(raw_dataframe)]
        cluster_samples.append({
            "cluster_id": cid,
            "samples": cluster_rows,
            "n_samples": len(cluster_rows),
        })

    return {
        "method_name": method_name,
        "method_class": clustering_method,
        "model": cluster_result.model,
        "params": clustering_method.params.copy(),
        "cluster_ids": cluster_ids,
        "cluster_samples": cluster_samples,
        "cluster_labels": [f"cluster_{cid}" for cid in cluster_ids],
        "labels": cluster_result.labels,
    }


def metrics_collect(
    validated: bool = False,
    validation_details: str = "",
    skill_folder_path: str = "",
    skill_description: str = "",
    cluster_id: int = 0,
    samples: list = [],
    _parallel_rank: int = 0,
    **kwargs: Any,
) -> dict:
    """单簇指标收集 ComputeNode 函数（子图内部）。

    基于 Default 字段和验证输出计算单簇 precision/recall/f1。

    :param validated: Skill 是否通过验证
    :param validation_details: 验证过程描述
    :param skill_folder_path: Skill 文件夹路径
    :param skill_description: Skill 描述
    :param cluster_id: 簇 ID
    :param samples: 当前簇的样本数据（含 Default 字段）
    :param _parallel_rank: 并行分支编号
    :param kwargs: 其他上游数据（自动透传）
    :returns: 匹配 ClusterMetrics schema 的输出字典
    """
    # 使用 _parallel_rank 确定当前处理哪个簇
    effective_cluster_id = cluster_id or _parallel_rank

    # 基于 Default 字段计算 precision/recall
    correct_set: list[dict] = []
    incorrect_set: list[dict] = []
    correct_count = 0
    total_count = len(samples)

    for sample in samples:
        default_val = sample.get("Default", 0)
        # 使用 validated 字段作为该簇整体预测效果的代理指标
        predicted = validated
        if (predicted and default_val == 1) or (not predicted and default_val == 0):
            correct_set.append(sample)
            correct_count += 1
        else:
            incorrect_set.append(sample)

    precision = correct_count / total_count if total_count > 0 else 0.0
    recall = correct_count / total_count if total_count > 0 else 0.0
    f1_score = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

    return {
        "cluster_id": effective_cluster_id,
        "precision": precision,
        "recall": recall,
        "f1_score": f1_score,
        "total_samples": total_count,
        "correct_prediction_set": correct_set,
        "incorrect_prediction_set": incorrect_set,
        "skill_used": skill_folder_path or skill_description,
    }


def clean_agent_env():
    """重启 paseo 服务，清理残留 agent 环境。"""
    subprocess.run([_PASEO_BIN, "restart"], env=env)


def interactive_agent(cwd, prompt):
    """启动新的 paseo agent 会话并发送初始 prompt。

    返回包含 'agent_id' 和 'status' 的字典。后续通过 interactive_agent_send_message
    复用该 agent_id，通过 fetch_agent_logs 获取输出。
    """
    effective_prompt, file_to_cleanup = _resolve_prompt(cwd, prompt)
    try:
        result = subprocess.run(
            [_PASEO_BIN, "run", "--mode", _get_mode(),
             "--provider", _get_provider(), "--json", effective_prompt],
            cwd=cwd,
            text=True,
            encoding="utf-8",
            capture_output=True,
            env=env
        )
        if result.stderr:
            print(f"result.stderr:{result.stderr}")
        agent_info = json.loads(result.stdout.strip())
        return {
            "agent_id": agent_info["agentId"],
            "status": agent_info["status"]
        }
    finally:
        _cleanup_prompt_file(file_to_cleanup)


def interactive_agent_send_message(agent_id, prompt, cwd=None):
    """向已有 agent session 发送消息。

    :param agent_id: paseo agent id
    :param prompt: 消息内容（/compact 等控制指令免阈值判断）
    :param cwd: agent 工作目录；prompt 需要文件化时用于确定 temp_prompt 位置。
                若为 None 且 prompt 超阈值，会回退到当前进程 cwd。
    """
    effective_cwd = cwd or os.getcwd()
    effective_prompt, file_to_cleanup = _resolve_prompt(effective_cwd, prompt)
    try:
        subprocess.run(
            [_PASEO_BIN, "send", agent_id, effective_prompt],
            cwd=effective_cwd,
            text=True,
            encoding="utf-8",
            capture_output=True,
            env=env
        )
    finally:
        _cleanup_prompt_file(file_to_cleanup)


def fetch_agent_logs(agent_id: str) -> str:
    """抓取指定 agent 的完整日志输出

    通过 `paseo logs <agent_id>` 拉取，返回 stdout（包含 [User] / [Thought] /
    助手回复等所有片段，按时间顺序）。

    Args:
        agent_id: paseo agent id

    Returns:
        str: paseo logs 的标准输出
    """
    result = subprocess.run(
        [_PASEO_BIN, "logs", agent_id],
        capture_output=True,
        text=True,
        encoding='utf-8',
        env=env
    )
    return result.stdout


_JSON_FENCE_RE = re.compile(r"```json\s*\n(.*?)\n```", re.DOTALL | re.IGNORECASE)


def extract_last_json_block(text: str) -> dict | list | None:
    """从一段文本里抠出最后一个 ```json ... ``` 围栏块并解析

    用于解析 paseo logs 里的助手最终输出。会从后向前尝试，遇到第一个能成功
    `json.loads` 的块就返回；都失败则返回 None。

    Args:
        text: 待解析的文本

    Returns:
        dict | list | None: 解析后的 JSON 对象，无可解析块时返回 None
    """
    matches = _JSON_FENCE_RE.findall(text or "")
    for raw in reversed(matches):
        try:
            return json.loads(raw.strip())
        except json.JSONDecodeError:
            continue
    return None


def interactive_agent_send_and_get(agent_id=None, prompt="", cwd=None) -> tuple[str, str]:
    """向 paseo 会话发送消息并返回 (助手输出文本, agent_id)。

    兼容旧版 main.py 的调用签名。paseo 的输出需要通过 logs 抓取，因此这里
    发送后拉取 logs 并返回完整日志文本，调用方可自行用 json_repair /
    extract_last_json_block 解析。

    - 若 agent_id 为 None：通过 interactive_agent 新建会话（需要 cwd）
    - 否则：向已有会话发送消息（复用 cwd 做长 prompt 文件化）
    """
    if agent_id is None:
        agent_id = interactive_agent(cwd or os.getcwd(), prompt)["agent_id"]
    else:
        interactive_agent_send_message(agent_id, prompt, cwd=cwd)
    content = fetch_agent_logs(agent_id)
    return content, agent_id


def run_agent(cwd, output_schema_path, prompt, parser):
    """通过 paseo run 运行一次性 agent 任务，带 output-schema 结构化输出。"""
    effective_prompt, file_to_cleanup = _resolve_prompt(cwd, prompt)
    try:
        result = subprocess.run(
            [_PASEO_BIN, "run", "--mode", _get_mode(),
             "--provider", _get_provider(), "--json", "--output-schema", str(output_schema_path), effective_prompt],
            cwd=cwd,
            text=True,
            encoding="utf-8",
            capture_output=True,
            env=env
        )
        try:
            if result.stderr:
                print(f"result.stderr:{result.stderr}")
            output_message = json.loads(result.stdout.strip())
        except json.JSONDecodeError:
            print("result.stdout", len(result.stdout), result.stdout)
            raise

        return parser(output_message)
    finally:
        _cleanup_prompt_file(file_to_cleanup)


def run_claude_agent(cwd, output_schema_path, prompt, parser):
    """paseo 无法支持大并发，并发交由 claude cli 启动会话完成
    通过 Claude CLI 运行 agent 会话并返回结果

    Args:
        cwd: 工作目录
        output_schema_path: JSON Schema 字典存放路径，用于结构化输出校验。
        prompt: 发送给 Claude 的提示词
        parser: 对 structured_output 做后处理的函数

    Returns:
        parser 处理后的结果
    """
    with open(output_schema_path, "r", encoding="utf-8") as f:
        output_schema = f.read()

    cmd = [
        _CLAUDE_BIN,
        "-p",
        "--output-format", "json",
        "--json-schema", output_schema,
    ]

    cmd.extend(["--safe-mode"])
    # prompt 放在最后
    cmd.append(prompt)

    result = subprocess.run(
        cmd,
        cwd=cwd,
        text=True,
        encoding="utf-8",
        capture_output=True,
        env=env,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"Claude CLI failed (rc={result.returncode}): {result.stderr}"
        )

    output_message = json.loads(result.stdout.strip())
    if output_message.get("is_error"):
        raise RuntimeError(f"Agent session error: {output_message.get('result')}")
    return parser(output_message["structured_output"])


def run_agent_parallel(cwd_list, output_schema_path, prompt_list, parser, max_parallel_size=10):
    """并行执行 run_claude_agent，单任务异常隔离，不因一个失败导致整批降级。

    每个任务独立 try/except：成功返回 parser 结果，失败返回 None。
    调用方（validation_skill / analyse_skill_result）负责将 None 转为各自的占位符。
    """
    def _safe_run(cwd, schema, prompt, p):
        try:
            return run_claude_agent(cwd, schema, prompt, p)
        except Exception as e:
            import traceback
            error_msg = traceback.format_exc()
            print(error_msg)

            logger.warning(f"run_agent 单任务失败，降级为 None: {e}")
            return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_parallel_size) as executor:
        result_iter = executor.map(
            _safe_run,
            cwd_list,
            [output_schema_path] * len(prompt_list),
            prompt_list,
            [parser] * len(prompt_list)
        )

    return list(result_iter)


from pathlib import Path

# 各调用方针对 run_agent_parallel 返回 None 的占位符
# validation_skill：dict 形态，与 parser 返回结构一致
_VALIDATION_PLACEHOLDER = {"risk_reason": "no output", "risk_result": "no output"}
# analyse_skill_result：字符串形态，与 parser 返回结构一致
_ANALYSE_PLACEHOLDER = "no output"


def validation_skill(iteration_dir, prompt_list, max_parallel_size=10):
    project_dir_list = [iteration_dir for _ in prompt_list]
    try:
        tasks_result = run_agent_parallel(
            cwd_list=project_dir_list,
            output_schema_path=Path(__file__).parent.parent / "json_schemas/validation_schema.json",
            prompt_list=[render("validation_skill_wrapper.j2", prompt=prompt) for prompt in prompt_list],
            parser=lambda x: {"risk_reason": x["risk_reason"], "risk_result": "是" if x["risk_result"] else "否"},
            max_parallel_size=max_parallel_size
        )
    except Exception as e:
        import traceback
        error_msg = traceback.format_exc()
        print(error_msg)
        print(f"Validation skill failed: {e}")
        # run_agent_parallel 整体异常（非单任务）时全量降级
        tasks_result = [None for _ in prompt_list]

    # 单任务返回 None 时转为 validation 专属占位符
    return [r if r is not None else _VALIDATION_PLACEHOLDER for r in tasks_result]


def analyse_skill_result(iteration_dir, prompt_list, max_parallel_size=10):
    project_dir_list = [iteration_dir for _ in prompt_list]
    try:
        tasks_result = run_agent_parallel(
            cwd_list=project_dir_list,
            output_schema_path=Path(__file__).parent.parent / "json_schemas/analyse_skill_schema.json",
            prompt_list=[render("analyse_skill_wrapper.j2", prompt=prompt) for prompt in prompt_list],
            parser=lambda x: x["analysis"],
            max_parallel_size=max_parallel_size
        )
    except Exception as e:
        import traceback
        error_msg = traceback.format_exc()
        print(error_msg)
        print(f"analyse_skill_result: {e}")
        # run_agent_parallel 整体异常（非单任务）时全量降级
        tasks_result = [None for _ in prompt_list]

    # 单任务返回 None 时转为 analyse 专属占位符
    return [r if r is not None else _ANALYSE_PLACEHOLDER for r in tasks_result]


def clean_agents(no_clean_agent_ids):
    """删除所有非活跃且不在保留列表中的 paseo agent。"""
    result = subprocess.run(
        [_PASEO_BIN, "ls", "-a", "-g", "--json"],
        capture_output=True,
        text=True,
        encoding='utf-8',
        env=env
    )
    if result.stderr:
        print(f"result.stderr:{result.stderr}")

    all_agents_info = json.loads(result.stdout.strip())
    all_live_agents_info = [agent_info for agent_info in all_agents_info if agent_info["status"] != "closed"]
    if len(all_live_agents_info) == 0:
        print(f"cannot find any paseo progress!")
        return
    else:
        def _delete_one(aid):
            subprocess.run([_PASEO_BIN, "delete", aid], env=env)
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            delete_agents = [
                agent_info["id"] for agent_info in all_live_agents_info if agent_info["id"] not in no_clean_agent_ids
            ]
            executor.map(_delete_one, delete_agents)
        print(f"agents: {delete_agents} have been deleted!")
