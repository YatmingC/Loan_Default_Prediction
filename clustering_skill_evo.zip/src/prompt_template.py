"""Jinja2 模板加载与渲染工具

提供统一的 prompt 模板渲染接口，将模板文件从 templates/ 目录加载并渲染。
"""

from jinja2 import Environment, FileSystemLoader
from pathlib import Path

_TEMPLATE_DIR = Path(__file__).parent.parent / "templates"

_env = Environment(
    loader=FileSystemLoader(str(_TEMPLATE_DIR)),
    keep_trailing_newline=True,
)


def render(template_name: str, **kwargs) -> str:
    """渲染指定模板

    Args:
        template_name: 模板文件名（相对于 templates/ 目录）
        **kwargs: 模板变量

    Returns:
        str: 渲染后的文本
    """
    return _env.get_template(template_name).render(**kwargs)
