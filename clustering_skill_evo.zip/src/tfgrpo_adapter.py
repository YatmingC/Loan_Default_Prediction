"""TFGRPO 适配模块

将 Training-Free GRPO 机制应用到 skill 演进阶段：
- 多 rollout 验证（每样本 N 次）
- 三分法经验提取（全错/半对错/全对）
- 簇级经验聚合
- 统一输出格式：{analysis, operations}
"""

import json
from pathlib import Path
from collections import Counter

from src.utils import run_agent, run_agent_parallel
from src.prompt_template import render
from adaptive_clustering.logger import get_logger

logger = get_logger(__name__)

_SCHEMA_DIR = Path(__file__).parent.parent / "json_schemas"
_UNIFIED_SCHEMA = _SCHEMA_DIR / "tfgrpo_sample_experience_schema.json"
_ADVANTAGE_SCHEMA = _SCHEMA_DIR / "tfgrpo_group_advantage_schema.json"
_AGGREGATE_SCHEMA = _SCHEMA_DIR / "tfgrpo_aggregate_schema.json"


def majority_vote(rollouts: list[dict]) -> dict:
    """对多个 rollout 结果进行多数投票。

    统计 risk_result 的出现次数，返回票数最多的判断。
    平票时取第一个 rollout 的结果（保持确定性）。
    """
    votes = Counter(r["risk_result"] for r in rollouts)
    winner = votes.most_common(1)[0][0]
    for r in rollouts:
        if r["risk_result"] == winner:
            return {"risk_reason": r["risk_reason"], "risk_result": winner}
    return rollouts[0]


def validation_skill_multi_rollout(
    iteration_dir: str,
    prompt_list: list[str],
    num_rollouts: int = 3,
    max_parallel_size: int = 10,
) -> list[list[dict]]:
    """对每个样本执行多次 rollout 验证。

    将 N 个样本展开为 N * num_rollouts 个并行任务，
    执行后按样本索引重新分组为二维结构。
    """
    n_samples = len(prompt_list)
    expanded_prompts = prompt_list * num_rollouts
    expanded_cwds = [iteration_dir] * len(expanded_prompts)

    validation_schema = Path(__file__).parent.parent / "json_schemas/validation_schema.json"
    parser = lambda x: {
        "risk_reason": x["risk_reason"],
        "risk_result": "是" if x["risk_result"] else "否",
    }

    logger.info(f"多 rollout 验证: {n_samples} 样本 × {num_rollouts} rollouts = {len(expanded_prompts)} 任务")

    try:
        flat_results = run_agent_parallel(
            cwd_list=expanded_cwds,
            output_schema_path=validation_schema,
            prompt_list=expanded_prompts,
            parser=parser,
            max_parallel_size=max_parallel_size,
        )
    except Exception as e:
        logger.error(f"多 rollout 验证失败: {e}")
        fallback = {"risk_reason": "no output", "risk_result": "no output"}
        flat_results = [fallback] * len(expanded_prompts)

    grouped: list[list[dict]] = [[] for _ in range(n_samples)]
    for rollout_idx in range(num_rollouts):
        for sample_idx in range(n_samples):
            grouped[sample_idx].append(flat_results[rollout_idx * n_samples + sample_idx])

    return grouped


def _analyze_all_wrong(
    iteration_dir: str,
    group: dict,
) -> dict:
    """全错样本分析（avg_reward = 0），1 步 LLM 调用。"""
    prompt = render(
        "tfgrpo_all_wrong_analysis.j2",
        question=group["question"],
        ground_truth=group["ground_truth"],
        rollouts=group["rollouts"],
    )
    return run_agent(
        cwd=iteration_dir,
        output_schema_path=_UNIFIED_SCHEMA,
        prompt=prompt,
        parser=lambda x: x,
    )


def _analyze_all_correct(
    iteration_dir: str,
    group: dict,
) -> dict:
    """全对样本分析（avg_reward = 1），1 步 LLM 调用。"""
    prompt = render(
        "tfgrpo_all_correct_analysis.j2",
        question=group["question"],
        ground_truth=group["ground_truth"],
        rollouts=group["rollouts"],
    )
    return run_agent(
        cwd=iteration_dir,
        output_schema_path=_UNIFIED_SCHEMA,
        prompt=prompt,
        parser=lambda x: x,
    )


def _analyze_mixed(
    iteration_dir: str,
    group: dict,
    skill_summary: str,
) -> dict:
    """半对错样本分析（0 < avg_reward < 1），2 步 LLM 调用。

    Phase 2: 优劣对比 → Phase 3: 决定操作
    """
    p2_prompt = render(
        "tfgrpo_group_advantage.j2",
        question=group["question"],
        ground_truth=group["ground_truth"],
        rollouts=group["rollouts"],
    )
    advantage = run_agent(
        cwd=iteration_dir,
        output_schema_path=_ADVANTAGE_SCHEMA,
        prompt=p2_prompt,
        parser=lambda x: x,
    )

    p3_prompt = render(
        "tfgrpo_group_update.j2",
        skill_summary=skill_summary,
        advantage_analysis=advantage["advantage_analysis"],
        disadvantage_analysis=advantage["disadvantage_analysis"],
        root_cause=advantage["root_cause"],
    )
    return run_agent(
        cwd=iteration_dir,
        output_schema_path=_UNIFIED_SCHEMA,
        prompt=p3_prompt,
        parser=lambda x: x,
    )


def extract_experiences_from_rollouts(
    iteration_dir: str,
    rollout_groups: list[dict],
    skill_summary: str = "",
    max_parallel_size: int = 4,
) -> list[dict]:
    """对每个样本的 rollout 组进行三分法经验提取。

    按 avg_reward 分流到不同 prompt，输出统一格式 {analysis, operations}。
    当前实现为串行处理每个样本（LLM 调用本身已并行）。

    Args:
        iteration_dir: 当前簇的 skill 工作目录
        rollout_groups: 每个元素 {sample_id, question, rollouts, ground_truth}
        skill_summary: 当前 SKILL.md 内容摘要（用于半对错 Phase 3）
        max_parallel_size: 并发数（预留，当前未使用）

    Returns:
        list[dict]: 每个样本的 {sample_id, avg_reward, analysis, operations}
    """
    results = []
    all_wrong_count = 0
    mixed_count = 0
    all_correct_count = 0

    for group in rollout_groups:
        correct_count = sum(1 for r in group["rollouts"] if r["is_correct"])
        avg_reward = correct_count / len(group["rollouts"])

        try:
            if avg_reward == 0:
                all_wrong_count += 1
                result = _analyze_all_wrong(iteration_dir, group)
            elif avg_reward == 1:
                all_correct_count += 1
                result = _analyze_all_correct(iteration_dir, group)
            else:
                mixed_count += 1
                result = _analyze_mixed(iteration_dir, group, skill_summary)
        except Exception as e:
            logger.warning(f"样本 {group['sample_id']} 经验提取失败: {e}")
            result = {"analysis": "经验提取失败", "operations": []}

        results.append({
            "sample_id": group["sample_id"],
            "avg_reward": avg_reward,
            "analysis": result.get("analysis", ""),
            "operations": result.get("operations", []),
        })

    logger.info(
        f"经验提取完成: {len(results)} 样本 "
        f"(全错={all_wrong_count}, 半对错={mixed_count}, 全对={all_correct_count})"
    )
    return results


def aggregate_cluster_experiences(
    per_sample_experiences: list[dict],
    current_skill_content: str,
    iteration_dir: str,
) -> dict:
    """簇级经验聚合。

    将所有样本的统一格式经验汇总，通过 LLM 去重排序，
    输出 pattern_collections（兼容 update_skill_prompt.j2）。
    """
    prompt = render(
        "tfgrpo_aggregate_experiences.j2",
        current_skill_content=current_skill_content,
        num_samples=len(per_sample_experiences),
        experiences=per_sample_experiences,
    )
    result = run_agent(
        cwd=iteration_dir,
        output_schema_path=_AGGREGATE_SCHEMA,
        prompt=prompt,
        parser=lambda x: x,
    )
    logger.info("簇级经验聚合完成")
    return result


def build_rollout_groups(
    data_list: list[dict],
    rollout_results: list[list[dict]],
) -> list[dict]:
    """从样本数据和多 rollout 结果构建 rollout 组。

    将 validation_skill_multi_rollout 的输出转换为
    extract_experiences_from_rollouts 所需的输入格式。
    """
    groups = []
    for idx, (sample, rollouts) in enumerate(zip(data_list, rollout_results)):
        ground_truth = sample["Default"]
        groups.append({
            "sample_id": idx,
            "question": sample.get("validation_prompt", sample.get("prompt", "")),
            "rollouts": [
                {
                    "risk_reason": r["risk_reason"],
                    "risk_result": r["risk_result"],
                    "is_correct": (r["risk_result"] == "是") == (ground_truth == 1),
                }
                for r in rollouts
            ],
            "ground_truth": ground_truth,
        })
    return groups
