# SBA信贷风控数据集适配Trace2Skill - 实施完成

## 概述

已完成SBA信贷风控数据集适配Trace2Skill框架的完整实现。所有代码已按照要求**尽量在新增文件中实现**，仅修改了1个现有文件以支持信贷风控任务类型。

## 文件清单

### 新增文件（9个）

#### 1. 核心适配模块 (credit_risk_adapter/)
- `credit_risk_adapter/__init__.py` - 模块导出
- `credit_risk_adapter/trace2skill_adapter.py` - 数据格式转换（复用SBADataLoader）
- `credit_risk_adapter/credit_risk_agent.py` - Agent实现（等价于cli_skill_preloaded）
- `credit_risk_adapter/credit_risk_runner.py` - Runner实现（等价于SpreadsheetBenchRunner）

#### 2. 主运行脚本
- `run_sba_trace2skill.py` - 单次运行入口
- `run_sba_multi_round_evolution.sh` - 多轮迭代演化脚本
- `test_sba_adaptation.sh` - 快速验证测试脚本

#### 3. Analysis适配
- `analysis/credit_risk_error_analysis_system.txt` - 信贷风控版error analysis系统提示

#### 4. 文档
- `SBA_ADAPTATION_GUIDE.md` - 详细使用指南
- `SBA_IMPLEMENTATION_SUMMARY.md` - 实施总结文档

### 修改的现有文件（1个）

#### `analysis/run_error_analysis.py`

**修改内容**：
1. 添加 `--task_type` 参数（默认"spreadsheet"，新增"credit_risk"选项）
2. 添加 `find_ground_truth_for_credit_risk()` 函数（从results.json读取ground truth）
3. 修改 `build_instance_index()` 支持多种任务类型
4. 修改 `setup_analysis_dir()` 使gold.xlsx拷贝可选（信贷任务不需要）
5. 修改 `run_single_instance()` 根据task_type选择不同逻辑
6. 调整参数验证（--work_dir改为optional）

**向后兼容性**：
- ✅ 默认task_type="spreadsheet"，保持原有行为
- ✅ 所有修改通过task_type条件判断，不影响SpreadsheetBench功能
- ✅ 现有脚本无需任何修改

## 架构设计

### 核心理念
将CSV每一行视为一个"instance"，保持Trace2Skill核心流程：
```
数据加载 → Agent推理 → 轨迹生成 → 分析 → Skill演化 → 验证
```

### 关键适配点

| 维度 | SpreadsheetBench | SBA Credit Risk |
|------|------------------|-----------------|
| 数据格式 | 目录+xlsx | CSV行记录 |
| Agent工具 | bash命令 | 无工具（纯推理） |
| 输出格式 | xlsx文件 | JSON: {predicted_default: 0/1} |
| Ground Truth | gold.xlsx | results.json中的ground_truth |
| 成功定义 | 文件正确 | prediction == ground_truth |

## 使用前准备

### 1. 拷贝SBA依赖文件（需手动执行）

```bash
cd D:/huawei/Trace2Skill
mkdir -p credit_risk_adapter

# 从gh_auto_research项目拷贝
cp D:/huawei/gh_auto_research/benchmark_test/data_loader_sba.py credit_risk_adapter/
cp D:/huawei/gh_auto_research/benchmark_test/prompts/default_prompt.txt credit_risk_adapter/sba_prompt_template.txt
cp D:/huawei/gh_auto_research/benchmark_test/logger.py credit_risk_adapter/
```

### 2. 修改import路径

编辑 `credit_risk_adapter/data_loader_sba.py`：
```python
# 将：
from benchmark_test.logger import get_logger
# 改为：
from credit_risk_adapter.logger import get_logger
```

### 3. 准备初始Skill

```bash
mkdir -p credit_risk_adapter/skills/sba_initial
# 将你现有的SBA skill复制为 SKILL.md
cp <你的初始skill> credit_risk_adapter/skills/sba_initial/SKILL.md
```

### 4. 设置环境变量

```bash
export OPENAI_API_KEY=<your_api_key>
```

## 快速测试

### 步骤1: 运行验证测试（3个样本）

```bash
chmod +x test_sba_adaptation.sh
./test_sba_adaptation.sh
```

预期输出：
```
✓ Found all required files
✓ OPENAI_API_KEY is set
✓ Loaded 5 instances
✓ Agent initialized
✓ results.json created
✓ Created 3 log files
✓ ALL TESTS PASSED
```

### 步骤2: 小规模测试（50个样本）

```bash
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model gpt-4o \
  --output_dir outputs/sba_test_50 \
  --start_idx 0 --end_idx 50
```

### 步骤3: 完整多轮演化（200个样本）

```bash
chmod +x run_sba_multi_round_evolution.sh
./run_sba_multi_round_evolution.sh
```

流程：
- Round 0: 初始skill生成轨迹（0-200条）
- Round 1-3: 分析→演化→验证循环
- 早停机制：accuracy不提升时自动停止

## 主要命令说明

### 1. 单次推理运行

```bash
python run_sba_trace2skill.py \
  --data_path <SBA_CSV路径> \
  --skill_path <SKILL.md路径> \
  --model gpt-4o \
  --output_dir <输出目录> \
  --start_idx 0 --end_idx 200
```

### 2. Error Analysis（信贷风控）

```bash
python analysis/run_error_analysis.py \
  --data_path <results.json路径> \
  --logs_dir <日志目录> \
  --output_dir <输出目录> \
  --model gpt-4o \
  --task_type credit_risk \  # 关键参数
  --workers 32
```

### 3. Skill演化

```bash
python -m skill_evolver.run_parallel_combined_skill_evolution \
  --error-json <error_analysis_parsed.json> \
  --success-json <success_analysis_parsed.json> \
  --skill-dir <skill目录> \
  --model gpt-4o \
  --max-workers 32 \
  --batch-size 5 \
  --continue-evolving
```

## 输出结构

```
outputs/sba_round_X/
├── outputs/
│   └── results.json              # 准确率和详细结果
├── logs/
│   └── credit_risk_skill_agent_*.md  # 每个实例的推理日志
├── error_analysis/
│   └── error_analysis_parsed.json
├── success_analysis/
│   └── success_analysis_parsed.json
├── skill/
│   └── SKILL.md                  # 演化后的skill
└── evolution_changelog.md        # 演化记录
```

## 常见问题

### Q1: ModuleNotFoundError: credit_risk_adapter.data_loader_sba
**A**: 未拷贝SBA依赖文件，执行"使用前准备"的步骤1

### Q2: ImportError: cannot import 'get_logger'
**A**: import路径未修改，执行"使用前准备"的步骤2

### Q3: Error analysis报错找不到gold.xlsx
**A**: 未指定task_type，添加 `--task_type credit_risk` 参数

### Q4: Skill演化无变化
**A**: 检查错误样本数量：
```bash
jq '.[] | select(.pass_gate == true)' error_analysis_parsed.json | wc -l
```

## 详细文档

- **SBA_ADAPTATION_GUIDE.md** - 完整使用指南（包含所有命令和参数说明）
- **SBA_IMPLEMENTATION_SUMMARY.md** - 技术实施总结（架构设计和代码说明）

## 实施验证检查清单

- [ ] 拷贝了所有SBA依赖文件（data_loader_sba.py, logger.py, sba_prompt_template.txt）
- [ ] 修改了data_loader_sba.py的import路径
- [ ] 准备了初始SKILL.md文件
- [ ] 设置了OPENAI_API_KEY环境变量
- [ ] 运行test_sba_adaptation.sh全部通过
- [ ] 50样本测试生成正确的results.json和logs
- [ ] Error analysis能正确解析credit_risk日志
- [ ] Skill evolution能修改SKILL.md
- [ ] 多轮迭代能正常运行并记录准确率变化

## 技术亮点

1. **最小侵入性**: 仅修改1个现有文件，且完全向后兼容
2. **完全复用**: 100%复用SBADataLoader的预处理逻辑
3. **架构一致性**: 与SpreadsheetBench保持相同的设计模式
4. **模块化**: 所有适配代码独立在credit_risk_adapter/
5. **可测试性**: 提供快速验证脚本和多级测试方案
6. **文档完整**: 使用指南+技术总结+测试脚本

## 联系与支持

如遇到问题：
1. 首先查看 `SBA_ADAPTATION_GUIDE.md` 的"常见问题"章节
2. 运行 `test_sba_adaptation.sh` 诊断环境配置
3. 检查 `SBA_IMPLEMENTATION_SUMMARY.md` 了解技术细节
