# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Trace2Skill is a research system that automatically evolves agent skills from execution traces. The core pipeline: trajectory generation → parallel multi-agent patch proposal → hierarchical conflict-free consolidation. The codebase focuses on SpreadsheetBench tasks but the skill evolution methodology applies to other domains (math reasoning, VQA mentioned in paper).

## Architecture

### Core Components

**src/react_agent/** - ReAct agent framework
- `agent.py`: Main ReActAgent orchestrating THINK→ACT→OBSERVE loop
- `models.py`: LLM client abstractions (OpenAIClient, ApiChatClient)
- `prompts.py`: System prompt builders with sectioned templates
- `converter.py`: Parse LLM responses into structured actions
- `tools.py`: Tool registry and definitions

**spreadsheet_agent/** - SpreadsheetBench agent implementations
- `agents/cli_only_agent.py`: Baseline agent with only bash tool (no skills)
- `agents/cli_skill_preloaded_agent.py`: Agent with skills embedded in system prompt at initialization
- `system_prompts.py`: Templates for agent system prompts
- `skills/`: Runtime skill directory tree (xlsx/, xlsx-35B/, xlsx-122B/)
  - Each skill: `SKILL.md` with YAML frontmatter + optional `references/*.md`
- `runner.py`: SpreadsheetBenchRunner orchestrating task execution

**analysis/** - Trajectory analysis for skill evolution
- `run_error_analysis.py`: Agentic multi-turn error analyst (uses ReAct agent to debug failures)
- `run_success_analysis_llm.py`: Single-call success analyst (extracts lessons from successes)
- `parse_error_analysis_outputs.py`: Parse analyst outputs to structured JSON
- `parse_success_analysis_outputs.py`: Parse success outputs to structured JSON

**skill_evolver/** - Parallel map-reduce skill evolution
- `parallel_evolving_agent.py`: Core map-reduce pipeline:
  1. MAP: Each error batch proposes a concise patch against frozen skill snapshot
  2. REDUCE: Hierarchical patch merging until one final patch
  3. APPLY: Convert merged patch to full files and validate
- `run_parallel_skill_evolution.py`: CLI for error-driven evolution
- `run_parallel_combined_skill_evolution.py`: CLI for combined error+success evolution
- Patch formats: JSON-based structured edits or markdown-based semantic instructions

**released_skills/** - Paper artifacts (separate from runtime skills)
- `trace2skill-xlsx-35B-combined/`, `trace2skill-xlsx-122B-combined/`: Self-deepen mode results
- `xlsx-35B/`, `xlsx-122B/`: Self-create mode results

### Key Patterns

**Skill Structure**: Skills use YAML frontmatter in `SKILL.md`:
```markdown
---
name: Excel Operations
description: Patterns for spreadsheet manipulation
---
(skill content)
```

**Generation Configs**: Model-specific configs in `gen_config/` control temperature, thinking modes, etc. Pass via `--generation_config` to any script that accepts it. Configs are JSON files or inline JSON strings.

**Agent Selection**: `--agent` flag chooses between `cli_only` (baseline, no skills) and `cli_skill_preloaded` (skills in context).

**Skill Directories**: Three parallel skill trees in `spreadsheet_agent/skills/`:
- `xlsx/`: Default skill
- `xlsx-35B/`, `xlsx-122B/`: Model-specific evolved skills from paper

## Common Commands

### Development Workflow

**Install dependencies** (lightweight, no complex build):
```bash
python -m pip install openai tqdm openpyxl requests diskcache
```

**Run SpreadsheetBench agent** (basic):
```bash
python run_spreadsheetbench.py \
  --data_path data/spreadsheetbench_verified/spreadsheetbench_verified_400 \
  --model <model_name> \
  --output_dir outputs/run \
  --log_dir outputs/logs \
  --working_dir outputs/work \
  --max_turns 100 \
  --workers 128
```

**Run with specific agent and skills**:
```bash
python run_spreadsheetbench.py \
  --data_path <dataset> \
  --model <model> \
  --agent cli_skill_preloaded \
  --skills_dir spreadsheet_agent/skills \
  --generation_config gen_config/qwen3.5_35B_122B_instruct_reasoning.json \
  --start_idx 0 --end_idx 200
```

**Evaluate outputs**:
```bash
python evaluate_with_official.py \
  --data_path <dataset> \
  --output_dir <outputs> \
  --verbose \
  --start_idx 0 --end_idx 200
```

**Match logs to results** (creates failure triage):
```bash
python analyze_results.py \
  --eval_results <outputs>/eval_official_results.json \
  --log_dir <outputs>/logs
```

### Analysis Pipeline

**Error analysis** (multi-turn agentic debugging):
```bash
python analysis/run_error_analysis.py \
  --data_path <dataset> \
  --work_dir <baseline_dir>/work \
  --logs_dir <baseline_dir>/logs \
  --output_dir <baseline_dir>/error_analysis \
  --model <model> \
  --workers 128 \
  --generation_config gen_config/qwen3.5_35B_122B_instruct_reasoning.json \
  --max_turns 100
```

**Success analysis** (single-call lesson extraction):
```bash
python analysis/run_success_analysis_llm.py \
  --logs_dir <baseline_dir>/logs \
  --output_dir <baseline_dir>/success_analysis \
  --model <model> \
  --max_workers 128 \
  --generation_config gen_config/qwen3.5_35B_122B_thinking_reasoning.json
```

**Parse analysis outputs to structured JSON**:
```bash
python analysis/parse_error_analysis_outputs.py \
  --input_dir <baseline_dir>/error_analysis \
  --output <baseline_dir>/error_analysis_parsed.json

python analysis/parse_success_analysis_outputs.py \
  --input_dir <baseline_dir>/success_analysis \
  --output <baseline_dir>/success_analysis_parsed.json
```

### Skill Evolution

**Parallel error-driven evolution**:
```bash
# Copy skills to evolution directory first
mkdir -p outputs/evolved_skills
cp -r spreadsheet_agent/skills/. outputs/evolved_skills

python -m skill_evolver.run_parallel_skill_evolution \
  --input-json <baseline_dir>/error_analysis_parsed.json \
  --skill-dir outputs/evolved_skills/xlsx \
  --model <model> \
  --max-workers 128 \
  --batch-size 1 \
  --save-intermediates \
  --intermediates-dir outputs/evolution/intermediates \
  --changelog outputs/evolution/change.log \
  --generation-config gen_config/qwen3.5_35B_122B_thinking_reasoning.json \
  --patch-pipeline json \
  --seed 41
```

**Combined error+success evolution**:
```bash
python -m skill_evolver.run_parallel_combined_skill_evolution \
  --error-json <error_analysis_parsed.json> \
  --success-json <success_analysis_parsed.json> \
  --skill-dir outputs/evolved_skills/xlsx \
  --model <model> \
  --max-workers 128
```

## Environment Setup

**API Configuration**:
```bash
export OPENAI_API_KEY=<your_key>
export OPENAI_BASE_URL=<optional_openai_compatible_endpoint>
```

For local serving: pass `--api-key EMPTY --base-url http://localhost:8000/v1`

## Important Conventions

**Data Splits**: The reproduction workflow uses training split (0:200) for skill evolution, held-out split (200:400) for final evaluation. Use `--start_idx` and `--end_idx` to control splits.

**Seed Control**: Pass `--seed` or `--seeds` to control randomness. Generation configs can also include seed. For reproducibility, use consistent seeds across runs, but note that 100% reproduction is difficult with long ReAct trajectories.

**Working Directory Isolation**: Agents run in sandboxed working directories. SpreadsheetBench tasks provide absolute paths; agents can only read/write within their working_directory.

**Skill Evolution Safety**: Always validate evolved skills on training split before held-out evaluation. LLM-edited skills can be damaged by hallucinated edits. Paper workflow: evolve with 3 seeds → validate on training split → pick best seed → evaluate on held-out split.

**Parallel Workers**: `--workers` or `--max-workers` controls concurrency. High parallelism (128) is common for reproducing paper results with cloud APIs.

**Log Formats**: `--log_format markdown` produces human-readable logs. Analysis scripts parse these markdown logs to extract trajectories.

**Patch Pipelines**: `--patch-pipeline json` (structured edits) or `markdown` (semantic instructions). JSON is more reliable for programmatic application.

## Testing and Validation

No formal test suite. Validation happens via:
1. Run agent on dataset split
2. Evaluate outputs with `evaluate_with_official.py`
3. Compare `eval_official_results.json` summary metrics

For evolved skills, compare training-split performance before/after evolution to detect regressions.
