# SBA信贷风控数据集适配Trace2Skill - 实施指南

本文档说明如何使用已实现的适配代码，将Trace2Skill应用于SBA信贷风控数据集。

## 架构概览

### 适配层组件

所有适配代码位于 `credit_risk_adapter/` 目录：

```
credit_risk_adapter/
├── __init__.py                    # 模块导出
├── trace2skill_adapter.py         # 数据加载和格式转换（复用SBADataLoader）
├── credit_risk_agent.py           # Agent实现（等价于cli_skill_preloaded_agent）
└── credit_risk_runner.py          # Runner实现（等价于SpreadsheetBenchRunner）
```

### 主要脚本

- `run_sba_trace2skill.py` - 单次运行脚本
- `run_sba_multi_round_evolution.sh` - 多轮迭代演化脚本

### Analysis适配

- `analysis/credit_risk_error_analysis_system.txt` - 信贷风控版本的error analysis系统提示
- `analysis/run_error_analysis.py` - 已修改，支持 `--task_type credit_risk` 参数

## 前置准备

### 1. 环境依赖

```bash
# 已有的Trace2Skill依赖
pip install openai tqdm openpyxl requests diskcache

# SBA数据集依赖
pip install pandas numpy scikit-learn
```

### 2. 拷贝SBA依赖文件

需要从 `gh_auto_research` 项目拷贝以下文件：

```bash
cd D:/huawei/Trace2Skill

# 创建适配器目录（如果不存在）
mkdir -p credit_risk_adapter

# 拷贝SBA数据加载器
cp D:/huawei/gh_auto_research/benchmark_test/data_loader_sba.py \
   credit_risk_adapter/

# 拷贝prompt模板
cp D:/huawei/gh_auto_research/benchmark_test/prompts/default_prompt.txt \
   credit_risk_adapter/sba_prompt_template.txt

# 拷贝logger
cp D:/huawei/gh_auto_research/benchmark_test/logger.py \
   credit_risk_adapter/
```

### 3. 修改import路径

编辑 `credit_risk_adapter/data_loader_sba.py`：

```bash
# 使用sed修改import路径
sed -i 's/from benchmark_test.logger/from credit_risk_adapter.logger/g' \
    credit_risk_adapter/data_loader_sba.py
```

或手动修改：
```python
# 将：
from benchmark_test.logger import get_logger

# 改为：
from credit_risk_adapter.logger import get_logger
```

### 4. 准备初始Skill

将你现有的SBA初始skill放到指定位置：

```bash
mkdir -p credit_risk_adapter/skills/sba_initial
cp <你的初始skill路径> credit_risk_adapter/skills/sba_initial/SKILL.md
```

SKILL.md格式示例：
```markdown
---
name: SBA Credit Risk Assessment
description: Initial skill for SBA credit risk prediction
---

# Credit Risk Assessment Patterns

## Key Risk Indicators
1. Credit score analysis
2. Debt-to-income ratio evaluation
3. Employment stability assessment
...
```

### 5. 设置环境变量

```bash
export OPENAI_API_KEY=<your_api_key>
export OPENAI_BASE_URL=<optional_base_url>  # 可选
```

## 使用流程

### 测试阶段：单轮运行（50条数据）

```bash
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model gpt-4o \
  --output_dir outputs/sba_test \
  --log_dir outputs/sba_test/logs \
  --start_idx 0 \
  --end_idx 50 \
  --max_turns 10

# 检查输出
ls outputs/sba_test/logs/  # 应该有50个.md日志文件
cat outputs/sba_test/results.json  # 查看准确率
```

### 完整流程：多轮迭代演化

#### 方案1：使用自动化脚本（推荐）

```bash
# 编辑脚本配置（如需要）
vim run_sba_multi_round_evolution.sh
# 修改 DATA_PATH, MODEL, INITIAL_SKILL 等变量

# 赋予执行权限
chmod +x run_sba_multi_round_evolution.sh

# 运行多轮迭代
./run_sba_multi_round_evolution.sh
```

脚本会自动执行：
1. Round 0: 用初始skill生成轨迹（0-200条）
2. Round 1-3: 分析→演化→验证循环
3. 早停：如果准确率不提升则停止

#### 方案2：手动逐步执行

**Round 0: 生成初始轨迹**

```bash
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model gpt-4o \
  --output_dir outputs/sba_round_0 \
  --log_dir outputs/sba_round_0/logs \
  --start_idx 0 \
  --end_idx 200
```

**Round 1: 分析 + 演化**

```bash
# 1. Error Analysis
python analysis/run_error_analysis.py \
  --data_path outputs/sba_round_0/results.json \
  --logs_dir outputs/sba_round_0/logs \
  --output_dir outputs/sba_round_1/error_analysis \
  --model gpt-4o \
  --task_type credit_risk \
  --workers 32

# 2. Success Analysis
python analysis/run_success_analysis_llm.py \
  --logs_dir outputs/sba_round_0/logs \
  --output_dir outputs/sba_round_1/success_analysis \
  --model gpt-4o \
  --max_workers 32

# 3. Parse Outputs
python analysis/parse_error_analysis_outputs.py \
  --input_dir outputs/sba_round_1/error_analysis \
  --output outputs/sba_round_1/error_analysis_parsed.json

python analysis/parse_success_analysis_outputs.py \
  --input_dir outputs/sba_round_1/success_analysis \
  --output outputs/sba_round_1/success_analysis_parsed.json

# 4. Evolve Skill
mkdir -p outputs/sba_round_1/skill
cp credit_risk_adapter/skills/sba_initial/SKILL.md outputs/sba_round_1/skill/

python -m skill_evolver.run_parallel_combined_skill_evolution \
  --error-json outputs/sba_round_1/error_analysis_parsed.json \
  --success-json outputs/sba_round_1/success_analysis_parsed.json \
  --skill-dir outputs/sba_round_1/skill \
  --model gpt-4o \
  --max-workers 32 \
  --batch-size 5 \
  --continue-evolving

# 5. Validate Evolved Skill
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path outputs/sba_round_1/skill/SKILL.md \
  --model gpt-4o \
  --output_dir outputs/sba_round_1/outputs \
  --log_dir outputs/sba_round_1/logs \
  --start_idx 0 \
  --end_idx 200
```

**对比准确率并决定是否继续**

```bash
# Round 0 准确率
python -c "import json; print(json.load(open('outputs/sba_round_0/results.json'))['accuracy'])"

# Round 1 准确率
python -c "import json; print(json.load(open('outputs/sba_round_1/outputs/results.json'))['accuracy'])"
```

如果有提升，继续Round 2（重复上述流程，将round_1改为round_2）。

### 最终评估：Held-out集

在训练集（0-200）上选出最佳skill后，在held-out集（200-400）上评估：

```bash
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path outputs/sba_round_X/skill/SKILL.md \  # X是最佳轮次
  --model gpt-4o \
  --output_dir outputs/sba_final_eval \
  --log_dir outputs/sba_final_eval/logs \
  --start_idx 200 \
  --end_idx 400

# 查看最终准确率
cat outputs/sba_final_eval/results.json
```

## 关键参数说明

### run_sba_trace2skill.py

- `--data_path`: SBA CSV文件路径
- `--skill_path`: SKILL.md文件路径（初始或演化后的skill）
- `--model`: 模型名称（如gpt-4o, gpt-4-turbo等）
- `--start_idx`, `--end_idx`: 数据集切片（0-200训练，200-400测试）
- `--max_turns`: 每个实例的最大推理轮数（默认10）

### analysis/run_error_analysis.py

- `--task_type credit_risk`: **必须指定**，启用信贷风控适配
- `--data_path`: 对于credit_risk任务，传入results.json而非数据集路径
- `--logs_dir`: 日志目录
- `--workers`: 并行worker数量

### skill_evolver.run_parallel_combined_skill_evolution

- `--error-json`, `--success-json`: 解析后的分析结果
- `--skill-dir`: skill目录（演化会修改其中的SKILL.md）
- `--batch-size`: 每批错误样本数量（信贷记录较短，可增大到5-10）
- `--continue-evolving`: 避免重复备份，多轮迭代时必须加上

## 输出结构

```
outputs/sba_round_X/
├── outputs/
│   └── results.json          # 准确率和详细结果
├── logs/
│   ├── credit_risk_skill_agent_0.md
│   ├── credit_risk_skill_agent_1.md
│   └── ...                   # 每个实例一个日志文件
├── error_analysis/
│   ├── 0/
│   │   ├── agent_log.md
│   │   └── analysis_report.md
│   └── error_analysis_parsed.json
├── success_analysis/
│   └── success_analysis_parsed.json
├── skill/
│   └── SKILL.md              # 演化后的skill
└── evolution_changelog.md    # 演化记录
```

## 常见问题

### 1. ModuleNotFoundError: No module named 'credit_risk_adapter.data_loader_sba'

**原因**: 未拷贝SBA依赖文件

**解决**: 参照"前置准备"第2步拷贝文件

### 2. ImportError: cannot import name 'get_logger' from 'credit_risk_adapter.logger'

**原因**: data_loader_sba.py中的import路径未修改

**解决**: 参照"前置准备"第3步修改import

### 3. Error analysis报错找不到gold.xlsx

**原因**: 使用了spreadsheet的默认task_type

**解决**: 确保传入 `--task_type credit_risk` 参数

### 4. Skill演化无效果

**可能原因**:
- 初始skill已经很强，错误样本太少
- batch_size设置不当
- 分析结果质量不高

**排查步骤**:
```bash
# 1. 检查错误样本数量
jq '.[] | select(.pass_gate == true)' outputs/sba_round_1/error_analysis_parsed.json | wc -l

# 2. 查看演化changelog
cat outputs/sba_round_1/evolution_changelog.md

# 3. 对比演化前后的skill
diff credit_risk_adapter/skills/sba_initial/SKILL.md outputs/sba_round_1/skill/SKILL.md
```

## 修改的现有文件总结

**仅修改了1个文件**: `analysis/run_error_analysis.py`

**修改内容**:
1. 添加 `--task_type` 参数（默认为spreadsheet，保持向后兼容）
2. 添加 `find_ground_truth_for_credit_risk()` 函数
3. 修改 `build_instance_index()` 支持credit_risk任务类型
4. 修改 `setup_analysis_dir()` 跳过gold.xlsx拷贝（credit_risk不需要）
5. 修改 `run_single_instance()` 根据task_type选择不同逻辑
6. `--work_dir` 从required改为optional（credit_risk不需要）

**所有修改都通过task_type判断，不影响原有spreadsheet功能。**

## 下一步

完成上述流程后，你可以：

1. 分析演化后的skill，提取可迁移的模式
2. 在不同的数据集切片上验证skill的泛化性
3. 尝试不同的模型（如claude-3-opus, qwen等）
4. 调整batch_size和演化轮数优化结果
