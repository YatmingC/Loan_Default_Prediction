#!/usr/bin/env python3
"""SBA 信贷风控数据集的 Trace2Skill 运行脚本

完全复用：
1. SBADataLoader 的数据预处理
2. SBA prompt 模板
3. Trace2Skill 的 skill evolution pipeline
"""

import argparse
import os
import sys
from pathlib import Path

# Add project root to path
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.react_agent import OpenAIClient
from credit_risk_adapter.credit_risk_agent import CreditRiskSkillAgent
from credit_risk_adapter.credit_risk_runner import CreditRiskRunner


def main():
    parser = argparse.ArgumentParser(
        description="Run SBA credit risk agent with Trace2Skill framework"
    )
    parser.add_argument(
        "--data_path",
        type=str,
        required=True,
        help="Path to SBA CSV file",
    )
    parser.add_argument(
        "--skill_path",
        type=str,
        required=True,
        help="Path to SKILL.md (initial or evolved skill)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o",
        help="Model name",
    )
    parser.add_argument(
        "--api_key",
        type=str,
        default=None,
        help="OpenAI API key (defaults to OPENAI_API_KEY env var)",
    )
    parser.add_argument(
        "--base_url",
        type=str,
        default=None,
        help="OpenAI API base URL (defaults to OPENAI_BASE_URL env var)",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="outputs/sba",
        help="Output directory",
    )
    parser.add_argument(
        "--log_dir",
        type=str,
        default=None,
        help="Log directory (defaults to output_dir/logs)",
    )
    parser.add_argument(
        "--start_idx",
        type=int,
        default=0,
        help="Start index",
    )
    parser.add_argument(
        "--end_idx",
        type=int,
        default=None,
        help="End index",
    )
    parser.add_argument(
        "--max_turns",
        type=int,
        default=10,
        help="Max turns per instance",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of parallel workers. >1 runs instances concurrently, each "
             "worker with its own agent/client/logger (default: 1 = serial)",
    )

    args = parser.parse_args()

    # 检查环境变量
    api_key = args.api_key or os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("ERROR: OPENAI_API_KEY not set and --api_key not provided")
        sys.exit(1)

    base_url = args.base_url or os.getenv("OPENAI_BASE_URL")

    # 设置日志目录
    log_dir = args.log_dir or os.path.join(args.output_dir, "logs")

    # 并发模式下关闭 verbose，避免多线程输出串台
    verbose = args.workers <= 1

    # Agent 工厂：每个 worker 调用它创建自己独立的 agent + client + logger。
    # 关键：ReActAgent 持有对话状态、ChatHistoryLogger 持有当前日志文件句柄，
    # 多线程共享会串台，因此每个 worker 必须有独立实例。
    def agent_factory() -> CreditRiskSkillAgent:
        client = OpenAIClient(
            model=args.model,
            api_key=api_key,
            base_url=base_url,
        )
        return CreditRiskSkillAgent(
            client=client,
            skill_path=args.skill_path,
            max_turns=args.max_turns,
            verbose=verbose,
            log_dir=log_dir,
            log_format="markdown",
        )

    print(f"Using model: {args.model}")
    print(f"Skill path: {args.skill_path}")
    print(f"Output directory: {args.output_dir}")
    print(f"Log directory: {log_dir}")
    print(f"Workers: {args.workers}")

    # 创建 runner（使用工厂模式，支持并发）
    runner = CreditRiskRunner(
        agent_factory=agent_factory,
        data_path=args.data_path,
        output_dir=args.output_dir,
    )

    # 运行
    runner.run_and_save(
        start_idx=args.start_idx,
        end_idx=args.end_idx,
        workers=args.workers,
    )


if __name__ == "__main__":
    main()
