# SBA 信贷风控数据集适配 Trace2Skill - 完整实施方案

本文档提供**严格遵循原论文实现**、**完全复用 SBA 原实现**的适配方案。

---

## Part 1: 复用 SBA 原实现的依赖文件

### Step 1.1: 拷贝 SBA 数据加载器到 Trace2Skill 项目

```bash
# 在 Trace2Skill 项目根目录下执行
mkdir -p credit_risk_adapter

# 拷贝 SBA 数据加载器
cp D:/huawei/gh_auto_research/benchmark_test/data_loader_sba.py \
   credit_risk_adapter/data_loader_sba.py

# 拷贝 prompt 模板
cp D:/huawei/gh_auto_research/benchmark_test/prompts/default_prompt.txt \
   credit_risk_adapter/sba_prompt_template.txt

# 拷贝 logger（如果需要）
cp D:/huawei/gh_auto_research/benchmark_test/logger.py \
   credit_risk_adapter/logger.py
```

### Step 1.2: 修改 data_loader_sba.py 的 import 路径

编辑 `credit_risk_adapter/data_loader_sba.py`，修改 import：

```python
# 原代码：
# from benchmark_test.logger import get_logger

# 修改为：
from credit_risk_adapter.logger import get_logger
```

---

## Part 2: 创建 Trace2Skill 适配层

### Step 2.1: 数据格式转换层

**创建 `credit_risk_adapter/trace2skill_adapter.py`**：

```python
"""将 SBA 数据适配为 Trace2Skill 的轨迹生成/分析格式

核心职责：
1. 复用 SBADataLoader 的完整预处理逻辑
2. 复用原 SBA prompt 模板
3. 转换为 Trace2Skill 的 instance 格式（用于轨迹生成）
4. 转换为 Trace2Skill 的 log 格式（用于 error/success 分析）
"""

import json
import pandas as pd
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Tuple

from credit_risk_adapter.data_loader_sba import SBADataLoader


@dataclass
class CreditRiskInstance:
    """单条信贷记录（Trace2Skill instance 格式）"""
    id: str
    instruction: str  # 包含特征的完整 prompt（复用 SBA 原 prompt 模板）
    ground_truth: int  # 真实标签
    features: Dict  # 原始特征字典（用于日志记录）
    metadata: Dict = field(default_factory=dict)


class SBATrace2SkillAdapter:
    """SBA 数据集到 Trace2Skill 格式的适配器
    
    严格复用 SBADataLoader 的所有预处理逻辑和特征命名。
    """
    
    def __init__(
        self,
        data_path: str,
        prompt_template_path: str = "credit_risk_adapter/sba_prompt_template.txt",
    ):
        """
        Args:
            data_path: SBA CSV 文件路径
            prompt_template_path: SBA prompt 模板路径（复用原实现）
        """
        # 使用原 SBADataLoader
        self.data_loader = SBADataLoader(data_path=data_path)
        
        # 加载原 SBA prompt 模板
        self.prompt_template = Path(prompt_template_path).read_text(encoding="utf-8")
    
    def load_instances(
        self,
        start_idx: int = 0,
        end_idx: int = None,
    ) -> List[CreditRiskInstance]:
        """加载数据为 Trace2Skill instance 格式
        
        完全复用 SBADataLoader 的预处理逻辑。
        """
        # 调用原 SBADataLoader 的预处理
        X, y = self.data_loader.prepare_for_inference(sample_size=None)
        
        # 切片
        if end_idx is None:
            end_idx = len(X)
        X = X.iloc[start_idx:end_idx]
        y = y.iloc[start_idx:end_idx]
        
        instances = []
        for idx, (row_idx, features_row) in enumerate(X.iterrows()):
            # 构建 loan_info 字符串（与原 SBA 实现一致）
            loan_info = self._format_loan_info(features_row)
            
            # 使用原 SBA prompt 模板
            instruction = self.prompt_template.format(loan_info=loan_info)
            
            instances.append(CreditRiskInstance(
                id=str(row_idx),
                instruction=instruction,
                ground_truth=int(y.iloc[idx]),
                features=features_row.to_dict(),
            ))
        
        return instances
    
    def _format_loan_info(self, features: pd.Series) -> str:
        """格式化 loan_info 字符串（与原 SBA baseline 推理一致）
        
        使用与 gh_auto_research 项目完全相同的特征展示格式。
        """
        lines = []
        for key, value in features.items():
            # 处理特殊格式
            if pd.isna(value):
                value_str = "N/A"
            elif isinstance(value, float):
                value_str = f"{value:.2f}"
            else:
                value_str = str(value)
            
            lines.append(f"- {key}: {value_str}")
        
        return "\n".join(lines)
    
    def save_as_jsonl(
        self,
        output_path: str,
        start_idx: int = 0,
        end_idx: int = None,
    ):
        """保存为 Trace2Skill 兼容的 JSONL 格式"""
        instances = self.load_instances(start_idx, end_idx)
        
        with open(output_path, "w", encoding="utf-8") as f:
            for inst in instances:
                record = {
                    "id": inst.id,
                    "instruction": inst.instruction,
                    "ground_truth": inst.ground_truth,
                    "features": inst.features,
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        
        print(f"Saved {len(instances)} instances to {output_path}")
    
    def get_data_summary(self) -> Dict:
        """获取数据摘要（复用原 SBADataLoader）"""
        return self.data_loader.get_data_summary()
```

---

## Part 3: 创建信贷风控 Agent（对应 cli_skill_preloaded）

**创建 `credit_risk_adapter/credit_risk_agent.py`**：

```python
"""信贷风控 Agent（等价于 cli_skill_preloaded_agent）

关键设计：
1. 系统提示中加载 skill（self-deepen 模式的起点）
2. 无需文件操作工具（纯推理任务）
3. 输出格式必须与原 SBA 实现一致（JSON 格式）
"""

import json
import os
import re
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, Optional

from src.react_agent import ReActAgent, AgentConfig, LLMClient
from spreadsheet_agent.agents.base import ChatHistoryLogger


@dataclass
class CreditRiskContext:
    """信贷风控任务上下文"""
    instance_id: str
    instruction: str  # 来自 SBATrace2SkillAdapter，包含完整 prompt
    ground_truth: int
    features: Dict


class CreditRiskSkillAgent:
    """信贷风控 Skill Agent
    
    等价于 cli_skill_preloaded_agent，但面向分类任务。
    """
    
    def __init__(
        self,
        client: LLMClient,
        skill_path: str,  # 初始 skill 的 SKILL.md 路径
        max_turns: int = 10,
        temperature: float = 0.0,
        verbose: bool = True,
        log_dir: Optional[str] = None,
        log_format: str = "markdown",
    ):
        self.client = client
        self.max_turns = max_turns
        self.temperature = temperature
        self.verbose = verbose
        
        # 加载 skill 内容
        self.skill_content = self._load_skill(skill_path)
        
        # 设置日志
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
            self._logger = ChatHistoryLogger(
                log_dir=log_dir,
                format=log_format,
            )
        else:
            self._logger = None
        
        self._agent: Optional[ReActAgent] = None
    
    @property
    def name(self) -> str:
        return "credit_risk_skill_agent"
    
    def _load_skill(self, skill_path: str) -> str:
        """加载 skill 内容（去除 YAML frontmatter）"""
        content = Path(skill_path).read_text(encoding="utf-8")
        
        # 去除 frontmatter
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                content = parts[2].strip()
        
        return content
    
    def _get_system_prompt(self) -> str:
        """构建系统提示（类似 cli_skill_preloaded 的 skill 预加载）"""
        return f"""You are a credit risk assessment expert with access to evolved skills.

# EVOLVED SKILL

{self.skill_content}

# TASK INSTRUCTIONS

You will receive loan application data. Use the skill above to analyze the risk and predict whether the borrower will default.

**CRITICAL OUTPUT FORMAT**: Your final answer MUST be valid JSON in this exact format:
{{"predicted_default": 0, "reasoning": "your analysis"}}

Where predicted_default is 0 (will not default) or 1 (will default).

Guidelines:
1. Apply the skill guidance above when analyzing risk factors
2. Provide clear reasoning based on the skill's patterns
3. Output ONLY the JSON object as your final answer (no markdown code blocks)
"""
    
    def run(self, context: CreditRiskContext) -> Dict:
        """运行 agent 进行预测
        
        Returns:
            {{
                "success": bool,
                "prediction": int,  # 0 or 1
                "answer": str,      # 原始回答
                "turns": int,
                "error": str,
            }}
        """
        # 创建 agent（无工具）
        if self._agent is None:
            config = AgentConfig(
                max_turns=self.max_turns,
                verbose=self.verbose,
                system_instructions=self._get_system_prompt(),
            )
            self._agent = ReActAgent(
                client=self.client,
                tools=[],  # 无工具
                config=config,
            )
        
        # 开始日志
        if self._logger:
            self._logger.start_session(self.name, context.instruction, None)
            self._logger.log_system_prompt(self._get_system_prompt())
            self._logger.log_user_task(context.instruction)
        
        try:
            result = self._agent.run(context.instruction)
            
            # 解析 JSON 输出（与原 SBA 实现一致）
            prediction, reasoning = self._parse_json_output(result.final_answer)
            
            success = result.success and prediction is not None
            
            run_result = {
                "success": success,
                "prediction": prediction,
                "answer": result.final_answer,
                "reasoning": reasoning,
                "turns": result.total_turns,
                "error": "" if success else "Failed to parse prediction",
            }
            
            if self._logger:
                self._logger.log_result(
                    success=success,
                    answer=result.final_answer,
                    turns=result.total_turns,
                    error=run_result["error"],
                )
            
            return run_result
            
        except Exception as e:
            error_msg = f"Exception: {str(e)}"
            error_result = {
                "success": False,
                "prediction": None,
                "answer": "",
                "reasoning": "",
                "turns": 0,
                "error": error_msg,
            }
            
            if self._logger:
                self._logger.log_result(False, "", 0, error_msg)
            
            return error_result
    
    def _parse_json_output(self, answer: str) -> tuple[Optional[int], str]:
        """解析 JSON 输出（与原 SBA baseline 一致）"""
        try:
            # 移除可能的 markdown code block
            cleaned = answer.strip()
            if cleaned.startswith("```"):
                cleaned = re.sub(r"```(?:json)?\s*", "", cleaned)
                cleaned = re.sub(r"```\s*$", "", cleaned)
            
            # 解析 JSON
            parsed = json.loads(cleaned)
            prediction = parsed.get("predicted_default")
            reasoning = parsed.get("reasoning", "")
            
            if prediction in (0, 1):
                return int(prediction), reasoning
            
        except (json.JSONDecodeError, KeyError, ValueError):
            pass
        
        # 回退：简单文本匹配
        if "predicted_default\": 1" in answer or "\"predicted_default\": 1" in answer:
            return 1, ""
        if "predicted_default\": 0" in answer or "\"predicted_default\": 0" in answer:
            return 0, ""
        
        return None, ""
```

---

## Part 4: 创建 Runner（生成轨迹）

**创建 `credit_risk_adapter/credit_risk_runner.py`**：

```python
"""信贷风控 Runner（等价于 SpreadsheetBenchRunner）"""

import json
import os
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field
from typing import List

from credit_risk_adapter.trace2skill_adapter import (
    SBATrace2SkillAdapter,
    CreditRiskInstance,
)
from credit_risk_adapter.credit_risk_agent import (
    CreditRiskSkillAgent,
    CreditRiskContext,
)


@dataclass
class CreditRiskResult:
    """单个实例的结果"""
    id: str
    instruction: str
    ground_truth: int
    prediction: Optional[int]
    success: bool
    reasoning: str = ""
    turns: int = 0
    error: str = ""


@dataclass
class BenchmarkResult:
    """整体 benchmark 结果"""
    agent_name: str
    model: str
    timestamp: str
    total_instances: int
    correct_predictions: int
    accuracy: float
    results: List[CreditRiskResult] = field(default_factory=list)


class CreditRiskRunner:
    """信贷风控任务 Runner
    
    功能等价于 SpreadsheetBenchRunner，但面向分类任务。
    """
    
    def __init__(
        self,
        agent: CreditRiskSkillAgent,
        data_path: str,
        output_dir: str = "outputs/creditrisk",
    ):
        self.agent = agent
        self.adapter = SBATrace2SkillAdapter(data_path=data_path)
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def load_data(
        self,
        start_idx: int = 0,
        end_idx: int = None,
    ) -> List[CreditRiskInstance]:
        """加载数据集"""
        return self.adapter.load_instances(start_idx, end_idx)
    
    def run_instance(self, instance: CreditRiskInstance) -> CreditRiskResult:
        """运行单个实例"""
        context = CreditRiskContext(
            instance_id=instance.id,
            instruction=instance.instruction,
            ground_truth=instance.ground_truth,
            features=instance.features,
        )
        
        agent_result = self.agent.run(context)
        
        return CreditRiskResult(
            id=instance.id,
            instruction=instance.instruction,
            ground_truth=instance.ground_truth,
            prediction=agent_result["prediction"],
            success=agent_result["success"],
            reasoning=agent_result.get("reasoning", ""),
            turns=agent_result["turns"],
            error=agent_result["error"],
        )
    
    def run(
        self,
        start_idx: int = 0,
        end_idx: int = None,
    ) -> BenchmarkResult:
        """运行 benchmark"""
        instances = self.load_data(start_idx, end_idx)
        print(f"Loaded {len(instances)} instances ({start_idx} to {end_idx or 'end'})")
        
        results = []
        correct_count = 0
        
        for i, instance in enumerate(instances, start=1):
            print(f"\nInstance {i}/{len(instances)}: {instance.id}")
            result = self.run_instance(instance)
            results.append(result)
            
            if result.success and result.prediction == result.ground_truth:
                correct_count += 1
                print(f"  ✓ CORRECT (predicted {result.prediction})")
            else:
                print(f"  ✗ WRONG (predicted {result.prediction}, truth {result.ground_truth})")
        
        accuracy = correct_count / len(instances) if instances else 0
        
        return BenchmarkResult(
            agent_name=self.agent.name,
            model=getattr(self.agent.client, "model", "unknown"),
            timestamp=datetime.now().isoformat(),
            total_instances=len(instances),
            correct_predictions=correct_count,
            accuracy=accuracy,
            results=results,
        )
    
    def run_and_save(
        self,
        results_file: str = None,
        start_idx: int = 0,
        end_idx: int = None,
    ) -> BenchmarkResult:
        """运行并保存结果"""
        result = self.run(start_idx, end_idx)
        
        results_file = results_file or os.path.join(self.output_dir, "results.json")
        
        # 序列化
        result_dict = {
            "agent_name": result.agent_name,
            "model": result.model,
            "timestamp": result.timestamp,
            "total_instances": result.total_instances,
            "correct_predictions": result.correct_predictions,
            "accuracy": result.accuracy,
            "results": [
                {
                    "id": r.id,
                    "ground_truth": r.ground_truth,
                    "prediction": r.prediction,
                    "success": r.success,
                    "reasoning": r.reasoning,
                    "turns": r.turns,
                    "error": r.error,
                }
                for r in result.results
            ],
        }
        
        with open(results_file, "w", encoding="utf-8") as f:
            json.dump(result_dict, f, indent=2, ensure_ascii=False)
        
        print(f"\n{'='*60}")
        print(f"BENCHMARK COMPLETE")
        print(f"Total: {result.total_instances}, Correct: {result.correct_predictions}")
        print(f"Accuracy: {result.accuracy*100:.2f}%")
        print(f"Results: {results_file}")
        print(f"{'='*60}")
        
        return result
```

---

## Part 5: 创建主运行脚本

**创建 `run_sba_trace2skill.py`**：

```python
#!/usr/bin/env python3
"""SBA 信贷风控数据集的 Trace2Skill 运行脚本

完全复用：
1. SBADataLoader 的数据预处理
2. SBA prompt 模板
3. Trace2Skill 的 skill evolution pipeline
"""

import argparse
import os
import sys
from pathlib import Path

from src.react_agent import OpenAIClient
from credit_risk_adapter.credit_risk_agent import CreditRiskSkillAgent
from credit_risk_adapter.credit_risk_runner import CreditRiskRunner


def main():
    parser = argparse.ArgumentParser(
        description="Run SBA credit risk agent with Trace2Skill framework"
    )
    parser.add_argument(
        "--data_path",
        type=str,
        required=True,
        help="Path to SBA CSV file",
    )
    parser.add_argument(
        "--skill_path",
        type=str,
        required=True,
        help="Path to SKILL.md (initial or evolved skill)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o",
        help="Model name",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="outputs/sba",
        help="Output directory",
    )
    parser.add_argument(
        "--log_dir",
        type=str,
        default=None,
        help="Log directory",
    )
    parser.add_argument(
        "--start_idx",
        type=int,
        default=0,
        help="Start index",
    )
    parser.add_argument(
        "--end_idx",
        type=int,
        default=None,
        help="End index",
    )
    parser.add_argument(
        "--max_turns",
        type=int,
        default=10,
        help="Max turns per instance",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of parallel workers (TODO: implement)",
    )
    
    args = parser.parse_args()
    
    # 检查环境变量
    if not os.getenv("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY not set")
        sys.exit(1)
    
    # 创建 client
    client = OpenAIClient(
        model=args.model,
        api_key=os.getenv("OPENAI_API_KEY"),
        base_url=os.getenv("OPENAI_BASE_URL"),
    )
    
    # 创建 agent
    agent = CreditRiskSkillAgent(
        client=client,
        skill_path=args.skill_path,
        max_turns=args.max_turns,
        verbose=True,
        log_dir=args.log_dir,
        log_format="markdown",
    )
    
    # 创建 runner
    runner = CreditRiskRunner(
        agent=agent,
        data_path=args.data_path,
        output_dir=args.output_dir,
    )
    
    # 运行
    runner.run_and_save(
        start_idx=args.start_idx,
        end_idx=args.end_idx,
    )


if __name__ == "__main__":
    main()
```

---

## Part 6: 多轮迭代脚本

**创建 `run_sba_multi_round_evolution.sh`**：

```bash
#!/bin/bash
# SBA 数据集多轮迭代演化脚本

set -e

DATA_PATH="data/SBA/SBAcase.11.13.17.csv"
MODEL="gpt-4o"
WORKERS=32
INITIAL_SKILL="credit_risk_adapter/skills/sba_initial/SKILL.md"
OUTPUT_ROOT="outputs/sba_multi_round"

# 迭代轮数
MAX_ROUNDS=3

echo "==================================="
echo "SBA Multi-Round Evolution Pipeline"
echo "==================================="
echo "Data: $DATA_PATH"
echo "Model: $MODEL"
echo "Max rounds: $MAX_ROUNDS"
echo "==================================="

# Round 0: 用初始 skill 生成轨迹
echo ""
echo "ROUND 0: Generating trajectories with initial skill..."
ROUND_DIR="$OUTPUT_ROOT/round_0"
mkdir -p "$ROUND_DIR"

python run_sba_trace2skill.py \
  --data_path "$DATA_PATH" \
  --skill_path "$INITIAL_SKILL" \
  --model "$MODEL" \
  --output_dir "$ROUND_DIR/outputs" \
  --log_dir "$ROUND_DIR/logs" \
  --start_idx 0 \
  --end_idx 200

# 计算 baseline 准确率
BASELINE_ACCURACY=$(python -c "
import json
with open('$ROUND_DIR/outputs/results.json') as f:
    data = json.load(f)
print(data['accuracy'])
")
echo "Baseline accuracy: $BASELINE_ACCURACY"

# 迭代演化
for round in $(seq 1 $MAX_ROUNDS); do
    echo ""
    echo "======================================="
    echo "ROUND $round: Evolution and validation"
    echo "======================================="
    
    PREV_ROUND=$((round - 1))
    PREV_DIR="$OUTPUT_ROOT/round_$PREV_ROUND"
    CURR_DIR="$OUTPUT_ROOT/round_$round"
    mkdir -p "$CURR_DIR"
    
    # Step 1: 分析上一轮轨迹
    echo "Step 1: Analyzing round $PREV_ROUND trajectories..."
    
    python analysis/run_error_analysis.py \
      --data_path "$DATA_PATH" \
      --logs_dir "$PREV_DIR/logs" \
      --output_dir "$CURR_DIR/error_analysis" \
      --model "$MODEL" \
      --workers "$WORKERS"
    
    python analysis/run_success_analysis_llm.py \
      --logs_dir "$PREV_DIR/logs" \
      --output_dir "$CURR_DIR/success_analysis" \
      --model "$MODEL" \
      --max_workers "$WORKERS"
    
    python analysis/parse_error_analysis_outputs.py \
      --input_dir "$CURR_DIR/error_analysis" \
      --output "$CURR_DIR/error_analysis_parsed.json"
    
    python analysis/parse_success_analysis_outputs.py \
      --input_dir "$CURR_DIR/success_analysis" \
      --output "$CURR_DIR/success_analysis_parsed.json"
    
    # Step 2: 演化 skill
    echo "Step 2: Evolving skill..."
    
    # 拷贝上一轮的 skill 作为起点
    SKILL_DIR="$CURR_DIR/skill"
    if [ $round -eq 1 ]; then
        mkdir -p "$SKILL_DIR"
        cp "$INITIAL_SKILL" "$SKILL_DIR/SKILL.md"
    else
        cp -r "$OUTPUT_ROOT/round_$PREV_ROUND/skill" "$SKILL_DIR"
    fi
    
    python -m skill_evolver.run_parallel_combined_skill_evolution \
      --error-json "$CURR_DIR/error_analysis_parsed.json" \
      --success-json "$CURR_DIR/success_analysis_parsed.json" \
      --skill-dir "$SKILL_DIR" \
      --model "$MODEL" \
      --max-workers "$WORKERS" \
      --batch-size 5 \
      --continue-evolving \
      --changelog "$CURR_DIR/evolution_changelog.md"
    
    # Step 3: 用演化后的 skill 重新生成轨迹
    echo "Step 3: Validating evolved skill..."
    
    python run_sba_trace2skill.py \
      --data_path "$DATA_PATH" \
      --skill_path "$SKILL_DIR/SKILL.md" \
      --model "$MODEL" \
      --output_dir "$CURR_DIR/outputs" \
      --log_dir "$CURR_DIR/logs" \
      --start_idx 0 \
      --end_idx 200
    
    # 计算准确率
    CURR_ACCURACY=$(python -c "
import json
with open('$CURR_DIR/outputs/results.json') as f:
    data = json.load(f)
print(data['accuracy'])
")
    
    echo "Round $round accuracy: $CURR_ACCURACY (baseline: $BASELINE_ACCURACY)"
    
    # 检查是否提升
    IMPROVED=$(python -c "print(1 if $CURR_ACCURACY > $BASELINE_ACCURACY else 0)")
    if [ "$IMPROVED" -eq 1 ]; then
        echo "✓ Improvement detected!"
        BASELINE_ACCURACY=$CURR_ACCURACY
    else
        echo "✗ No improvement, stopping iteration"
        break
    fi
done

echo ""
echo "==================================="
echo "Multi-round evolution completed!"
echo "Final accuracy: $BASELINE_ACCURACY"
echo "==================================="
```

---

## Part 7: 完整工作流

### Step 7.1: 准备环境

```bash
cd D:/huawei/Trace2Skill

# 拷贝 SBA 依赖
bash -c "
mkdir -p credit_risk_adapter
cp D:/huawei/gh_auto_research/benchmark_test/data_loader_sba.py credit_risk_adapter/
cp D:/huawei/gh_auto_research/benchmark_test/prompts/default_prompt.txt credit_risk_adapter/sba_prompt_template.txt
cp D:/huawei/gh_auto_research/benchmark_test/logger.py credit_risk_adapter/
"

# 修改 import
sed -i 's/from benchmark_test.logger/from credit_risk_adapter.logger/g' credit_risk_adapter/data_loader_sba.py

# 准备初始 skill
mkdir -p credit_risk_adapter/skills/sba_initial
# 将你的初始 SBA skill 放到这里
cp <你的初始skill路径> credit_risk_adapter/skills/sba_initial/SKILL.md
```

### Step 7.2: 单轮演化（验证流程）

```bash
# 设置环境变量
export OPENAI_API_KEY=<your_key>
export OPENAI_BASE_URL=<optional>

# 生成轨迹
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model gpt-4o \
  --output_dir outputs/sba_round_0 \
  --log_dir outputs/sba_round_0/logs \
  --start_idx 0 \
  --end_idx 50  # 先测试 50 条

# 检查日志格式
ls outputs/sba_round_0/logs/*.md | head -3
```

### Step 7.3: 多轮迭代

```bash
chmod +x run_sba_multi_round_evolution.sh
./run_sba_multi_round_evolution.sh
```

---

## 关键修正总结

### ✅ 完全复用 SBA 原实现
1. **数据加载**: 直接使用 `SBADataLoader`，保持特征命名、预处理逻辑完全一致
2. **Prompt**: 复用 `default_prompt.txt` 模板和 JSON 输出格式
3. **特征格式化**: `_format_loan_info()` 保持与原实现一致

### ✅ 遵循 Trace2Skill 论文实现
1. **Agent 设计**: 等价于 `cli_skill_preloaded_agent`（加载 skill）
2. **日志格式**: markdown 格式，兼容 analysis 脚本
3. **演化 pipeline**: 完全复用 `skill_evolver`（无需修改）

### ✅ 支持多轮迭代
1. 手动循环：演化 → 验证 → 重新生成轨迹 → 再演化
2. 早停机制：准确率不提升时停止
3. `--continue-evolving`: 避免重复备份

### ⚠️ 仍需适配的部分
- `analysis/error_analysis_system.txt` 中的 spreadsheet 术语需要改为信贷风控术语
- `analysis/run_error_analysis.py` 中的 `find_gold_file()` 需要改为比较预测值与真实标签

这些适配我会在下一个文件中提供。
