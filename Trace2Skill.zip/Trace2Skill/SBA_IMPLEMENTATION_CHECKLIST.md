# SBA信贷风控适配Trace2Skill - 实施检查清单

## 使用此清单

在执行测试前，逐项检查以下内容。每完成一项，在 [ ] 中标记为 [x]。

---

## Phase 1: 环境准备

### 依赖安装
- [ ] 已安装基础依赖：`pip install openai tqdm openpyxl requests diskcache`
- [ ] 已安装数据处理依赖：`pip install pandas numpy scikit-learn`
- [ ] 已设置OPENAI_API_KEY：`export OPENAI_API_KEY=<your_key>`
- [ ] （可选）已设置OPENAI_BASE_URL：`export OPENAI_BASE_URL=<url>`

### 文件拷贝
- [ ] 已拷贝 `data_loader_sba.py` 到 `credit_risk_adapter/`
- [ ] 已拷贝 `default_prompt.txt` 到 `credit_risk_adapter/sba_prompt_template.txt`
- [ ] 已拷贝 `logger.py` 到 `credit_risk_adapter/`

### Import修改
- [ ] 已在 `credit_risk_adapter/data_loader_sba.py` 中修改import路径
  ```python
  # 从: from benchmark_test.logger import get_logger
  # 到: from credit_risk_adapter.logger import get_logger
  ```

### 数据和Skill准备
- [ ] SBA数据文件存在：`data/SBA/SBAcase.11.13.17.csv`
- [ ] 已创建目录：`credit_risk_adapter/skills/sba_initial/`
- [ ] 已准备初始SKILL.md：`credit_risk_adapter/skills/sba_initial/SKILL.md`
- [ ] SKILL.md包含YAML frontmatter（name, description）

---

## Phase 2: 快速验证测试（3个样本）

### 执行测试
```bash
chmod +x test_sba_adaptation.sh
./test_sba_adaptation.sh
```

### 验证点
- [ ] [1/6] 所有依赖文件检查通过
- [ ] [2/6] 环境变量检查通过
- [ ] [3/6] 数据加载器测试通过（加载5个实例）
- [ ] [4/6] Agent初始化测试通过
- [ ] [5/6] 小规模运行完成（3个样本）
- [ ] [6/6] 输出验证通过

### 输出检查
- [ ] 生成文件：`outputs/sba_quick_test/results.json`
- [ ] 生成日志：`outputs/sba_quick_test/logs/*.md`（共3个）
- [ ] results.json包含字段：accuracy, total_instances, correct_predictions
- [ ] 日志文件格式正确（markdown格式，包含reasoning）

---

## Phase 3: 小规模测试（50个样本）

### 执行测试
```bash
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model gpt-4o \
  --output_dir outputs/sba_test_50 \
  --start_idx 0 --end_idx 50
```

### 验证点
- [ ] 运行完成，无Python异常
- [ ] 生成50个日志文件：`ls outputs/sba_test_50/logs/*.md | wc -l`
- [ ] results.json中total_instances=50
- [ ] accuracy在合理范围内（如0.5-0.9）

### 日志检查（抽查）
```bash
# 查看第一个日志
head -50 outputs/sba_test_50/logs/credit_risk_skill_agent_0.md
```
- [ ] 包含系统提示（含skill内容）
- [ ] 包含用户任务（loan features）
- [ ] 包含assistant推理
- [ ] 包含RESULT章节（success, turns）

---

## Phase 4: Error Analysis测试

### 执行测试
```bash
python analysis/run_error_analysis.py \
  --data_path outputs/sba_test_50/results.json \
  --logs_dir outputs/sba_test_50/logs \
  --output_dir outputs/sba_test_50/error_analysis \
  --model gpt-4o \
  --task_type credit_risk \
  --workers 4
```

### 验证点
- [ ] 运行完成，无Python异常
- [ ] 生成目录：`outputs/sba_test_50/error_analysis/`
- [ ] 包含子目录（每个失败实例一个）
- [ ] 生成文件：`error_analysis_parsed.json`

### 解析结果检查
```bash
cat outputs/sba_test_50/error_analysis/error_analysis_parsed.json | jq '.[0]'
```
- [ ] JSON结构正确（包含id, error_type, suggestions等）
- [ ] pass_gate字段存在
- [ ] 与spreadsheet版本的JSON结构兼容

---

## Phase 5: Success Analysis测试

### 执行测试
```bash
python analysis/run_success_analysis_llm.py \
  --logs_dir outputs/sba_test_50/logs \
  --output_dir outputs/sba_test_50/success_analysis \
  --model gpt-4o \
  --max_workers 4
```

### 验证点
- [ ] 运行完成，无Python异常
- [ ] 生成目录：`outputs/sba_test_50/success_analysis/`
- [ ] 生成文件：`success_analysis_parsed.json`

---

## Phase 6: Skill Evolution测试

### 执行测试
```bash
mkdir -p outputs/sba_test_50/skill_evolution
cp credit_risk_adapter/skills/sba_initial/SKILL.md outputs/sba_test_50/skill_evolution/

python -m skill_evolver.run_parallel_combined_skill_evolution \
  --error-json outputs/sba_test_50/error_analysis/error_analysis_parsed.json \
  --success-json outputs/sba_test_50/success_analysis/success_analysis_parsed.json \
  --skill-dir outputs/sba_test_50/skill_evolution \
  --model gpt-4o \
  --max-workers 4 \
  --batch-size 3
```

### 验证点
- [ ] 运行完成，无Python异常
- [ ] SKILL.md文件被修改（与初始版本不同）
- [ ] 生成changelog（如果有--changelog参数）

### Skill变化检查
```bash
diff credit_risk_adapter/skills/sba_initial/SKILL.md \
     outputs/sba_test_50/skill_evolution/SKILL.md
```
- [ ] 有实质性修改（不仅是格式变化）
- [ ] frontmatter保持完整
- [ ] 新增或修改了风险评估模式

---

## Phase 7: 完整多轮演化（可选，200个样本）

### 执行测试
```bash
# 检查脚本配置
cat run_sba_multi_round_evolution.sh | head -20

# 如需要，修改DATA_PATH, MODEL等变量
vim run_sba_multi_round_evolution.sh

# 执行
chmod +x run_sba_multi_round_evolution.sh
./run_sba_multi_round_evolution.sh
```

### 验证点
- [ ] Round 0完成：生成初始轨迹
- [ ] Round 0 accuracy记录在终端输出
- [ ] Round 1完成：分析→演化→验证
- [ ] Round 1 accuracy与Round 0对比
- [ ] 如有提升，继续Round 2-3
- [ ] 如无提升，早停机制生效

### 输出结构检查
```bash
tree outputs/sba_multi_round/ -L 2
```
- [ ] 包含round_0/目录（outputs/, logs/）
- [ ] 包含round_1/目录（error_analysis/, success_analysis/, skill/, outputs/, logs/）
- [ ] 每轮都有results.json记录accuracy

---

## Phase 8: 代码质量检查

### 新增文件存在性
- [ ] `credit_risk_adapter/__init__.py`
- [ ] `credit_risk_adapter/trace2skill_adapter.py`
- [ ] `credit_risk_adapter/credit_risk_agent.py`
- [ ] `credit_risk_adapter/credit_risk_runner.py`
- [ ] `run_sba_trace2skill.py`
- [ ] `run_sba_multi_round_evolution.sh`
- [ ] `test_sba_adaptation.sh`
- [ ] `analysis/credit_risk_error_analysis_system.txt`
- [ ] `SBA_ADAPTATION_GUIDE.md`
- [ ] `SBA_IMPLEMENTATION_SUMMARY.md`
- [ ] `SBA_README.md`

### 修改文件验证
```bash
git diff analysis/run_error_analysis.py
```
- [ ] 确认添加了--task_type参数
- [ ] 确认添加了find_ground_truth_for_credit_risk函数
- [ ] 确认build_instance_index支持credit_risk
- [ ] 确认向后兼容（默认task_type="spreadsheet"）

---

## Phase 9: 向后兼容性检查（可选）

如果你有现有的SpreadsheetBench测试：

### 执行原有测试
```bash
# 运行你原有的SpreadsheetBench脚本（如果有）
# 例如：python run_spreadsheetbench.py ...
```

### 验证点
- [ ] 原有SpreadsheetBench脚本运行正常
- [ ] 无新的错误或警告
- [ ] 输出格式和结果与之前一致
- [ ] error_analysis仍然能正常处理spreadsheet任务

---

## 完成状态

### 所有阶段汇总
- [ ] Phase 1: 环境准备 ✓
- [ ] Phase 2: 快速验证（3样本）✓
- [ ] Phase 3: 小规模测试（50样本）✓
- [ ] Phase 4: Error Analysis测试 ✓
- [ ] Phase 5: Success Analysis测试 ✓
- [ ] Phase 6: Skill Evolution测试 ✓
- [ ] Phase 7: 完整多轮演化（可选）✓
- [ ] Phase 8: 代码质量检查 ✓
- [ ] Phase 9: 向后兼容性检查（可选）✓

### 最终交付
- [ ] 所有必需的测试通过
- [ ] 文档已阅读并理解
- [ ] 代码已提交到版本控制
- [ ] 准备进行实际数据集上的完整演化

---

## 问题记录

如果某个阶段失败，记录问题：

**Phase X 失败原因**：
- 错误信息：
- 尝试的解决方案：
- 最终解决方法：

---

## 参考文档

遇到问题时查阅：
1. **SBA_README.md** - 快速开始和常见问题
2. **SBA_ADAPTATION_GUIDE.md** - 详细使用指南
3. **SBA_IMPLEMENTATION_SUMMARY.md** - 技术实现细节
4. **CREDIT_RISK_ADAPTATION.md** - 架构设计文档（原规划）
5. **CREDIT_RISK_IMPLEMENTATION.md** - 实施方案文档（原规划）
