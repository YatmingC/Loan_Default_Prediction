"""信贷风控 Agent（等价于 cli_skill_preloaded_agent）

关键设计：
1. 系统提示中加载 skill（self-deepen 模式的起点）
2. 无需文件操作工具（纯推理任务）
3. 输出格式必须与原 SBA 实现一致（JSON 格式）
"""

import json
import os
import re
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, Optional

from src.react_agent import ReActAgent, AgentConfig, LLMClient
from spreadsheet_agent.agents.base import ChatHistoryLogger


@dataclass
class CreditRiskContext:
    """信贷风控任务上下文"""
    instance_id: str
    instruction: str  # 来自 SBATrace2SkillAdapter，包含完整 prompt
    ground_truth: int
    features: Dict


class CreditRiskSkillAgent:
    """信贷风控 Skill Agent

    等价于 cli_skill_preloaded_agent，但面向分类任务。
    """

    def __init__(
        self,
        client: LLMClient,
        skill_path: str,  # 初始 skill 的 SKILL.md 路径
        max_turns: int = 10,
        temperature: float = 0.0,
        verbose: bool = True,
        log_dir: Optional[str] = None,
        log_format: str = "markdown",
    ):
        self.client = client
        self.max_turns = max_turns
        self.temperature = temperature
        self.verbose = verbose

        # 加载 skill 内容
        self.skill_content = self._load_skill(skill_path)

        # 设置日志
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
            self._logger = ChatHistoryLogger(
                log_dir=log_dir,
                format=log_format,
            )
        else:
            self._logger = None

        self._agent: Optional[ReActAgent] = None

    @property
    def name(self) -> str:
        return "credit_risk_skill_agent"

    def _load_skill(self, skill_path: str) -> str:
        """加载 skill 内容（去除 YAML frontmatter）"""
        skill_file = Path(skill_path)
        if not skill_file.exists():
            print(f"[WARNING] Skill file not found: {skill_path}, using empty skill")
            return ""

        content = skill_file.read_text(encoding="utf-8")

        # 去除 frontmatter
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                content = parts[2].strip()

        return content

    def _get_system_prompt(self) -> str:
        """构建系统提示（类似 cli_skill_preloaded 的 skill 预加载）"""
        return f"""You are a credit risk assessment expert with access to evolved skills.

# EVOLVED SKILL

{self.skill_content}

# TASK INSTRUCTIONS

You will receive loan application data. Use the skill above to analyze the risk and predict whether the borrower will default.

**CRITICAL OUTPUT FORMAT**: Your final answer MUST be valid JSON in this exact format:
{{"predicted_default": 0, "reasoning": "your analysis"}}

Where predicted_default is 0 (will not default) or 1 (will default).

Guidelines:
1. Apply the skill guidance above when analyzing risk factors
2. Provide clear reasoning based on the skill's patterns
3. Output ONLY the JSON object as your final answer (no markdown code blocks)
4. Signal completion with: ACTION: TASK_COMPLETE
"""

    def _create_step_callback(self):
        """构造 on_step 回调：把每一步 assistant 轨迹写进日志。

        与 BaseSpreadsheetAgent._create_step_callback 等价。没有 logger 时返回
        None（ReActAgent 会跳过）。关键：回调闭包持有 self._logger，而
        start_session 在每次 run 前重置当前日志文件句柄，因此并发/复用 agent
        时也会写到正确的 per-instance 文件。
        """
        if self._logger is None:
            return None

        def on_step(step) -> None:
            self._logger.log_step(step)

        return on_step

    def run(self, context: CreditRiskContext) -> Dict:
        """运行 agent 进行预测

        Returns:
            {{
                "success": bool,
                "prediction": int,  # 0 or 1
                "answer": str,      # 原始回答
                "reasoning": str,   # 推理过程
                "turns": int,
                "error": str,
            }}
        """
        # 创建 agent（无工具）
        if self._agent is None:
            config = AgentConfig(
                max_turns=self.max_turns,
                verbose=self.verbose,
                system_instructions=self._get_system_prompt(),
            )
            self._agent = ReActAgent(
                client=self.client,
                tools=[],  # 无工具
                config=config,
                on_step=self._create_step_callback(),
            )

        # 开始日志
        if self._logger:
            # 创建一个临时的 AgentContext 用于日志命名
            from spreadsheet_agent.agents.base import AgentContext
            temp_context = AgentContext(
                working_dir="",
                input_file="",
                output_file="",
                instruction=context.instruction,
                instance_id=context.instance_id,
            )
            self._logger.start_session(self.name, context.instruction, temp_context)
            self._logger.log_system_prompt(self._get_system_prompt())
            self._logger.log_user_task(context.instruction)

        try:
            result = self._agent.run(context.instruction)

            # 解析 JSON 输出（与原 SBA 实现一致）
            prediction, reasoning = self._parse_json_output(result.final_answer)

            success = result.success and prediction is not None

            run_result = {
                "success": success,
                "prediction": prediction,
                "answer": result.final_answer,
                "reasoning": reasoning,
                "turns": result.total_turns,
                "error": "" if success else "Failed to parse prediction",
            }

            if self._logger:
                self._logger.log_result(
                    success=success,
                    answer=result.final_answer,
                    turns=result.total_turns,
                    error=run_result["error"],
                )

            return run_result

        except Exception as e:
            error_msg = f"Exception: {str(e)}"
            error_result = {
                "success": False,
                "prediction": None,
                "answer": "",
                "reasoning": "",
                "turns": 0,
                "error": error_msg,
            }

            if self._logger:
                self._logger.log_result(False, "", 0, error_msg)

            return error_result

    def _parse_json_output(self, answer: str) -> tuple:
        """解析 JSON 输出（与原 SBA baseline 一致）

        Returns:
            (prediction: Optional[int], reasoning: str)
            prediction 为显式规整后的 int {0,1}；无法识别时返回 None
            （由上层 metrics 的 parse_failures 统计，并按 0 计入指标）。
        """
        try:
            # 移除可能的 markdown code block
            cleaned = answer.strip()
            if cleaned.startswith("```"):
                cleaned = re.sub(r"```(?:json)?\s*", "", cleaned)
                cleaned = re.sub(r"```\s*$", "", cleaned)

            # 解析 JSON
            parsed = json.loads(cleaned)
            reasoning = parsed.get("reasoning", "")
            raw = parsed.get("predicted_default")

            # 显式规整：只接受明确的 0/1（含 bool True/False、"0"/"1"、1.0），
            # 其余（如 None、2、"maybe"）视为无法解析，返回 None。
            pred = self._normalize_prediction(raw)
            if pred is not None:
                return pred, reasoning

        except (json.JSONDecodeError, KeyError, ValueError):
            pass

        # 回退：简单文本匹配
        if '"predicted_default": 1' in answer or "'predicted_default': 1" in answer:
            return 1, ""
        if '"predicted_default": 0' in answer or "'predicted_default': 0" in answer:
            return 0, ""

        return None, ""

    @staticmethod
    def _normalize_prediction(raw) -> Optional[int]:
        """把原始预测值显式规整为 int {0,1}，无法识别返回 None。

        显式区分类型，避免 int 与 bool / str 之间的隐式比较。
        """
        if raw is None:
            return None
        # bool 必须先于 int 判断（bool 是 int 子类）
        if isinstance(raw, bool):
            return 1 if raw else 0
        if isinstance(raw, int):
            return raw if raw in (0, 1) else None
        if isinstance(raw, float):
            if raw == 0.0:
                return 0
            if raw == 1.0:
                return 1
            return None
        if isinstance(raw, str):
            s = raw.strip().lower()
            if s in ("1", "true", "yes", "违约"):
                return 1
            if s in ("0", "false", "no", "不违约"):
                return 0
            return None
        return None

