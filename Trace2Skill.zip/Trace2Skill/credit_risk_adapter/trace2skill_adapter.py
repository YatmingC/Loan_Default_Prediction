"""将 SBA 数据适配为 Trace2Skill 的轨迹生成/分析格式

核心职责：
1. 复用 SBADataLoader 的完整预处理逻辑
2. 复用原 SBA prompt 模板
3. 转换为 Trace2Skill 的 instance 格式（用于轨迹生成）
"""

import json
import pandas as pd
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict


@dataclass
class CreditRiskInstance:
    """单条信贷记录（Trace2Skill instance 格式）"""
    id: str
    instruction: str  # 包含特征的完整 prompt（复用 SBA 原 prompt 模板）
    ground_truth: int  # 真实标签
    features: Dict  # 原始特征字典（用于日志记录）
    metadata: Dict = field(default_factory=dict)


class SBATrace2SkillAdapter:
    """SBA 数据集到 Trace2Skill 格式的适配器

    严格复用 SBADataLoader 的所有预处理逻辑和特征命名。
    """

    def __init__(
        self,
        data_path: str,
        prompt_template_path: str = "credit_risk_adapter/sba_prompt_template.txt",
    ):
        """
        Args:
            data_path: SBA CSV 文件路径
            prompt_template_path: SBA prompt 模板路径（复用原实现）
        """
        # 延迟导入，避免循环依赖
        from credit_risk_adapter.data_loader_sba import SBADataLoader

        # 使用原 SBADataLoader
        self.data_loader = SBADataLoader(data_path=data_path)

        # 加载原 SBA prompt 模板
        template_path = Path(prompt_template_path)
        if template_path.exists():
            self.prompt_template = template_path.read_text(encoding="utf-8")
        else:
            # 如果模板文件不存在，使用默认模板
            self.prompt_template = self._get_default_prompt_template()

    def _get_default_prompt_template(self) -> str:
        """默认 prompt 模板（与原 SBA 实现一致）"""
        return """You are a credit risk assessment expert. Based on the following loan application features, predict whether the borrower will default.

Loan Application Features:
{loan_info}

**Task**: Analyze the risk factors and predict whether this loan will default.

**Output Format**: Your response MUST be a valid JSON object in this exact format:
{{"predicted_default": 0, "reasoning": "your detailed analysis"}}

Where:
- predicted_default: 0 (will NOT default) or 1 (will default)
- reasoning: your analysis of key risk factors

Output ONLY the JSON object (no markdown code blocks, no extra text)."""

    def load_instances(
        self,
        start_idx: int = 0,
        end_idx: int = None,
    ) -> List[CreditRiskInstance]:
        """加载数据为 Trace2Skill instance 格式

        完全复用 SBADataLoader 的预处理逻辑。
        """
        # 调用原 SBADataLoader 的预处理
        X, y = self.data_loader.prepare_for_inference(sample_size=None)

        # 切片
        if end_idx is None:
            end_idx = len(X)
        X = X.iloc[start_idx:end_idx]
        y = y.iloc[start_idx:end_idx]

        instances = []
        for idx, (row_idx, features_row) in enumerate(X.iterrows()):
            # 构建 loan_info 字符串（与原 SBA 实现一致）
            loan_info = self._format_loan_info(features_row)

            # 使用原 SBA prompt 模板
            instruction = self.prompt_template.format(loan_info=loan_info)

            instances.append(CreditRiskInstance(
                id=str(row_idx),
                instruction=instruction,
                ground_truth=int(y.iloc[idx]),
                features=features_row.to_dict(),
            ))

        return instances

    def _format_loan_info(self, features: pd.Series) -> str:
        """格式化 loan_info 字符串（与原 SBA baseline 推理一致）

        使用与 gh_auto_research 项目完全相同的特征展示格式。
        """
        lines = []
        for key, value in features.items():
            # 处理特殊格式
            if pd.isna(value):
                value_str = "N/A"
            elif isinstance(value, float):
                value_str = f"{value:.2f}"
            else:
                value_str = str(value)

            lines.append(f"- {key}: {value_str}")

        return "\n".join(lines)

    def save_as_jsonl(
        self,
        output_path: str,
        start_idx: int = 0,
        end_idx: int = None,
    ):
        """保存为 Trace2Skill 兼容的 JSONL 格式"""
        instances = self.load_instances(start_idx, end_idx)

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            for inst in instances:
                record = {
                    "id": inst.id,
                    "instruction": inst.instruction,
                    "ground_truth": inst.ground_truth,
                    "features": inst.features,
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

        print(f"Saved {len(instances)} instances to {output_path}")

    def get_data_summary(self) -> Dict:
        """获取数据摘要（复用原 SBADataLoader）"""
        return self.data_loader.get_data_summary()
