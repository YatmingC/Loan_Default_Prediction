"""信贷风控二分类指标计算（口径对齐原 SBA baseline_inference.py）

关键约定（与 gh_auto_research/benchmark_test/baseline_inference.py 一致）：
- 正类 (positive) = 1，表示「违约 / default」
- precision / recall / f1 均为 binary 口径（pos_label=1, average='binary'）
- zero_division=0：分母为 0 时指标取 0 而非报错
- 标签规整：y_true 与 y_pred 在比较前都强制转成 int {0,1}
  （对应原 SBA 的 pd.to_numeric(errors='coerce').fillna(0).astype(int)）
- 预测缺失 (None / 无法解析) 视为 0（不违约），与原 SBA 的 fillna(0) 一致

本模块杜绝「不同类型直接比较」：所有标签（无论来源是 int / bool / str /
是否 / True-False）都先经 to_binary_label() 规整到同一 int 域，再比较。
"""

from __future__ import annotations

from typing import Any, List, Sequence


# 字符串标签到二分类的显式映射（大小写不敏感）
_POSITIVE_STRINGS = {"1", "true", "yes", "y", "是", "违约", "default", "defaulted"}
_NEGATIVE_STRINGS = {"0", "false", "no", "n", "否", "不违约", "non-default", "no default", "nondefault"}


def to_binary_label(value: Any, default_on_fail: int = 0) -> int:
    """把任意类型的标签显式规整为 int {0, 1}。

    显式处理 int / float / bool / str / None，避免 int 与 bool / str / 是否
    之间直接比较。无法识别时返回 default_on_fail（默认 0，对齐 SBA fillna(0)）。

    Args:
        value: 原始标签（可能是 int / float / bool / str / None）
        default_on_fail: 无法解析时的回退值（默认 0）

    Returns:
        int，0 或 1
    """
    if value is None:
        return default_on_fail

    # bool 必须在 int 之前判断（bool 是 int 的子类）
    if isinstance(value, bool):
        return 1 if value else 0

    if isinstance(value, (int, float)):
        try:
            v = int(round(float(value)))
        except (ValueError, TypeError, OverflowError):
            return default_on_fail
        return 1 if v == 1 else 0

    if isinstance(value, str):
        s = value.strip().lower()
        if s in _POSITIVE_STRINGS:
            return 1
        if s in _NEGATIVE_STRINGS:
            return 0
        # 退路：尝试把字符串当数值解析（如 "1.0"）
        try:
            v = int(round(float(s)))
            return 1 if v == 1 else 0
        except (ValueError, TypeError):
            return default_on_fail

    return default_on_fail


def _confusion_counts(y_true: Sequence[int], y_pred: Sequence[int]) -> tuple[int, int, int, int]:
    """返回 (tp, fp, fn, tn)，正类为 1。"""
    tp = sum(1 for t, p in zip(y_true, y_pred) if t == 1 and p == 1)
    fp = sum(1 for t, p in zip(y_true, y_pred) if t == 0 and p == 1)
    fn = sum(1 for t, p in zip(y_true, y_pred) if t == 1 and p == 0)
    tn = sum(1 for t, p in zip(y_true, y_pred) if t == 0 and p == 0)
    return tp, fp, fn, tn


def _manual_metrics(y_true: Sequence[int], y_pred: Sequence[int]) -> dict:
    """纯 Python 指标计算（sklearn 不可用时的回退，数值与 sklearn 一致）。"""
    tp, fp, fn, tn = _confusion_counts(y_true, y_pred)
    n = len(y_true)
    accuracy = (tp + tn) / n if n else 0.0
    precision = tp / (tp + fp) if (tp + fp) else 0.0  # zero_division=0
    recall = tp / (tp + fn) if (tp + fn) else 0.0      # zero_division=0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1_score": f1,
    }


def compute_metrics(y_true_raw: Sequence[Any], y_pred_raw: Sequence[Any]) -> dict:
    """计算二分类指标，口径对齐原 SBA。

    Args:
        y_true_raw: 真实标签序列（任意类型，内部会规整）
        y_pred_raw: 预测标签序列（任意类型，None 视为 0）

    Returns:
        指标字典，包含 accuracy / precision / recall / f1_score /
        total_samples / default_count / predicted_default_count /
        confusion_matrix / parse_failures。
    """
    if len(y_true_raw) != len(y_pred_raw):
        raise ValueError(
            f"y_true ({len(y_true_raw)}) 与 y_pred ({len(y_pred_raw)}) 长度不一致，无法对齐比较"
        )

    # 两边都显式规整到 int {0,1}，杜绝跨类型比较
    y_true = [to_binary_label(v) for v in y_true_raw]
    y_pred = [to_binary_label(v) for v in y_pred_raw]

    # 记录预测缺失数量（None），用于透明度报告
    parse_failures = sum(1 for v in y_pred_raw if v is None)

    try:
        from sklearn.metrics import (
            accuracy_score,
            precision_score,
            recall_score,
            f1_score,
        )

        metrics = {
            "accuracy": float(accuracy_score(y_true, y_pred)),
            "precision": float(precision_score(y_true, y_pred, zero_division=0)),
            "recall": float(recall_score(y_true, y_pred, zero_division=0)),
            "f1_score": float(f1_score(y_true, y_pred, zero_division=0)),
        }
    except ImportError:
        # sklearn 不可用时回退到纯 Python 实现（数值一致）
        metrics = _manual_metrics(y_true, y_pred)

    tp, fp, fn, tn = _confusion_counts(y_true, y_pred)
    metrics.update({
        "total_samples": len(y_true),
        "default_count": int(sum(y_true)),               # 真实违约数
        "predicted_default_count": int(sum(y_pred)),     # 预测违约数
        "confusion_matrix": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
        "parse_failures": parse_failures,                # 预测解析失败数（已按 0 计入）
    })
    return metrics


def is_correct(prediction: Any, ground_truth: Any) -> bool:
    """判断单条预测是否正确（两边都规整后比较）。"""
    return to_binary_label(prediction) == to_binary_label(ground_truth)
