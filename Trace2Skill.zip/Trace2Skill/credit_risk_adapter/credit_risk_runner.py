"""信贷风控 Runner（等价于 SpreadsheetBenchRunner）

支持串行和多 worker 并发两种模式。并发模式下，每个 worker 持有自己
独立的 agent + logger 实例（通过 agent_factory 创建），避免共享
ReActAgent 对话状态和 ChatHistoryLogger 日志文件句柄导致的线程串台。
"""

import json
import os
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from tqdm import tqdm

from credit_risk_adapter.trace2skill_adapter import (
    SBATrace2SkillAdapter,
    CreditRiskInstance,
)
from credit_risk_adapter.credit_risk_agent import (
    CreditRiskSkillAgent,
    CreditRiskContext,
)


@dataclass
class CreditRiskResult:
    """单个实例的结果"""
    id: str
    instruction: str
    ground_truth: int
    prediction: Optional[int]
    success: bool
    reasoning: str = ""
    turns: int = 0
    error: str = ""


@dataclass
class BenchmarkResult:
    """整体 benchmark 结果"""
    agent_name: str
    model: str
    timestamp: str
    total_instances: int
    correct_predictions: int
    accuracy: float
    results: List[CreditRiskResult] = field(default_factory=list)


class CreditRiskRunner:
    """信贷风控任务 Runner

    功能等价于 SpreadsheetBenchRunner，但面向分类任务。

    有两种构造方式：
    1. 传入 agent_factory（推荐，支持并发）：一个无参可调用对象，每次调用
       返回一个全新的 CreditRiskSkillAgent。并发时每个 worker 用它创建
       自己独立的 agent。
    2. 传入单个 agent（仅串行模式，向后兼容）：此时无法并发。
    """

    def __init__(
        self,
        data_path: str,
        agent: Optional[CreditRiskSkillAgent] = None,
        agent_factory: Optional[Callable[[], CreditRiskSkillAgent]] = None,
        output_dir: str = "outputs/creditrisk",
    ):
        if agent is None and agent_factory is None:
            raise ValueError("Must provide either `agent` or `agent_factory`")

        self._agent = agent
        self._agent_factory = agent_factory
        self.adapter = SBATrace2SkillAdapter(data_path=data_path)
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def _make_agent(self) -> CreditRiskSkillAgent:
        """创建一个 agent 实例（工厂优先）"""
        if self._agent_factory is not None:
            return self._agent_factory()
        return self._agent

    @property
    def agent_name(self) -> str:
        agent = self._agent if self._agent is not None else self._make_agent()
        return agent.name

    @property
    def model(self) -> str:
        agent = self._agent if self._agent is not None else self._make_agent()
        return getattr(agent.client, "model", "unknown")

    def load_data(
        self,
        start_idx: int = 0,
        end_idx: int = None,
    ) -> List[CreditRiskInstance]:
        """加载数据集"""
        return self.adapter.load_instances(start_idx, end_idx)

    def run_instance(
        self,
        instance: CreditRiskInstance,
        agent: Optional[CreditRiskSkillAgent] = None,
    ) -> CreditRiskResult:
        """运行单个实例

        Args:
            instance: 要运行的实例
            agent: 使用的 agent（并发时每个 worker 传入自己的）。
                   若为 None，使用 self._agent（串行模式）。
        """
        if agent is None:
            agent = self._agent
        if agent is None:
            raise RuntimeError("No agent available for run_instance")

        context = CreditRiskContext(
            instance_id=instance.id,
            instruction=instance.instruction,
            ground_truth=instance.ground_truth,
            features=instance.features,
        )

        try:
            agent_result = agent.run(context)
        except Exception as exc:
            return CreditRiskResult(
                id=instance.id,
                instruction=instance.instruction,
                ground_truth=instance.ground_truth,
                prediction=None,
                success=False,
                reasoning="",
                turns=0,
                error=f"{exc}\n{traceback.format_exc()}",
            )

        return CreditRiskResult(
            id=instance.id,
            instruction=instance.instruction,
            ground_truth=instance.ground_truth,
            prediction=agent_result["prediction"],
            success=agent_result["success"],
            reasoning=agent_result.get("reasoning", ""),
            turns=agent_result["turns"],
            error=agent_result["error"],
        )

    def run(
        self,
        start_idx: int = 0,
        end_idx: int = None,
        workers: int = 1,
    ) -> BenchmarkResult:
        """运行 benchmark（支持并发）"""
        instances = self.load_data(start_idx, end_idx)
        print(f"Loaded {len(instances)} instances ({start_idx} to {end_idx or 'end'})")

        if not instances:
            return BenchmarkResult(
                agent_name=self.agent_name,
                model=self.model,
                timestamp=datetime.now().isoformat(),
                total_instances=0,
                correct_predictions=0,
                accuracy=0.0,
                results=[],
            )

        if workers <= 1:
            results = self._run_serial(instances)
        else:
            results = self._run_parallel(instances, workers)

        correct_count = sum(
            1 for r in results
            if r.success and r.prediction == r.ground_truth
        )
        accuracy = correct_count / len(instances) if instances else 0

        return BenchmarkResult(
            agent_name=self.agent_name,
            model=self.model,
            timestamp=datetime.now().isoformat(),
            total_instances=len(instances),
            correct_predictions=correct_count,
            accuracy=accuracy,
            results=results,
        )

    def _run_serial(self, instances: List[CreditRiskInstance]) -> List[CreditRiskResult]:
        """串行执行"""
        # 串行模式复用单个 agent（工厂或已有实例均可）
        agent = self._agent if self._agent is not None else self._make_agent()

        results = []
        pbar = tqdm(total=len(instances), desc="Processing", unit="instance")
        correct_live = 0
        for instance in instances:
            result = self.run_instance(instance, agent=agent)
            results.append(result)
            if result.success and result.prediction == result.ground_truth:
                correct_live += 1
            pbar.set_postfix(correct=correct_live, refresh=False)
            pbar.update(1)
        pbar.close()
        return results

    def _run_parallel(
        self,
        instances: List[CreditRiskInstance],
        workers: int,
    ) -> List[CreditRiskResult]:
        """多 worker 并发执行

        按 round-robin 把 instances 分成 num_workers 块，每个 worker 用
        agent_factory 创建自己独立的 agent，串行处理分到的块。
        """
        if self._agent_factory is None:
            print(
                "[WARNING] workers > 1 requires agent_factory for thread safety. "
                "Falling back to serial execution."
            )
            return self._run_serial(instances)

        num_workers = min(workers, len(instances))
        print(f"Running in parallel mode with {num_workers} workers")

        # Round-robin 分块
        chunks = [[] for _ in range(num_workers)]
        for i, instance in enumerate(instances):
            chunks[i % num_workers].append(instance)

        all_results: dict[str, CreditRiskResult] = {}
        results_lock = threading.Lock()
        progress_lock = threading.Lock()
        correct_live = [0]
        pbar = tqdm(total=len(instances), desc="Processing", unit="instance")

        def progress_callback(result: CreditRiskResult) -> None:
            with progress_lock:
                if result.success and result.prediction == result.ground_truth:
                    correct_live[0] += 1
                pbar.set_postfix(correct=correct_live[0], refresh=False)
                pbar.update(1)

        def run_worker(worker_id: int, worker_instances: List[CreditRiskInstance]) -> None:
            # 每个 worker 创建自己独立的 agent（独立 ReActAgent + logger）
            worker_agent = self._make_agent()
            for instance in worker_instances:
                try:
                    result = self.run_instance(instance, agent=worker_agent)
                except Exception as exc:
                    result = CreditRiskResult(
                        id=instance.id,
                        instruction=instance.instruction,
                        ground_truth=instance.ground_truth,
                        prediction=None,
                        success=False,
                        error=f"{exc}\n{traceback.format_exc()}",
                    )
                    tqdm.write(f"[Worker {worker_id}] {instance.id}: ERROR - {exc}")
                with results_lock:
                    all_results[instance.id] = result
                progress_callback(result)

        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = {
                executor.submit(run_worker, i, chunk): i
                for i, chunk in enumerate(chunks)
            }
            for future in as_completed(futures):
                worker_id = futures[future]
                try:
                    future.result()
                except Exception as exc:
                    tqdm.write(f"[Worker {worker_id}] Failed with error: {exc}")
        pbar.close()

        # 按原始顺序还原结果
        ordered = [all_results[inst.id] for inst in instances if inst.id in all_results]
        return ordered

    def run_and_save(
        self,
        results_file: str = None,
        start_idx: int = 0,
        end_idx: int = None,
        workers: int = 1,
    ) -> BenchmarkResult:
        """运行并保存结果"""
        result = self.run(start_idx, end_idx, workers=workers)

        results_file = results_file or os.path.join(self.output_dir, "results.json")

        # 序列化
        result_dict = {
            "agent_name": result.agent_name,
            "model": result.model,
            "timestamp": result.timestamp,
            "total_instances": result.total_instances,
            "correct_predictions": result.correct_predictions,
            "accuracy": result.accuracy,
            "results": [
                {
                    "id": r.id,
                    "ground_truth": r.ground_truth,
                    "prediction": r.prediction,
                    "success": r.success,
                    "reasoning": r.reasoning,
                    "turns": r.turns,
                    "error": r.error,
                }
                for r in result.results
            ],
        }

        with open(results_file, "w", encoding="utf-8") as f:
            json.dump(result_dict, f, indent=2, ensure_ascii=False)

        print(f"\n{'='*60}")
        print(f"BENCHMARK COMPLETE")
        print(f"Total: {result.total_instances}, Correct: {result.correct_predictions}")
        print(f"Accuracy: {result.accuracy*100:.2f}%")
        print(f"Results: {results_file}")
        print(f"{'='*60}")

        return result
