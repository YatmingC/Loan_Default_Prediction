# SBA 适配 Trace2Skill - 快速开始指南

## 文档索引

1. **CREDIT_RISK_ADAPTATION.md** - 架构分析和理论方案（647行）
2. **CREDIT_RISK_IMPLEMENTATION.md** - 完整实施代码（926行）
3. **本文档** - 缺失部分补充 + 执行检查清单

---

## 缺失部分：Analysis 脚本适配

`CREDIT_RISK_IMPLEMENTATION.md` 已提供完整的数据加载、Agent、Runner 和多轮迭代代码，但**缺少 analysis 脚本的适配**。

### 需要适配的 analysis 组件

| 文件 | 问题 | 解决方案 |
|------|------|---------|
| `analysis/error_analysis_system.txt` | 提到 "spreadsheet", "xlsx", "gold.xlsx" | 创建 `analysis/credit_risk_error_analysis_system.txt` |
| `analysis/run_error_analysis.py` | `find_gold_file()` 查找 xlsx 文件 | 修改为从 results.json 读取 ground_truth |
| `analysis/evaluate_output.py` | 比较 xlsx 文件 | 不需要（分类任务直接比较标签） |

### 创建 `analysis/credit_risk_error_analysis_system.txt`

```text
# Role
You are an expert failure-analysis agent for credit risk prediction tasks.

# Mission
Given an agent's execution log and prediction result, diagnose **why the agent made the wrong prediction**, identify **causal failure reasons**, and suggest **how the agent's reasoning should be improved**.

Your analysis must be **systematic**, **evidence-driven**, and **reproducible**.

# Context You Will Receive
You will be given:
- The agent's full reasoning log for a credit risk prediction task
- The loan application features
- The agent's predicted label (0 or 1)
- The ground truth label (0 or 1)
- Information about why they differ

# Required Workflow (MANDATORY)
1. **Understand the prediction failure**
   - Review the loan features and identify key risk indicators
   - Compare agent's reasoning with ground truth
   - Identify which risk factors were misinterpreted or overlooked

2. **Trace the failure to agent reasoning**
   - Locate the specific reasoning steps that led to the wrong prediction
   - Identify flawed assumptions, missing patterns, or incorrect weight given to features

3. **Propose skill improvement**
   - Suggest what pattern or rule should be added/modified in the skill
   - Be specific about which features and their combinations matter

# Output Format
When you have completed your analysis, output:

Thought: [final summary]

ACTION: TASK_COMPLETE

Your analysis will be extracted from your reasoning history.
```

### 修改 `analysis/run_error_analysis.py` 中的相关函数

在 `run_error_analysis.py` 中需要修改或新增：

```python
def find_ground_truth_for_credit_risk(results_file: str, instance_id: str) -> int | None:
    """从 results.json 中读取 ground truth（适配信贷风控）"""
    try:
        with open(results_file, 'r', encoding='utf-8') as f:
            results = json.load(f)
        
        for result in results.get('results', []):
            if str(result.get('id')) == str(instance_id):
                return result.get('ground_truth')
        
        return None
    except Exception as e:
        print(f"Error reading ground truth: {e}")
        return None
```

然后在主流程中，如果检测到是信贷风控任务（通过参数 `--task_type credit_risk`），使用这个函数替代 `find_gold_file()`。

---

## 完整执行检查清单

### Phase 0: 环境准备

- [ ] 已安装依赖：`pip install openai tqdm openpyxl requests diskcache pandas numpy`
- [ ] 已设置环境变量：`OPENAI_API_KEY`, `OPENAI_BASE_URL`（可选）
- [ ] SBA 数据文件存在：`data/SBA/SBAcase.11.13.17.csv`
- [ ] 初始 skill 已准备好（你现有的 SBA skill）

### Phase 1: 拷贝依赖（10分钟）

```bash
cd D:/huawei/Trace2Skill

# 创建适配器目录
mkdir -p credit_risk_adapter

# 拷贝 SBA 原实现
cp D:/huawei/gh_auto_research/benchmark_test/data_loader_sba.py credit_risk_adapter/
cp D:/huawei/gh_auto_research/benchmark_test/prompts/default_prompt.txt credit_risk_adapter/sba_prompt_template.txt
cp D:/huawei/gh_auto_research/benchmark_test/logger.py credit_risk_adapter/

# 修改 import
sed -i 's/from benchmark_test.logger/from credit_risk_adapter.logger/g' credit_risk_adapter/data_loader_sba.py

# 准备初始 skill
mkdir -p credit_risk_adapter/skills/sba_initial
cp <你的初始SBA_skill路径> credit_risk_adapter/skills/sba_initial/SKILL.md
```

- [ ] 文件拷贝完成
- [ ] import 路径已修改
- [ ] 初始 skill 已放置

### Phase 2: 创建适配代码（30分钟）

按照 `CREDIT_RISK_IMPLEMENTATION.md` 创建以下文件（可直接复制代码）：

- [ ] `credit_risk_adapter/trace2skill_adapter.py` (Part 2)
- [ ] `credit_risk_adapter/credit_risk_agent.py` (Part 3)
- [ ] `credit_risk_adapter/credit_risk_runner.py` (Part 4)
- [ ] `run_sba_trace2skill.py` (Part 5)
- [ ] `run_sba_multi_round_evolution.sh` (Part 6)
- [ ] `analysis/credit_risk_error_analysis_system.txt` (本文档)

### Phase 3: 单轮测试（30分钟）

```bash
# 测试 50 条数据
python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model gpt-4o \
  --output_dir outputs/sba_test \
  --log_dir outputs/sba_test/logs \
  --start_idx 0 \
  --end_idx 50
```

检查点：
- [ ] 运行无报错
- [ ] 生成日志文件：`outputs/sba_test/logs/*.md`
- [ ] 生成结果文件：`outputs/sba_test/results.json`
- [ ] 日志格式正确（markdown，包含 reasoning）
- [ ] results.json 包含 accuracy 字段

### Phase 4: Analysis 测试（30分钟）

```bash
# 测试 error analysis（需要先适配 run_error_analysis.py）
python analysis/run_error_analysis.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --logs_dir outputs/sba_test/logs \
  --output_dir outputs/sba_test/error_analysis \
  --model gpt-4o \
  --workers 4 \
  --task_type credit_risk  # 新增参数
```

检查点：
- [ ] error analysis 运行成功
- [ ] 生成 parsed JSON
- [ ] JSON 结构与 spreadsheet 版本兼容

### Phase 5: Skill Evolution 测试（1小时）

```bash
# 测试单轮演化
mkdir -p outputs/sba_evolution_test/skill
cp credit_risk_adapter/skills/sba_initial/SKILL.md outputs/sba_evolution_test/skill/

python -m skill_evolver.run_parallel_combined_skill_evolution \
  --error-json outputs/sba_test/error_analysis/parsed_error_records.json \
  --success-json outputs/sba_test/success_analysis/parsed_success_records.json \
  --skill-dir outputs/sba_evolution_test/skill \
  --model gpt-4o \
  --max-workers 4 \
  --batch-size 5
```

检查点：
- [ ] 演化运行成功
- [ ] skill 文件已修改
- [ ] 生成 changelog

### Phase 6: 多轮迭代（按需）

```bash
chmod +x run_sba_multi_round_evolution.sh
./run_sba_multi_round_evolution.sh
```

检查点：
- [ ] 每轮准确率有记录
- [ ] skill 逐轮演化
- [ ] 早停机制生效（如果准确率不提升）

---

## 预期问题与解决方案

### 问题 1: analysis 脚本报错 "找不到 gold.xlsx"
**原因**：analysis 脚本硬编码了 spreadsheet 逻辑  
**解决**：使用本文档提供的 `find_ground_truth_for_credit_risk()`

### 问题 2: 日志格式不兼容
**原因**：Agent 输出格式与 analysis 预期不符  
**解决**：确保 `CreditRiskSkillAgent` 使用 `ChatHistoryLogger`，格式为 markdown

### 问题 3: skill evolution 无效果
**原因**：
1. 初始 skill 已经很强，错误样本太少
2. 数据集样本量不足
3. prompt 模板与 skill 结构不匹配

**解决**：
1. 检查 error_analysis_parsed.json 中是否有足够的错误模式
2. 调整 `--batch-size` 和 `--merge-batch-size`
3. 查看 evolution changelog，确认 skill 有实际修改

---

## 关键设计决策总结

| 决策点 | 选择 | 理由 |
|--------|------|------|
| **baseline 定义** | 加载初始 skill 的 agent | self-deepen 模式，演化在初始 skill 基础上深化 |
| **数据加载** | 100% 复用 SBADataLoader | 保持特征命名、预处理逻辑一致 |
| **Prompt 模板** | 100% 复用 default_prompt.txt | 与原 SBA baseline 完全一致 |
| **Agent 工具** | 无工具（纯推理） | 分类任务不需要文件操作 |
| **日志格式** | markdown | 兼容 Trace2Skill analysis 脚本 |
| **迭代策略** | 手动多轮 + 早停 | 论文无内置迭代，但支持 `--continue-evolving` |

---

## 估算工作量

- **Phase 1-2（环境 + 代码）**: 40 分钟
- **Phase 3（单轮测试）**: 30 分钟
- **Phase 4-5（Analysis + Evolution 测试）**: 1.5 小时
- **Phase 6（多轮迭代，可选）**: 2-4 小时（取决于数据集大小）

**总计**：最少 2.5 小时可完成基础验证，完整多轮迭代约 4-6 小时。

---

## 新会话快速启动命令

```bash
# 在新会话中执行
cd D:/huawei/Trace2Skill
cat CREDIT_RISK_IMPLEMENTATION.md  # 查看完整代码
cat CREDIT_RISK_QUICKSTART.md      # 查看本文档

# 按 Phase 1-6 依次执行检查清单
```
