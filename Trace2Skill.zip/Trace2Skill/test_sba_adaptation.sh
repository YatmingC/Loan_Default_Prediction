#!/bin/bash
# 快速测试脚本 - 验证SBA适配是否正常工作

set -e

echo "=========================================="
echo "SBA Trace2Skill Adaptation - Quick Test"
echo "=========================================="
echo ""

# 检查依赖文件
echo "[1/6] Checking dependency files..."
REQUIRED_FILES=(
    "credit_risk_adapter/data_loader_sba.py"
    "credit_risk_adapter/sba_prompt_template.txt"
    "credit_risk_adapter/logger.py"
    "credit_risk_adapter/skills/sba_initial/SKILL.md"
    "data/SBA/SBAcase.11.13.17.csv"
)

MISSING=0
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "  ✗ Missing: $file"
        MISSING=1
    else
        echo "  ✓ Found: $file"
    fi
done

if [ $MISSING -eq 1 ]; then
    echo ""
    echo "ERROR: Missing required files. Please follow SBA_ADAPTATION_GUIDE.md setup instructions."
    exit 1
fi

echo ""
echo "[2/6] Checking environment variables..."
if [ -z "$OPENAI_API_KEY" ]; then
    echo "  ✗ OPENAI_API_KEY not set"
    echo "  Please set: export OPENAI_API_KEY=<your_key>"
    exit 1
else
    echo "  ✓ OPENAI_API_KEY is set"
fi

# 测试数据加载
echo ""
echo "[3/6] Testing data loader..."
python -c "
from credit_risk_adapter.trace2skill_adapter import SBATrace2SkillAdapter
adapter = SBATrace2SkillAdapter(data_path='data/SBA/SBAcase.11.13.17.csv')
instances = adapter.load_instances(start_idx=0, end_idx=5)
print(f'  ✓ Loaded {len(instances)} instances')
print(f'  ✓ First instance ID: {instances[0].id}')
print(f'  ✓ Ground truth: {instances[0].ground_truth}')
"

# 测试agent初始化
echo ""
echo "[4/6] Testing agent initialization..."
python -c "
from src.react_agent import OpenAIClient
from credit_risk_adapter.credit_risk_agent import CreditRiskSkillAgent
import os

client = OpenAIClient(model='gpt-4o', api_key=os.getenv('OPENAI_API_KEY'))
agent = CreditRiskSkillAgent(
    client=client,
    skill_path='credit_risk_adapter/skills/sba_initial/SKILL.md',
    max_turns=5,
    verbose=False,
)
print(f'  ✓ Agent initialized: {agent.name}')
print(f'  ✓ Skill content length: {len(agent.skill_content)} characters')
"

# 运行小规模测试（3个样本）
echo ""
echo "[5/6] Running small-scale test (3 samples)..."
TEST_DIR="outputs/sba_quick_test"
rm -rf "$TEST_DIR"

python run_sba_trace2skill.py \
  --data_path data/SBA/SBAcase.11.13.17.csv \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model gpt-4o \
  --output_dir "$TEST_DIR" \
  --log_dir "$TEST_DIR/logs" \
  --start_idx 0 \
  --end_idx 3 \
  --max_turns 10

# 验证输出
echo ""
echo "[6/6] Validating outputs..."
if [ -f "$TEST_DIR/results.json" ]; then
    echo "  ✓ results.json created"
    python -c "
import json
with open('$TEST_DIR/results.json') as f:
    data = json.load(f)
print(f'  ✓ Accuracy: {data[\"accuracy\"]*100:.1f}%')
print(f'  ✓ Total instances: {data[\"total_instances\"]}')
print(f'  ✓ Correct predictions: {data[\"correct_predictions\"]}')
"
else
    echo "  ✗ results.json not found"
    exit 1
fi

LOG_COUNT=$(ls "$TEST_DIR/logs"/*.md 2>/dev/null | wc -l)
if [ $LOG_COUNT -eq 3 ]; then
    echo "  ✓ Created $LOG_COUNT log files"
else
    echo "  ✗ Expected 3 log files, found $LOG_COUNT"
    exit 1
fi

echo ""
echo "=========================================="
echo "✓ ALL TESTS PASSED"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Run on larger dataset (50-200 samples)"
echo "2. Run error analysis to validate credit_risk task type"
echo "3. Run full multi-round evolution pipeline"
echo ""
echo "Commands:"
echo "  # Test with 50 samples:"
echo "  python run_sba_trace2skill.py \\"
echo "    --data_path data/SBA/SBAcase.11.13.17.csv \\"
echo "    --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \\"
echo "    --model gpt-4o \\"
echo "    --output_dir outputs/sba_test_50 \\"
echo "    --start_idx 0 --end_idx 50"
echo ""
echo "  # Run multi-round evolution:"
echo "  chmod +x run_sba_multi_round_evolution.sh"
echo "  ./run_sba_multi_round_evolution.sh"
echo ""
