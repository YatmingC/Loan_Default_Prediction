# SBA信贷风控数据集适配指南

本文档说明如何将Trace2Skill方法适配到SBA信贷风控数据集。

## 架构差异对比

| 维度 | SpreadsheetBench | SBA信贷风控 |
|------|------------------|-------------|
| 任务类型 | 文件操作（读取/修改Excel） | 分类预测（判断违约） |
| 输入格式 | Excel文件 (.xlsx) | CSV记录（特征向量） |
| 输出格式 | 修改后的Excel文件 | 分类标签 (0/1) |
| Agent工具 | bash命令操作文件系统 | 直接接收DataFrame，返回预测 |
| 一个instance | 一个spreadsheet操作任务 | 一条贷款记录 |

## 适配方案

### 核心理念

将CSV每一行视为一个"instance"，保持Trace2Skill的核心流程：
1. **轨迹生成**：baseline agent在样本上推理，生成成功/失败轨迹
2. **分析**：使用现有的error_analysis和success_analysis分析轨迹
3. **Skill演化**：使用parallel_evolving_agent演化skill
4. **评估**：在held-out集上评估演化后的skill

### 关键适配

#### 1. 数据加载适配

**创建 `credit_risk_agent/data_loader.py`**：

```python
"""信贷风控数据集加载器"""
import json
import pandas as pd
from dataclasses import dataclass, field
from pathlib import Path

@dataclass
class CreditRiskInstance:
    """单条信贷记录"""
    id: str                          # 记录ID（行号）
    features: dict                   # 特征字典
    ground_truth: int                # 真实标签（0/1）
    instruction: str                 # 任务指令
    metadata: dict = field(default_factory=dict)

class CreditRiskDataLoader:
    """将CSV转换为Trace2Skill instance格式"""
    
    def __init__(
        self,
        data_path: str,
        target_column: str = "Default",
        instruction_template: str = None,
    ):
        self.data_path = Path(data_path)
        self.target_column = target_column
        self.instruction_template = instruction_template or self._default_instruction()
        
    def _default_instruction(self) -> str:
        return """Based on the following loan application features, predict whether the borrower will default (1) or not (0).

Features:
{features}

Analyze the risk factors and provide your prediction as a single digit: 0 or 1."""
    
    def load_instances(self, start_idx: int = 0, end_idx: int = None) -> list[CreditRiskInstance]:
        """加载数据集为instance列表"""
        df = pd.read_csv(self.data_path)
        
        if end_idx is None:
            end_idx = len(df)
        df = df.iloc[start_idx:end_idx]
        
        instances = []
        for idx, row in df.iterrows():
            # 提取特征（排除目标列）
            features = {
                col: row[col] 
                for col in df.columns 
                if col != self.target_column
            }
            
            # 格式化指令
            features_str = "\n".join([f"- {k}: {v}" for k, v in features.items()])
            instruction = self.instruction_template.format(features=features_str)
            
            instances.append(CreditRiskInstance(
                id=str(idx),
                features=features,
                ground_truth=int(row[self.target_column]),
                instruction=instruction,
            ))
        
        return instances
    
    def save_as_jsonl(self, output_path: str, start_idx: int = 0, end_idx: int = None):
        """保存为Trace2Skill兼容的JSONL格式"""
        instances = self.load_instances(start_idx, end_idx)
        
        with open(output_path, "w", encoding="utf-8") as f:
            for inst in instances:
                record = {
                    "id": inst.id,
                    "instruction": inst.instruction,
                    "ground_truth": inst.ground_truth,
                    "features": inst.features,
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
```

#### 2. Agent适配

**创建 `credit_risk_agent/agents/base.py`**：

```python
"""信贷风控Agent基类"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
import os
from typing import Callable

from react_agent import ReActAgent, AgentConfig, AgentStep, LLMClient
from spreadsheet_agent.agents.base import ChatHistoryLogger

@dataclass
class CreditRiskContext:
    """信贷风控任务上下文"""
    instance_id: str
    instruction: str      # 包含特征的完整prompt
    ground_truth: int     # 真实标签（仅用于评估）
    features: dict        # 原始特征字典

class BaseCreditRiskAgent(ABC):
    """信贷风控Agent基类
    
    与SpreadsheetAgent的关键区别：
    - 不需要文件系统操作工具
    - 输出是分类标签，而非文件
    - 可以选择零工具模式（纯prompt）或提供分析工具
    """
    
    def __init__(
        self,
        client: LLMClient,
        max_turns: int = 10,
        temperature: float = 0.0,
        verbose: bool = True,
        log_dir: str | None = None,
        log_format: str = "markdown",
    ):
        self.client = client
        self.max_turns = max_turns
        self.temperature = temperature
        self.verbose = verbose
        self._agent: ReActAgent | None = None
        
        if log_dir:
            self._logger = ChatHistoryLogger(
                log_dir=log_dir,
                format=log_format,
            )
        else:
            self._logger = None
    
    @property
    @abstractmethod
    def name(self) -> str:
        pass
    
    @abstractmethod
    def get_system_prompt(self) -> str:
        """返回系统提示（包含skill）"""
        pass
    
    def build_task_prompt(self, context: CreditRiskContext) -> str:
        """构建任务prompt"""
        return context.instruction
    
    def run(self, context: CreditRiskContext) -> dict:
        """运行agent进行预测
        
        Returns:
            {
                "success": bool,
                "prediction": int,  # 0 or 1
                "answer": str,      # 原始回答
                "turns": int,
                "error": str,
            }
        """
        # 创建agent实例
        if self._agent is None:
            config = AgentConfig(
                max_turns=self.max_turns,
                verbose=self.verbose,
                system_instructions=self.get_system_prompt(),
            )
            self._agent = ReActAgent(
                client=self.client,
                tools=[],  # 信贷风控任务通常不需要工具
                config=config,
                on_step=self._create_step_callback(),
            )
        
        task_prompt = self.build_task_prompt(context)
        
        # 日志记录
        if self._logger:
            self._logger.start_session(self.name, task_prompt, None)
            self._logger.log_system_prompt(self.get_system_prompt())
            self._logger.log_user_task(task_prompt)
        
        try:
            result = self._agent.run(task_prompt)
            
            # 解析预测结果
            prediction = self._extract_prediction(result.final_answer)
            
            run_result = {
                "success": result.success and prediction is not None,
                "prediction": prediction,
                "answer": result.final_answer,
                "turns": result.total_turns,
                "error": result.error if not result.success else "",
            }
            
            if self._logger:
                self._logger.log_result(
                    success=run_result["success"],
                    answer=run_result["answer"],
                    turns=run_result["turns"],
                    error=run_result["error"],
                )
            
            return run_result
            
        except Exception as e:
            error_msg = f"Exception: {str(e)}"
            error_result = {
                "success": False,
                "prediction": None,
                "answer": "",
                "turns": 0,
                "error": error_msg,
            }
            
            if self._logger:
                self._logger.log_result(False, "", 0, error_msg)
            
            return error_result
    
    def _extract_prediction(self, answer: str) -> int | None:
        """从agent回答中提取预测标签"""
        # 简单策略：查找最后出现的0或1
        answer = answer.strip()
        
        # 查找明确的预测格式
        if "prediction:" in answer.lower():
            parts = answer.lower().split("prediction:")
            last_part = parts[-1].strip()
            if last_part.startswith("1"):
                return 1
            elif last_part.startswith("0"):
                return 0
        
        # 回退：查找最后的数字
        for char in reversed(answer):
            if char == "1":
                return 1
            elif char == "0":
                return 0
        
        return None
    
    def _create_step_callback(self) -> Callable[[AgentStep], None] | None:
        if self._logger is None:
            return None
        return lambda step: self._logger.log_step(step)
```

#### 3. Runner适配

**创建 `credit_risk_agent/runner.py`**：

```python
"""信贷风控Runner"""
import json
import os
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field

from credit_risk_agent.data_loader import CreditRiskDataLoader, CreditRiskInstance
from credit_risk_agent.agents.base import BaseCreditRiskAgent, CreditRiskContext

@dataclass
class CreditRiskResult:
    """单个实例的结果"""
    id: str
    instruction: str
    ground_truth: int
    prediction: int | None
    success: bool
    answer: str = ""
    turns: int = 0
    error: str = ""

@dataclass
class BenchmarkResult:
    """整体benchmark结果"""
    agent_name: str
    model: str
    timestamp: str
    total_instances: int
    successful_predictions: int
    accuracy: float
    results: list[CreditRiskResult] = field(default_factory=list)

class CreditRiskRunner:
    """信贷风控任务Runner
    
    功能等价于SpreadsheetBenchRunner，但面向分类任务
    """
    
    def __init__(
        self,
        agent: BaseCreditRiskAgent,
        data_path: str,
        target_column: str = "Default",
        output_dir: str = "outputs/creditrisk",
    ):
        self.agent = agent
        self.data_loader = CreditRiskDataLoader(
            data_path=data_path,
            target_column=target_column,
        )
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def load_data(self) -> list[CreditRiskInstance]:
        """加载数据集"""
        return self.data_loader.load_instances()
    
    def run_instance(self, instance: CreditRiskInstance) -> CreditRiskResult:
        """运行单个实例"""
        context = CreditRiskContext(
            instance_id=instance.id,
            instruction=instance.instruction,
            ground_truth=instance.ground_truth,
            features=instance.features,
        )
        
        agent_result = self.agent.run(context)
        
        return CreditRiskResult(
            id=instance.id,
            instruction=instance.instruction,
            ground_truth=instance.ground_truth,
            prediction=agent_result["prediction"],
            success=agent_result["success"],
            answer=agent_result["answer"],
            turns=agent_result["turns"],
            error=agent_result["error"],
        )
    
    def run(
        self,
        start_idx: int = 0,
        end_idx: int | None = None,
    ) -> BenchmarkResult:
        """运行benchmark"""
        instances = self.data_loader.load_instances(start_idx, end_idx)
        print(f"Loaded {len(instances)} instances ({start_idx} to {end_idx or 'end'})")
        
        results = []
        correct_count = 0
        
        for i, instance in enumerate(instances, start=1):
            print(f"\nInstance {i}/{len(instances)}: {instance.id}")
            result = self.run_instance(instance)
            results.append(result)
            
            if result.success and result.prediction == result.ground_truth:
                correct_count += 1
                print(f"  CORRECT (predicted {result.prediction}, ground truth {result.ground_truth})")
            else:
                print(f"  WRONG (predicted {result.prediction}, ground truth {result.ground_truth})")
        
        accuracy = correct_count / len(instances) if instances else 0
        
        return BenchmarkResult(
            agent_name=self.agent.name,
            model=getattr(self.agent.client, "model", "unknown"),
            timestamp=datetime.now().isoformat(),
            total_instances=len(instances),
            successful_predictions=correct_count,
            accuracy=accuracy,
            results=results,
        )
    
    def run_and_save(
        self,
        results_file: str | None = None,
        start_idx: int = 0,
        end_idx: int | None = None,
    ) -> BenchmarkResult:
        """运行并保存结果"""
        result = self.run(start_idx, end_idx)
        
        results_file = results_file or os.path.join(self.output_dir, "results.json")
        
        result_dict = {
            "agent_name": result.agent_name,
            "model": result.model,
            "timestamp": result.timestamp,
            "total_instances": result.total_instances,
            "successful_predictions": result.successful_predictions,
            "accuracy": result.accuracy,
            "results": [
                {
                    "id": r.id,
                    "ground_truth": r.ground_truth,
                    "prediction": r.prediction,
                    "success": r.success,
                    "answer": r.answer,
                    "turns": r.turns,
                    "error": r.error,
                }
                for r in result.results
            ],
        }
        
        with open(results_file, "w", encoding="utf-8") as f:
            json.dump(result_dict, f, indent=2)
        
        print(f"\n{'='*60}")
        print(f"BENCHMARK COMPLETE")
        print(f"Agent: {result.agent_name}")
        print(f"Total: {result.total_instances}, Correct: {result.successful_predictions}")
        print(f"Accuracy: {result.accuracy*100:.2f}%")
        print(f"Results saved to: {results_file}")
        print(f"{'='*60}")
        
        return result
```

#### 4. 具体Agent实现

> **重要澄清 —— "baseline" 的真实含义**
>
> Trace2Skill 里存在两个不同的参照点，不要混淆：
>
> 1. **无 skill 对照组（`cli_only`）**：系统提示不含任何 skill，仅用于"连 skill 都没有"的对比实验。**不是**演化轨迹的来源。
> 2. **演化起点基线（`cli_skill_preloaded`）**：加载了**初始 skill**的 agent。它生成的轨迹才是喂给分析和演化的数据源。论文的两种模式都从这里出发：
>    - **self-deepen**：初始 skill 是人工编写的成熟 skill
>    - **self-create**：初始 skill 是一个很弱的草稿
>
> **你已有初始 SBA skill → 走 self-deepen 路线。** 生成轨迹的 agent 必须加载你的初始 skill，演化在此基础上深化。下面因此定义两个 agent：
> - `NoSkillCreditRiskAgent`：可选的无 skill 对照组
> - `SkillCreditRiskAgent`（见下一节）：加载初始/演化 skill，既用于**生成演化轨迹**，也用于**评估演化后的 skill**

**创建 `credit_risk_agent/agents/no_skill_agent.py`（可选对照组）**：

```python
"""无 skill 对照组 Agent（等价于 cli_only，仅用于对比，不产生演化轨迹）"""
from credit_risk_agent.agents.base import BaseCreditRiskAgent

class NoSkillCreditRiskAgent(BaseCreditRiskAgent):
    """无 skill 的对照 agent"""
    
    @property
    def name(self) -> str:
        return "no_skill_credit_risk_agent"
    
    def get_system_prompt(self) -> str:
        return """You are a credit risk assessment expert. Your task is to analyze loan application data and predict whether the borrower will default.

Guidelines:
1. Carefully review all provided features
2. Identify high-risk indicators (e.g., low credit score, high debt ratio, unstable employment)
3. Consider industry-specific patterns for the dataset
4. Provide your final prediction as a single digit: 0 (will not default) or 1 (will default)

Format your response as:
Analysis: [your reasoning]
Prediction: [0 or 1]"""
```

**创建 `credit_risk_agent/agents/skill_agent.py`**：

```python
"""带Skill的信贷风控Agent"""
import os
from pathlib import Path

from credit_risk_agent.agents.base import BaseCreditRiskAgent

class SkillCreditRiskAgent(BaseCreditRiskAgent):
    """加载skill的agent"""
    
    def __init__(self, skills_dir: str, **kwargs):
        super().__init__(**kwargs)
        self.skills_dir = Path(skills_dir)
        self._skill_content = self._load_skills()
    
    @property
    def name(self) -> str:
        return "skill_credit_risk_agent"
    
    def _load_skills(self) -> str:
        """加载skill内容"""
        skill_file = self.skills_dir / "SKILL.md"
        if not skill_file.exists():
            return ""
        
        with open(skill_file, "r", encoding="utf-8") as f:
            return f.read()
    
    def get_system_prompt(self) -> str:
        base_prompt = """You are a credit risk assessment expert. Use the evolved skills below to predict loan defaults.

# EVOLVED SKILLS

{skills}

# TASK

Analyze the loan application and predict: 0 (will not default) or 1 (will default).

Format:
Analysis: [reasoning using skills]
Prediction: [0 or 1]"""
        
        return base_prompt.format(skills=self._skill_content)
```

## 使用流程

### Step 1: 数据准备

```bash
# 将SBA CSV转换为Trace2Skill格式
python -c "
from credit_risk_agent.data_loader import CreditRiskDataLoader

loader = CreditRiskDataLoader(
    data_path='data/SBA/SBAcase.11.13.17.csv',
    target_column='Default',
)

# 训练集 0:200
loader.save_as_jsonl('data/sba_train.jsonl', start_idx=0, end_idx=200)

# 测试集 200:400
loader.save_as_jsonl('data/sba_test.jsonl', start_idx=200, end_idx=400)
"
```

### Step 2: 加载初始 Skill 运行（生成演化轨迹）

**关键**：这里必须加载你的初始 SBA skill，不是无 skill。生成的轨迹将作为演化输入。

```bash
# 先把你的初始 SBA skill 放到 credit_risk_agent/skills/sba/ 目录
# 目录结构应为：credit_risk_agent/skills/sba/SKILL.md（包含你的初始 skill 内容）

python run_creditrisk.py \
  --data_path data/sba_train.jsonl \
  --agent skill \
  --skills_dir credit_risk_agent/skills/sba \
  --model gpt-4o \
  --output_dir outputs/sba_initial_skill \
  --log_dir outputs/sba_initial_skill/logs \
  --workers 32
```

### Step 3: 分析轨迹

```bash
# 错误分析（分析预测错误的样本）
python analysis/run_error_analysis.py \
  --data_path data/sba_train.jsonl \
  --logs_dir outputs/sba_initial_skill/logs \
  --output_dir outputs/sba_initial_skill/error_analysis \
  --model gpt-4o \
  --workers 32

# 成功分析（分析预测正确的样本）
python analysis/run_success_analysis_llm.py \
  --logs_dir outputs/sba_initial_skill/logs \
  --output_dir outputs/sba_initial_skill/success_analysis \
  --model gpt-4o \
  --max_workers 32

# 解析输出
python analysis/parse_error_analysis_outputs.py \
  --input_dir outputs/sba_initial_skill/error_analysis \
  --output outputs/sba_initial_skill/error_analysis_parsed.json

python analysis/parse_success_analysis_outputs.py \
  --input_dir outputs/sba_initial_skill/success_analysis \
  --output outputs/sba_initial_skill/success_analysis_parsed.json
```

### Step 4: Skill演化

```bash
# 初始化skill目录
mkdir -p credit_risk_agent/skills/sba
echo "# SBA Credit Risk Skills" > credit_risk_agent/skills/sba/SKILL.md

# 运行演化
python -m skill_evolver.run_parallel_combined_skill_evolution \
  --error-json outputs/sba_baseline/error_analysis_parsed.json \
  --success-json outputs/sba_baseline/success_analysis_parsed.json \
  --skill-dir credit_risk_agent/skills/sba \
  --model gpt-4o \
  --max-workers 32 \
  --batch-size 5
```

### Step 5: 评估演化后的Skill

```bash
python run_creditrisk.py \
  --data_path data/sba_test.jsonl \
  --agent skill \
  --skills_dir credit_risk_agent/skills/sba \
  --model gpt-4o \
  --output_dir outputs/sba_skill \
  --log_dir outputs/sba_skill/logs \
  --workers 32
```

## 注意事项

1. **轨迹日志格式**：确保日志格式与现有analysis脚本兼容（markdown格式）
2. **Success定义**：分类正确 = success，分类错误 = failure
3. **Batch Size**：信贷记录通常较短，可以增大batch_size加速演化
4. **多种子验证**：使用3个种子演化，选最佳结果
5. **评估指标**：除accuracy外，还应考虑precision/recall/F1（特别是不平衡数据集）

## 与gh_auto_research项目的集成

可以复用`run_benchmark.py`中的DataLoader逻辑，但推理引擎替换为Trace2Skill的Agent+Skill系统。
