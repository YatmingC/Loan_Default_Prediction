#!/usr/bin/env python3
"""给 SBA 信贷风控的轨迹日志打 _SUCCEED / _FAILED 后缀。

背景
----
analysis/run_error_analysis.py 与 analysis/run_success_analysis_llm.py 都通过
日志文件名里的 `_SUCCEED` / `_FAILED` 后缀来发现要分析的实例：
  - error analysis 只挑 `_FAILED` 的（要从错误里学）
  - success analysis 只挑 `_SUCCEED` 的（要从成功里学）

但 CreditRiskSkillAgent 的 logger 只会写 `credit_risk_skill_agent_{id}.md`，
不带任何后缀。因此必须在「生成轨迹」和「分析轨迹」之间插入这一步，否则两个
分析脚本都会发现 0 个实例，演化阶段拿到空输入、skill 不会真正进化。

为什么不用 analyze_results.py
-----------------------------
analyze_results.py 的 rename 依据是 result["success"]，而在信贷风控里 success
表示「模型输出能被解析成 0/1」，不等于「预测正确」。一个能解析但预测错误的样本
会被错误地标成 _SUCCEED、送进 success analysis。这里改为依据 is_correct()
（prediction 与 ground_truth 规整后相等），口径与 results.json 的 accuracy 一致。

用法
----
    python rename_sba_logs.py \
        --results outputs/sba_multi_round/round_0/outputs/results.json \
        --logs_dir outputs/sba_multi_round/round_0/logs

幂等：已带 _SUCCEED / _FAILED 的文件会被跳过；可安全重复执行。
"""

import argparse
import json
import os
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from credit_risk_adapter.metrics import is_correct


def _instance_id_from_filename(name: str) -> str | None:
    """从日志文件名解析 instance id。

    约定：`{agent_name}_{id}.md`，id 为最后一个下划线段。
    已带 _SUCCEED / _FAILED 后缀的返回 None（视为已处理）。
    """
    if not name.endswith(".md"):
        return None
    stem = name[: -len(".md")]
    if stem.endswith("_SUCCEED") or stem.endswith("_FAILED"):
        return None
    parts = stem.split("_")
    if not parts:
        return None
    return parts[-1]


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Tag SBA trajectory logs with _SUCCEED/_FAILED based on correctness"
    )
    parser.add_argument(
        "--results",
        required=True,
        help="Path to results.json produced by run_sba_trace2skill.py",
    )
    parser.add_argument(
        "--logs_dir",
        required=True,
        help="Directory holding the agent .md logs for this round",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print planned renames without touching disk",
    )
    args = parser.parse_args()

    with open(args.results, encoding="utf-8") as fh:
        data = json.load(fh)
    results = data["results"] if isinstance(data, dict) else data

    # id -> is_correct
    correct_by_id: dict[str, bool] = {}
    for r in results:
        rid = str(r.get("id", ""))
        correct_by_id[rid] = is_correct(r.get("prediction"), r.get("ground_truth"))

    logs_dir = args.logs_dir
    renamed = succeed = failed = skipped = missing = 0

    for name in sorted(os.listdir(logs_dir)):
        instance_id = _instance_id_from_filename(name)
        if instance_id is None:
            skipped += 1
            continue
        if instance_id not in correct_by_id:
            # 日志里有、results.json 里没有（例如只跑了部分实例）
            missing += 1
            continue

        suffix = "_SUCCEED" if correct_by_id[instance_id] else "_FAILED"
        src = os.path.join(logs_dir, name)
        dst = os.path.join(logs_dir, name[: -len(".md")] + suffix + ".md")
        if src == dst:
            continue

        if args.dry_run:
            print(f"[dry-run] {name} -> {os.path.basename(dst)}")
        else:
            os.rename(src, dst)
        renamed += 1
        if suffix == "_SUCCEED":
            succeed += 1
        else:
            failed += 1

    print(
        f"Renamed {renamed} logs ({succeed} SUCCEED, {failed} FAILED) in {logs_dir}. "
        f"Skipped {skipped} (already tagged / non-log), {missing} not in results.json."
    )


if __name__ == "__main__":
    main()
