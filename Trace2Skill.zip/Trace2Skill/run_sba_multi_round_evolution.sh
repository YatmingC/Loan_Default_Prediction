#!/bin/bash
# SBA 数据集多轮迭代演化脚本

set -e

DATA_PATH="data/SBA/SBAcase.11.13.17.csv"
MODEL="gpt-4o"
WORKERS=32
INITIAL_SKILL="credit_risk_adapter/skills/sba_initial/SKILL.md"
OUTPUT_ROOT="outputs/sba_multi_round"

# 迭代轮数
MAX_ROUNDS=3

echo "==================================="
echo "SBA Multi-Round Evolution Pipeline"
echo "==================================="
echo "Data: $DATA_PATH"
echo "Model: $MODEL"
echo "Max rounds: $MAX_ROUNDS"
echo "==================================="

# Round 0: 用初始 skill 生成轨迹
echo ""
echo "ROUND 0: Generating trajectories with initial skill..."
ROUND_DIR="$OUTPUT_ROOT/round_0"
mkdir -p "$ROUND_DIR"

python run_sba_trace2skill.py \
  --data_path "$DATA_PATH" \
  --skill_path "$INITIAL_SKILL" \
  --model "$MODEL" \
  --output_dir "$ROUND_DIR/outputs" \
  --log_dir "$ROUND_DIR/logs" \
  --start_idx 0 \
  --end_idx 200 \
  --workers "$WORKERS"

# 计算 baseline 准确率
BASELINE_ACCURACY=$(python -c "
import json
with open('$ROUND_DIR/outputs/results.json') as f:
    data = json.load(f)
print(data['accuracy'])
")
echo "Baseline accuracy: $BASELINE_ACCURACY"

# 迭代演化
for round in $(seq 1 $MAX_ROUNDS); do
    echo ""
    echo "======================================="
    echo "ROUND $round: Evolution and validation"
    echo "======================================="

    PREV_ROUND=$((round - 1))
    PREV_DIR="$OUTPUT_ROOT/round_$PREV_ROUND"
    CURR_DIR="$OUTPUT_ROOT/round_$round"
    mkdir -p "$CURR_DIR"

    # Step 1: 分析上一轮轨迹
    echo "Step 1: Analyzing round $PREV_ROUND trajectories..."

    python analysis/run_error_analysis.py \
      --data_path "$PREV_DIR/outputs/results.json" \
      --logs_dir "$PREV_DIR/logs" \
      --output_dir "$CURR_DIR/error_analysis" \
      --model "$MODEL" \
      --task_type credit_risk \
      --workers "$WORKERS"

    python analysis/run_success_analysis_llm.py \
      --logs_dir "$PREV_DIR/logs" \
      --output_dir "$CURR_DIR/success_analysis" \
      --model "$MODEL" \
      --max_workers "$WORKERS"

    python analysis/parse_error_analysis_outputs.py \
      --input_dir "$CURR_DIR/error_analysis" \
      --output "$CURR_DIR/error_analysis_parsed.json"

    python analysis/parse_success_analysis_outputs.py \
      --input_dir "$CURR_DIR/success_analysis" \
      --output "$CURR_DIR/success_analysis_parsed.json"

    # Step 2: 演化 skill
    echo "Step 2: Evolving skill..."

    # 拷贝上一轮的 skill 作为起点
    SKILL_DIR="$CURR_DIR/skill"
    if [ $round -eq 1 ]; then
        mkdir -p "$SKILL_DIR"
        cp "$INITIAL_SKILL" "$SKILL_DIR/SKILL.md"
    else
        cp -r "$OUTPUT_ROOT/round_$PREV_ROUND/skill" "$SKILL_DIR"
    fi

    python -m skill_evolver.run_parallel_combined_skill_evolution \
      --error-json "$CURR_DIR/error_analysis_parsed.json" \
      --success-json "$CURR_DIR/success_analysis_parsed.json" \
      --skill-dir "$SKILL_DIR" \
      --model "$MODEL" \
      --max-workers "$WORKERS" \
      --batch-size 5 \
      --continue-evolving \
      --changelog "$CURR_DIR/evolution_changelog.md"

    # Step 3: 用演化后的 skill 重新生成轨迹
    echo "Step 3: Validating evolved skill..."

    python run_sba_trace2skill.py \
      --data_path "$DATA_PATH" \
      --skill_path "$SKILL_DIR/SKILL.md" \
      --model "$MODEL" \
      --output_dir "$CURR_DIR/outputs" \
      --log_dir "$CURR_DIR/logs" \
      --start_idx 0 \
      --end_idx 200 \
      --workers "$WORKERS"

    # 计算准确率
    CURR_ACCURACY=$(python -c "
import json
with open('$CURR_DIR/outputs/results.json') as f:
    data = json.load(f)
print(data['accuracy'])
")

    echo "Round $round accuracy: $CURR_ACCURACY (baseline: $BASELINE_ACCURACY)"

    # 检查是否提升
    IMPROVED=$(python -c "print(1 if $CURR_ACCURACY > $BASELINE_ACCURACY else 0)")
    if [ "$IMPROVED" -eq 1 ]; then
        echo "✓ Improvement detected!"
        BASELINE_ACCURACY=$CURR_ACCURACY
    else
        echo "✗ No improvement, stopping iteration"
        break
    fi
done

echo ""
echo "==================================="
echo "Multi-round evolution completed!"
echo "Final accuracy: $BASELINE_ACCURACY"
echo "==================================="
