
分开手动跑（便于 debug）

下面每一步都可以独立执行、独立检查产物。先设好环境：

export OPENAI_API_KEY=<your_key>
如用兼容端点： export OPENAI_BASE_URL=<endpoint>

DATA=data/SBA/SBAcase.11.13.17.csv   # 改成你的实际路径
MODEL=gpt-4o
WORKERS=32

# Round 0 — 用初始 skill 生成轨迹

python run_sba_trace2skill.py \
  --data_path "$DATA" \
  --skill_path credit_risk_adapter/skills/sba_initial/SKILL.md \
  --model "$MODEL" \
  --output_dir outputs/sba_multi_round/round_0/outputs \
  --log_dir   outputs/sba_multi_round/round_0/logs \
  --start_idx 0 --end_idx 200 --workers "$WORKERS"
检查：outputs/sba_multi_round/round_0/outputs/results.json 存在、有 accuracy；round_0/logs/ 下有一堆 .md。

# 打后缀（新增的必做步骤）

python rename_sba_logs.py \
  --results  outputs/sba_multi_round/round_0/outputs/results.json \
  --logs_dir outputs/sba_multi_round/round_0/logs
先加 --dry-run 可以预览。它会打印 Renamed N logs (X SUCCEED, Y FAILED)。如果 N=0 或全是 SUCCEED/全是 FAILED，后面分析会没东西可学 —— 这里就能提前发现问题。

# Round 1 - Step 1：分析上一轮

# 错误分析（只处理 _FAILED 的日志）
python analysis/run_error_analysis.py \
  --data_path outputs/sba_multi_round/round_0/outputs/results.json \
  --logs_dir  outputs/sba_multi_round/round_0/logs \
  --output_dir outputs/sba_multi_round/round_1/error_analysis \
  --model "$MODEL" --task_type credit_risk --workers "$WORKERS"

# 成功分析（只处理 _SUCCEED 的日志）
python analysis/run_success_analysis_llm.py \
  --logs_dir  outputs/sba_multi_round/round_0/logs \
  --output_dir outputs/sba_multi_round/round_1/success_analysis \
  --model "$MODEL" --task_type credit_risk --max_workers "$WORKERS"

# 解析成结构化 JSON
python analysis/parse_error_analysis_outputs.py \
  --input_dir outputs/sba_multi_round/round_1/error_analysis \
  --output    outputs/sba_multi_round/round_1/error_analysis_parsed.json

python analysis/parse_success_analysis_outputs.py \
  --input_dir outputs/sba_multi_round/round_1/success_analysis \
  --output    outputs/sba_multi_round/round_1/success_analysis_parsed.json
检查：两个 *_parsed.json 是非空 list。

# Round 1 - Step 2：演化 skill

mkdir -p outputs/sba_multi_round/round_1/skill
cp credit_risk_adapter/skills/sba_initial/SKILL.md outputs/sba_multi_round/round_1/skill/

python -m skill_evolver.run_parallel_combined_skill_evolution \
  --error-json   outputs/sba_multi_round/round_1/error_analysis_parsed.json \
  --success-json outputs/sba_multi_round/round_1/success_analysis_parsed.json \
  --skill-dir    outputs/sba_multi_round/round_1/skill \
  --model "$MODEL" --task-type credit_risk --max-workers "$WORKERS" --batch-size 5 \
  --continue-evolving \
  --changelog    outputs/sba_multi_round/round_1/evolution_changelog.md
检查：round_1/skill/SKILL.md 内容相对初始版有变化；看 evolution_changelog.md。

# Round 1 - Step 3：用演化后的 skill 重新验证

python run_sba_trace2skill.py \
  --data_path "$DATA" \
  --skill_path outputs/sba_multi_round/round_1/skill/SKILL.md \
  --model "$MODEL" \
  --output_dir outputs/sba_multi_round/round_1/outputs \
  --log_dir   outputs/sba_multi_round/round_1/logs \
  --start_idx 0 --end_idx 200 --workers "$WORKERS"

# 再打后缀，供 Round 2 分析用
python rename_sba_logs.py \
  --results  outputs/sba_multi_round/round_1/outputs/results.json \
  --logs_dir outputs/sba_multi_round/round_1/logs

# 对比准确率，决定是否继续

python -c "import json;print('round_0', json.load(open('outputs/sba_multi_round/round_0/outputs/results.json'))['accuracy'])"
python -c "import json;print('round_1', json.load(open('outputs/sba_multi_round/round_1/outputs/results.json'))['accuracy'])"
有提升就进 Round 2：把上面 Step 1-3 里的 round_0→round_1、round_1→round_2，并且 Step 2 的起点 skill 改成拷贝上一轮：cp -r
outputs/sba_multi_round/round_1/skill outputs/sba_multi_round/round_2/skill(不再从 sba_initial 拷)。

# 最终 held-out 评估（选出最佳轮次后）

python run_sba_trace2skill.py \
  --data_path "$DATA" \
  --skill_path outputs/sba_multi_round/round_X/skill/SKILL.md \
  --model "$MODEL" \
  --output_dir outputs/sba_final_eval/outputs \
  --log_dir   outputs/sba_final_eval/logs \
  --start_idx 200 --end_idx 400 --workers "$WORKERS"